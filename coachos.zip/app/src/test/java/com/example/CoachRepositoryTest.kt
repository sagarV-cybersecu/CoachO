package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.repository.CoachRepository
import com.example.model.ClientStatus
import com.example.model.PrimaryGoalType
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CoachRepositoryTest {

    private lateinit var database: AppDatabase
    private lateinit var repository: CoachRepository
    private val testTrainerId = "trainer-unit-test-123"

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = CoachRepository(database)
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun seedTrainerData_createsRealisticClientRoster() = runBlocking {
        repository.seedInitialClientsForTrainer(testTrainerId)

        val clients = repository.getClients(testTrainerId).first()
        assertTrue("Trainer should have initial clients seeded", clients.size >= 4)

        val attentionClients = repository.getClientsNeedingAttention(testTrainerId).first()
        assertTrue("Trainer should have clients flagged for attention", attentionClients.isNotEmpty())

        val todaySessions = repository.getTodaySessions(testTrainerId).first()
        assertTrue("Trainer should have scheduled sessions for today", todaySessions.isNotEmpty())
    }

    @Test
    fun tenantIsolation_ensuresCrossTrainerDataIsNotLeaked() = runBlocking {
        val trainerA = "trainer-alpha"
        val trainerB = "trainer-beta"

        repository.seedInitialClientsForTrainer(trainerA)

        val clientsA = repository.getClients(trainerA).first()
        val clientsB = repository.getClients(trainerB).first()

        assertTrue("Trainer A should have clients", clientsA.isNotEmpty())
        assertTrue("Trainer B should have zero clients before seeding or creation", clientsB.isEmpty())
    }

    @Test
    fun stage2_consultationAndScreeningPersistCorrectly() = runBlocking {
        repository.seedInitialClientsForTrainer(testTrainerId)
        val clients = repository.getClients(testTrainerId).first()
        val sarah = clients.first { it.fullName == "Sarah Jenkins" }

        val consultation = repository.getConsultation(testTrainerId, sarah.id).first()
        assertNotNull("Sarah should have a seeded consultation", consultation)
        assertTrue("Consultation should be completed", consultation!!.isCompleted)
        assertEquals("Fat Loss & Lower Body Tone (Drop 4kg safely)", consultation.goals.primaryGoal)

        val screening = repository.getHealthScreening(testTrainerId, sarah.id).first()
        assertNotNull("Sarah should have a health screening", screening)
        assertTrue("Screening disclaimer should be acknowledged", screening!!.disclaimerAcknowledged)
    }

    @Test
    fun stage2_goalsAssessmentsAndTimelinePersistCorrectly() = runBlocking {
        repository.seedInitialClientsForTrainer(testTrainerId)
        val clients = repository.getClients(testTrainerId).first()
        val sarah = clients.first { it.fullName == "Sarah Jenkins" }

        val goals = repository.getGoalsForClient(testTrainerId, sarah.id).first()
        assertTrue("Sarah should have goals recorded", goals.isNotEmpty())

        val assessments = repository.getAssessmentsForClient(testTrainerId, sarah.id).first()
        assertTrue("Sarah should have assessment records", assessments.isNotEmpty())
        val baseline = repository.getBaselineAssessment(testTrainerId, sarah.id).first()
        assertNotNull("Sarah should have a baseline assessment", baseline)
        assertTrue("Baseline flag should be true", baseline!!.isBaseline)

        val measurements = repository.getMeasurementsForClient(testTrainerId, sarah.id).first()
        assertTrue("Sarah should have measurements logged", measurements.isNotEmpty())

        val timeline = repository.getTimelineEvents(testTrainerId, sarah.id).first()
        assertTrue("Sarah should have timeline milestones logged", timeline.isNotEmpty())
    }
}
