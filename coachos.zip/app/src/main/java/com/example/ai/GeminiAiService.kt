package com.example.ai

import com.example.BuildConfig
import com.example.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

class GeminiAiService : AIService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    override fun isConfigured(): Boolean {
        val key = runCatching { BuildConfig.GEMINI_API_KEY }.getOrNull()
        return !key.isNullOrBlank() && key != "MY_GEMINI_API_KEY"
    }

    override suspend fun analyzeClientBrain(
        client: Client,
        question: String,
        coachingMethod: CoachingMethod?
    ): AiResult<String> = withContext(Dispatchers.IO) {
        if (!isConfigured()) {
            return@withContext AiResult.NotConfigured()
        }

        val prompt = buildString {
            appendLine("You are CoachOS AI, an intelligent assistant for personal trainers.")
            appendLine("TRAINER'S COACHING METHOD:")
            if (coachingMethod != null) {
                appendLine("- Preferred Split: ${coachingMethod.preferredSplit}")
                appendLine("- Progression: ${coachingMethod.progressionPhilosophy}")
                appendLine("- Avoided: ${coachingMethod.avoidedExercises}")
                appendLine("- Communication: ${coachingMethod.clientCommunicationStyle}")
            } else {
                appendLine("- General evidence-based resistance and progressive overload.")
            }
            appendLine()
            appendLine("CLIENT DIGITAL TWIN DATA:")
            appendLine("- Name: ${client.fullName}")
            appendLine("- Primary Goal: ${client.primaryGoal} (${client.goalType.name})")
            appendLine("- Current Program: ${client.currentProgram}")
            appendLine("- Status: ${client.status.name}")
            appendLine("- Fitness Level: ${client.fitnessLevel.name}")
            appendLine("- Weight: Current ${client.currentWeightKg} kg, Target ${client.targetWeightKg} kg")
            appendLine("- Attendance Rate: ${client.attendanceRatePercent}%")
            appendLine("- Package Sessions: ${client.packageRemainingSessions} remaining of ${client.packageTotalSessions}")
            appendLine("- Last Workout: ${client.lastWorkoutDate}")
            appendLine("- Last Check-in: ${client.lastCheckInDate}")
            appendLine("- Training Readiness: ${client.readinessScore} (${client.readinessReason})")
            appendLine("- Needs Attention Flag: ${client.needsAttention} (${client.attentionReason ?: "None"})")
            appendLine("- Trainer Notes Summary: ${client.notesSummary}")
            appendLine()
            appendLine("TRAINER INQUIRY: \"$question\"")
            appendLine()
            appendLine("MANDATES:")
            appendLine("1. Be concise, actionable, and objective.")
            appendLine("2. Never invent missing facts. If data is missing, state 'Insufficient data'.")
            appendLine("3. Do not diagnose medical conditions. Recommend professional clearance if appropriate.")
            appendLine("4. Respect trainer authority; provide recommendations for trainer approval.")
        }

        callGeminiRest(prompt)
    }

    override suspend fun generateNextBestActions(
        client: Client,
        coachingMethod: CoachingMethod?
    ): AiResult<List<AiRecommendation>> = withContext(Dispatchers.IO) {
        if (!isConfigured()) {
            return@withContext AiResult.NotConfigured()
        }

        val prompt = buildString {
            appendLine("You are CoachOS AI. Given the following client data, output 1 to 2 Next Best Action recommendations for the trainer.")
            appendLine("CLIENT: ${client.fullName}")
            appendLine("Goal: ${client.primaryGoal}")
            appendLine("Readiness: ${client.readinessScore} - ${client.readinessReason}")
            appendLine("Attendance: ${client.attendanceRatePercent}%, Last workout: ${client.lastWorkoutDate}")
            appendLine("Package: ${client.packageRemainingSessions} / ${client.packageTotalSessions} remaining")
            appendLine("Attention reason: ${client.attentionReason ?: "None"}")
            appendLine()
            appendLine("Respond with a JSON array where each object has:")
            appendLine("\"recommendation\": string,")
            appendLine("\"reason\": string,")
            appendLine("\"supportingData\": [array of strings],")
            appendLine("\"confidence\": \"High\" | \"Medium\" | \"Low\",")
            appendLine("\"considerations\": [array of strings]")
            appendLine("Do NOT wrap in markdown ticks, only raw valid JSON array.")
        }

        when (val result = callGeminiRest(prompt)) {
            is AiResult.Success -> {
                val parsed = parseRecommendationsJson(result.data, client)
                if (parsed.isNotEmpty()) {
                    AiResult.Success(parsed)
                } else {
                    AiResult.Error("Could not parse recommendations from AI response.")
                }
            }
            is AiResult.NotConfigured -> AiResult.NotConfigured(result.message)
            is AiResult.Error -> AiResult.Error(result.message)
        }
    }

    override suspend fun generateSessionBrief(client: Client, sessionFocus: String): AiResult<String> =
        withContext(Dispatchers.IO) {
            if (!isConfigured()) {
                return@withContext AiResult.NotConfigured()
            }

            val prompt = """
            Prepare a 3-bullet "Today's Coaching Brief" for personal trainer before their session with ${client.fullName}.
            Session Focus: $sessionFocus
            Client Readiness: ${client.readinessScore} (${client.readinessReason})
            Attention Flag: ${client.attentionReason ?: "None"}
            Last workout: ${client.lastWorkoutDate}
            Provide:
            1. Key Technical / Intensity Focus
            2. Questions to check in with client
            3. Recommended precaution or load adjustment
            Keep it brief, professional, and gym-ready.
            """.trimIndent()

            callGeminiRest(prompt)
        }

    private fun callGeminiRest(promptText: String): AiResult<String> {
        val apiKey = BuildConfig.GEMINI_API_KEY
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

        return try {
            val jsonBody = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", promptText))
                        })
                    })
                })
            }

            val request = Request.Builder()
                .url(url)
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string()

            if (!response.isSuccessful || responseBody == null) {
                return AiResult.Error("AI request failed with code ${response.code}: ${response.message}")
            }

            val root = JSONObject(responseBody)
            val candidates = root.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val content = firstCandidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val text = parts?.optJSONObject(0)?.optString("text")

            if (!text.isNullOrBlank()) {
                AiResult.Success(text.trim())
            } else {
                AiResult.Error("Received empty response from AI service.")
            }
        } catch (e: Exception) {
            AiResult.Error("AI connection error: ${e.localizedMessage ?: e.message}")
        }
    }

    private fun parseRecommendationsJson(rawText: String, client: Client): List<AiRecommendation> {
        val list = mutableListOf<AiRecommendation>()
        try {
            val cleanJson = rawText.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val array = JSONArray(cleanJson)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val rec = obj.getString("recommendation")
                val reason = obj.getString("reason")
                val supporting = mutableListOf<String>()
                val supArr = obj.optJSONArray("supportingData")
                if (supArr != null) {
                    for (j in 0 until supArr.length()) supporting.add(supArr.getString(j))
                }
                val conf = obj.optString("confidence", "Medium")
                val considerations = mutableListOf<String>()
                val conArr = obj.optJSONArray("considerations")
                if (conArr != null) {
                    for (j in 0 until conArr.length()) considerations.add(conArr.getString(j))
                }

                list.add(
                    AiRecommendation(
                        id = UUID.randomUUID().toString(),
                        clientId = client.id,
                        clientName = client.fullName,
                        priority = ActionPriority.HIGH,
                        recommendation = rec,
                        reason = reason,
                        supportingData = supporting,
                        confidence = conf,
                        considerations = considerations,
                        status = ActionStatus.PENDING,
                        timestamp = System.currentTimeMillis()
                    )
                )
            }
        } catch (e: Exception) {
            // Ignore parse errors, fallback to empty
        }
        return list
    }
}
