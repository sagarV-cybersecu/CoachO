package com.example.ai

import com.example.data.repository.CoachRepository
import com.example.model.AiRecommendation
import com.example.model.Client
import kotlinx.coroutines.flow.firstOrNull

class ClientIntelligenceService(
    private val aiService: AIService,
    private val repository: CoachRepository
) {
    fun isAiConfigured(): Boolean = aiService.isConfigured()

    suspend fun queryClientBrain(client: Client, question: String): AiResult<String> {
        val coachingMethod = repository.getCoachingMethod(client.trainerId).firstOrNull()
        return aiService.analyzeClientBrain(client, question, coachingMethod)
    }

    suspend fun refreshNextBestActions(client: Client): AiResult<List<AiRecommendation>> {
        val coachingMethod = repository.getCoachingMethod(client.trainerId).firstOrNull()
        val result = aiService.generateNextBestActions(client, coachingMethod)
        if (result is AiResult.Success) {
            for (rec in result.data) {
                repository.insertAiRecommendation(rec)
            }
        }
        return result
    }

    suspend fun getTodaySessionBrief(client: Client, sessionFocus: String): AiResult<String> {
        return aiService.generateSessionBrief(client, sessionFocus)
    }
}
