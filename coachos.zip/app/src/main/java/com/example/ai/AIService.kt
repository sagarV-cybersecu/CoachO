package com.example.ai

import com.example.model.AiRecommendation
import com.example.model.Client
import com.example.model.CoachingMethod

sealed class AiResult<out T> {
    data class Success<T>(val data: T) : AiResult<T>()
    data class NotConfigured(val message: String = "AI service is not configured. Please set your GEMINI_API_KEY in Secrets.") : AiResult<Nothing>()
    data class Error(val message: String) : AiResult<Nothing>()
}

interface AIService {
    fun isConfigured(): Boolean
    suspend fun analyzeClientBrain(client: Client, question: String, coachingMethod: CoachingMethod?): AiResult<String>
    suspend fun generateNextBestActions(client: Client, coachingMethod: CoachingMethod?): AiResult<List<AiRecommendation>>
    suspend fun generateSessionBrief(client: Client, sessionFocus: String): AiResult<String>
}
