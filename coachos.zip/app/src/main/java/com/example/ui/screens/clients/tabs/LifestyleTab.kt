package com.example.ui.screens.clients.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.CoachRepository
import com.example.model.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun LifestyleTab(
    client: Client,
    trainerId: String,
    repository: CoachRepository,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val lifestyleState by repository.getLifestyle(trainerId, client.id).collectAsState(initial = null)

    var sleepHours by remember(lifestyleState) { mutableStateOf(lifestyleState?.sleepDurationHours?.toFloat() ?: 7.0f) }
    var sleepQuality by remember(lifestyleState) { mutableStateOf(lifestyleState?.sleepQualityRating ?: 3) }
    var stressRating by remember(lifestyleState) { mutableStateOf(lifestyleState?.stressRating ?: 3) }
    var recoveryRating by remember(lifestyleState) { mutableStateOf(lifestyleState?.recoveryRating ?: 3) }
    var stepsText by remember(lifestyleState) { mutableStateOf(lifestyleState?.dailyAverageSteps?.toString() ?: "8500") }
    var activityLevel by remember(lifestyleState) { mutableStateOf(lifestyleState?.activityLevel ?: "Moderately Active") }
    var workSchedule by remember(lifestyleState) { mutableStateOf(lifestyleState?.workScheduleType ?: "Standard Full-Time") }
    var hydrationText by remember(lifestyleState) { mutableStateOf(lifestyleState?.hydrationLiters?.toString() ?: "2.5") }
    var nutritionSummary by remember(lifestyleState) { mutableStateOf(lifestyleState?.nutritionHabitsSummary ?: "") }
    var trainingAvailability by remember(lifestyleState) { mutableStateOf(lifestyleState?.trainingAvailabilityDays ?: "Mon, Wed, Fri") }
    var lifestyleNotes by remember(lifestyleState) { mutableStateOf(lifestyleState?.lifestyleNotes ?: "") }
    var saveMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header & Save Action
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Lifestyle & Recovery Baseline", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                    Text("Daily stressors, circadian rhythm & habits", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }

                Button(
                    onClick = {
                        val lifestyle = ClientLifestyle(
                            clientId = client.id,
                            trainerId = trainerId,
                            sleepDurationHours = sleepHours.toDouble(),
                            sleepQualityRating = sleepQuality,
                            stressRating = stressRating,
                            activityLevel = activityLevel,
                            dailyAverageSteps = stepsText.toIntOrNull() ?: 8000,
                            workScheduleType = workSchedule,
                            recoveryRating = recoveryRating,
                            hydrationLiters = hydrationText.toDoubleOrNull() ?: 2.5,
                            nutritionHabitsSummary = nutritionSummary,
                            trainingAvailabilityDays = trainingAvailability,
                            lifestyleNotes = lifestyleNotes,
                            updatedAt = System.currentTimeMillis()
                        )
                        coroutineScope.launch {
                            repository.saveLifestyle(lifestyle)
                            saveMessage = "Lifestyle profile updated!"
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = Color.Black),
                    modifier = Modifier.testTag("btn_save_lifestyle")
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Save Profile", fontWeight = FontWeight.Bold)
                }
            }
        }

        if (saveMessage != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = EmeraldContainer.copy(alpha = 0.25f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(saveMessage ?: "", color = EmeraldPrimary, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        // Sleep & Circadian Rhythm
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, OnyxBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Bedtime, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Sleep Duration & Quality", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                }

                Text(
                    text = "Nightly Sleep Duration: ${String.format("%.1f", sleepHours)} Hours",
                    style = MaterialTheme.typography.bodyMedium,
                    color = CyanAccent,
                    fontWeight = FontWeight.SemiBold
                )
                Slider(
                    value = sleepHours,
                    onValueChange = { sleepHours = it },
                    valueRange = 4.0f..10.0f,
                    steps = 11,
                    colors = SliderDefaults.colors(thumbColor = CyanAccent, activeTrackColor = CyanAccent)
                )

                Text(
                    text = "Sleep Quality Rating (1 = Interrupted, 5 = Restorative): $sleepQuality / 5",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary
                )
                RatingSelector(selectedRating = sleepQuality, onSelect = { sleepQuality = it }, activeColor = CyanAccent)
            }
        }

        // Stress & Recovery Readiness
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, OnyxBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Speed, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Stress Demands & Subjective Recovery", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                }

                Text(
                    text = "Work & Life Stress (1 = Relaxed, 5 = Severe Burnout): $stressRating / 5",
                    style = MaterialTheme.typography.bodyMedium,
                    color = when (stressRating) {
                        1, 2 -> EmeraldPrimary
                        3 -> CyanAccent
                        4 -> AmberWarning
                        else -> CrimsonError
                    }
                )
                RatingSelector(selectedRating = stressRating, onSelect = { stressRating = it }, activeColor = AmberWarning)

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Systemic Recovery Capacity (1 = Exhausted, 5 = Fully Recovered): $recoveryRating / 5",
                    style = MaterialTheme.typography.bodyMedium,
                    color = EmeraldPrimary
                )
                RatingSelector(selectedRating = recoveryRating, onSelect = { recoveryRating = it }, activeColor = EmeraldPrimary)
            }
        }

        // Movement & Hydration Metrics
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, OnyxBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DirectionsWalk, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Daily Steps & Hydration", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = stepsText,
                        onValueChange = { stepsText = it },
                        label = { Text("Daily Average Steps") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                    OutlinedTextField(
                        value = hydrationText,
                        onValueChange = { hydrationText = it },
                        label = { Text("Hydration (Liters/Day)") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = activityLevel,
                        onValueChange = { activityLevel = it },
                        label = { Text("General Activity Level") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                    OutlinedTextField(
                        value = workSchedule,
                        onValueChange = { workSchedule = it },
                        label = { Text("Work Schedule") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                }
            }
        }

        // Nutrition Habits & Availability Schedule
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, OnyxBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Training Availability & Nutrition Habits", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                }

                OutlinedTextField(
                    value = trainingAvailability,
                    onValueChange = { trainingAvailability = it },
                    label = { Text("Target Weekly Training Days & Times") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )

                OutlinedTextField(
                    value = nutritionSummary,
                    onValueChange = { nutritionSummary = it },
                    label = { Text("Nutrition Habits Summary & Adherence Notes") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(90.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )

                OutlinedTextField(
                    value = lifestyleNotes,
                    onValueChange = { lifestyleNotes = it },
                    label = { Text("Coach Recovery Interventions & Homework") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(90.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )
            }
        }
    }
}

@Composable
private fun RatingSelector(
    selectedRating: Int,
    onSelect: (Int) -> Unit,
    activeColor: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        (1..5).forEach { rating ->
            val isSelected = selectedRating == rating
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isSelected) activeColor else OnyxSurfaceHigh)
                    .clickable { onSelect(rating) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = rating.toString(),
                    style = MaterialTheme.typography.titleSmall,
                    color = if (isSelected) Color.Black else TextSecondary,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
