package com.example.ui.screens.settings

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.CoachRepository
import com.example.data.session.SessionManager
import com.example.model.*
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    trainerId: String,
    repository: CoachRepository,
    sessionManager: SessionManager,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var trainerProfile by remember { mutableStateOf<TrainerUser?>(null) }
    var coachingMethod by remember { mutableStateOf<CoachingMethod?>(null) }
    val auditLogs by repository.getAuditLogs(trainerId).collectAsState(initial = emptyList())
    val clients by repository.getClients(trainerId).collectAsState(initial = emptyList())

    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showEditPhilosophyDialog by remember { mutableStateOf(false) }
    var showAuditLogsDialog by remember { mutableStateOf(false) }
    var showSignOutConfirm by remember { mutableStateOf(false) }

    LaunchedEffect(trainerId) {
        trainerProfile = repository.getTrainerById(trainerId)
        coachingMethod = repository.getCoachingMethod(trainerId).firstOrNull()
    }

    // Edit Profile Dialog
    if (showEditProfileDialog && trainerProfile != null) {
        var editName by remember { mutableStateOf(trainerProfile!!.displayName) }
        var editSpecialization by remember { mutableStateOf(trainerProfile!!.specialization) }
        var editBio by remember { mutableStateOf(trainerProfile!!.bio) }
        var editPhone by remember { mutableStateOf(trainerProfile!!.phone) }

        AlertDialog(
            onDismissRequest = { showEditProfileDialog = false },
            title = { Text("Edit Trainer Profile", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("Display Name") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                    OutlinedTextField(
                        value = editSpecialization,
                        onValueChange = { editSpecialization = it },
                        label = { Text("Specializations") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                    OutlinedTextField(
                        value = editPhone,
                        onValueChange = { editPhone = it },
                        label = { Text("Phone") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                    OutlinedTextField(
                        value = editBio,
                        onValueChange = { editBio = it },
                        label = { Text("Bio / Philosophy") },
                        modifier = Modifier.fillMaxWidth().height(90.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val updated = trainerProfile!!.copy(
                            displayName = editName,
                            specialization = editSpecialization,
                            bio = editBio,
                            phone = editPhone
                        )
                        coroutineScope.launch {
                            repository.updateTrainerProfile(updated)
                            trainerProfile = updated
                            showEditProfileDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = Color.Black)
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditProfileDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = OnyxSurface
        )
    }

    // Edit Philosophy Dialog
    if (showEditPhilosophyDialog && coachingMethod != null) {
        var split by remember { mutableStateOf(coachingMethod!!.preferredSplit) }
        var progression by remember { mutableStateOf(coachingMethod!!.progressionPhilosophy) }
        var avoided by remember { mutableStateOf(coachingMethod!!.avoidedExercises) }
        var repRanges by remember { mutableStateOf(coachingMethod!!.repRanges) }

        AlertDialog(
            onDismissRequest = { showEditPhilosophyDialog = false },
            title = { Text("Coaching Methodology Rules", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("AI uses these rules when drafting recommendations for you.", style = MaterialTheme.typography.bodySmall, color = CyanAccent)
                    OutlinedTextField(
                        value = split,
                        onValueChange = { split = it },
                        label = { Text("Preferred Workout Split") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                    OutlinedTextField(
                        value = progression,
                        onValueChange = { progression = it },
                        label = { Text("Progression Philosophy") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                    OutlinedTextField(
                        value = repRanges,
                        onValueChange = { repRanges = it },
                        label = { Text("Rep Ranges & Hypertrophy Targets") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                    OutlinedTextField(
                        value = avoided,
                        onValueChange = { avoided = it },
                        label = { Text("Avoided / High-Injury Exercises") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val updated = coachingMethod!!.copy(
                            preferredSplit = split,
                            progressionPhilosophy = progression,
                            avoidedExercises = avoided,
                            repRanges = repRanges
                        )
                        coroutineScope.launch {
                            repository.saveCoachingMethod(updated)
                            coachingMethod = updated
                            showEditPhilosophyDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = Color.Black)
                ) {
                    Text("Save Philosophy")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditPhilosophyDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = OnyxSurface
        )
    }

    // Audit Logs Dialog
    if (showAuditLogsDialog) {
        AlertDialog(
            onDismissRequest = { showAuditLogsDialog = false },
            title = { Text("Audit Trail (${auditLogs.size} events)", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                LazyColumn(modifier = Modifier.fillMaxWidth().height(320.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(auditLogs.take(20)) { log ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(log.action, style = MaterialTheme.typography.labelSmall, color = EmeraldPrimary, fontWeight = FontWeight.Bold)
                                    Text(log.entityType, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(log.details, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showAuditLogsDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = Color.Black)
                ) {
                    Text("Close")
                }
            },
            containerColor = OnyxSurface
        )
    }

    // Sign Out Confirmation
    if (showSignOutConfirm) {
        AlertDialog(
            onDismissRequest = { showSignOutConfirm = false },
            title = { Text("Sign Out of CoachOS AI?", color = TextPrimary) },
            text = { Text("Your local data is saved securely in the database. You can log back in at any time.", color = TextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        sessionManager.clearSession()
                        showSignOutConfirm = false
                        onSignOut()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonError, contentColor = Color.White)
                ) {
                    Text("Sign Out")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSignOutConfirm = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = OnyxSurface
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OnyxBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Coach Settings & SaaS",
                style = MaterialTheme.typography.headlineMedium,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "System configuration, coaching rules, and tenant security",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }

        // Trainer Profile Card
        item {
            SectionHeader(
                title = "Trainer Profile",
                actionLabel = "Edit",
                onActionClick = { showEditProfileDialog = true }
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, OnyxBorder, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(EmeraldContainer)
                                .border(1.5.dp, EmeraldPrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(28.dp))
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column {
                            Text(
                                text = trainerProfile?.displayName ?: "Coach",
                                style = MaterialTheme.typography.titleLarge,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = trainerProfile?.email ?: sessionManager.getTrainerEmail(),
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Specialization: ${trainerProfile?.specialization ?: "Strength & Conditioning"}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = trainerProfile?.bio ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Roster Capacity: ${clients.size} / ${trainerProfile?.clientCapacity ?: 25} active clients",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyanAccent,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Coaching Philosophy & Methodology Card
        item {
            SectionHeader(
                title = "Coaching Methodology",
                actionLabel = "Modify Rules",
                onActionClick = { showEditPhilosophyDialog = true }
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, OnyxBorder, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Preferred Split: ${coachingMethod?.preferredSplit ?: "Upper / Lower"}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Progression: ${coachingMethod?.progressionPhilosophy ?: "Double progression"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Avoided Moves: ${coachingMethod?.avoidedExercises ?: "None"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        // SaaS Architecture & Tenant Isolation Card
        item {
            SectionHeader(title = "Tenant Security & Architecture")

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, OnyxBorder, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Trainer Tenant ID", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                        Text(trainerId.take(12) + "...", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Isolation Boundary", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                        Text("Strict Tenant Partitioning Active", style = MaterialTheme.typography.labelSmall, color = EmeraldPrimary, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Database Engine", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                        Text("Room SQLite (Encrypted/Offline-First)", style = MaterialTheme.typography.labelSmall, color = TextPrimary)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { showAuditLogsDialog = true },
                            modifier = Modifier.weight(1f).height(38.dp),
                            shape = RoundedCornerShape(8.dp),
                            border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(OnyxBorder))
                        ) {
                            Icon(Icons.Default.History, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Audit Trail", color = TextPrimary, fontSize = 12.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                val jsonExport = buildString {
                                    append("{\"trainer\": \"${trainerProfile?.displayName}\", ")
                                    append("\"clientsCount\": ${clients.size}, ")
                                    append("\"clients\": [")
                                    append(clients.joinToString(",") { "{\"id\": \"${it.id}\", \"name\": \"${it.fullName}\", \"goal\": \"${it.primaryGoal}\"}" })
                                    append("]}")
                                }
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("CoachOS Client Data Export", jsonExport)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "Client data JSON copied to clipboard!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f).height(38.dp),
                            shape = RoundedCornerShape(8.dp),
                            border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(CyanAccent))
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Export JSON", color = CyanAccent, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Sign Out Button
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = { showSignOutConfirm = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_sign_out"),
                colors = ButtonDefaults.buttonColors(containerColor = OnyxSurfaceElevated, contentColor = CrimsonError),
                shape = RoundedCornerShape(12.dp),
                border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(CrimsonError.copy(alpha = 0.5f)))
            ) {
                Icon(Icons.Default.ExitToApp, contentDescription = null, tint = CrimsonError)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Sign Out of CoachOS", fontWeight = FontWeight.Bold)
            }
        }
    }
}
