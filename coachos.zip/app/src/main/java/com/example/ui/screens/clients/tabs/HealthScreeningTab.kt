package com.example.ui.screens.clients.tabs

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.CoachRepository
import com.example.model.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun HealthScreeningTab(
    client: Client,
    trainerId: String,
    repository: CoachRepository,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val screeningState by repository.getHealthScreening(trainerId, client.id).collectAsState(initial = null)

    var questions by remember(screeningState) {
        mutableStateOf(screeningState?.questions ?: HealthScreening.defaultScreeningQuestions())
    }
    var trainerNotes by remember(screeningState) {
        mutableStateOf(screeningState?.trainerNotes ?: "")
    }
    var selectedStatus by remember(screeningState) {
        mutableStateOf(screeningState?.reviewStatus ?: ScreeningReviewStatus.CLEAR)
    }
    var disclaimerAcknowledged by remember(screeningState) {
        mutableStateOf(screeningState?.disclaimerAcknowledged ?: true)
    }
    var saveMessage by remember { mutableStateOf<String?>(null) }

    // Auto calculate recommended status based on answers
    val anyYesAnswered = questions.any { it.answerYes }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Medical Disclaimer Banner (MANDATORY REQUIREMENT)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, AmberWarning.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
            colors = CardDefaults.cardColors(containerColor = AmberContainer.copy(alpha = 0.25f))
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.Top
            ) {
                Icon(
                    Icons.Default.HealthAndSafety,
                    contentDescription = null,
                    tint = AmberWarning,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Medical Disclaimer & Legal Safety",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color(0xFFFDE68A),
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "This Physical Activity Readiness Questionnaire (PAR-Q) is designed exclusively for exercise readiness screening by qualified fitness professionals. It does NOT constitute medical diagnosis, treatment, or clinical advice.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // Status Card & Quick Action
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, OnyxBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Screening Clearance Status", style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text(
                            text = if (anyYesAnswered) "Follow-up required (affirmative responses present)" else "No health flags reported",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (anyYesAnswered) AmberWarning else EmeraldPrimary
                        )
                    }

                    Button(
                        onClick = {
                            val screening = HealthScreening(
                                clientId = client.id,
                                trainerId = trainerId,
                                date = "Today",
                                reviewStatus = selectedStatus,
                                questions = questions,
                                trainerNotes = trainerNotes,
                                disclaimerAcknowledged = disclaimerAcknowledged,
                                updatedAt = System.currentTimeMillis()
                            )
                            coroutineScope.launch {
                                repository.saveHealthScreening(screening)
                                saveMessage = "PAR-Q Health Screening saved successfully!"
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = Color.Black),
                        modifier = Modifier.testTag("btn_save_screening")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save Status", fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Status Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ScreeningReviewStatus.entries.forEach { status ->
                        val isSelected = selectedStatus == status
                        val chipColor = when (status) {
                            ScreeningReviewStatus.CLEAR -> EmeraldPrimary
                            ScreeningReviewStatus.REVIEW_REQUIRED -> AmberWarning
                            ScreeningReviewStatus.PROFESSIONAL_CLEARANCE_RECOMMENDED -> CrimsonError
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) chipColor.copy(alpha = 0.2f) else OnyxSurfaceHigh)
                                .border(1.dp, if (isSelected) chipColor else Color.Transparent, RoundedCornerShape(10.dp))
                                .clickable { selectedStatus = status }
                                .padding(vertical = 10.dp, horizontal = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = status.label,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) chipColor else TextSecondary,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }

        if (saveMessage != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = EmeraldContainer.copy(alpha = 0.25f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(saveMessage ?: "", color = EmeraldPrimary, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        // Questions List
        Text(
            text = "Physical Activity Readiness Questionnaire (PAR-Q+)",
            style = MaterialTheme.typography.titleMedium,
            color = TextPrimary,
            fontWeight = FontWeight.Bold
        )

        questions.forEachIndexed { index, question ->
            ScreeningQuestionCard(
                index = index + 1,
                question = question,
                onAnswerChanged = { yes ->
                    questions = questions.mapIndexed { idx, q ->
                        if (idx == index) {
                            val updated = q.copy(answerYes = yes)
                            if (yes && selectedStatus == ScreeningReviewStatus.CLEAR) {
                                selectedStatus = ScreeningReviewStatus.REVIEW_REQUIRED
                            }
                            updated
                        } else q
                    }
                },
                onFollowUpChanged = { details ->
                    questions = questions.mapIndexed { idx, q ->
                        if (idx == index) q.copy(followUpAnswer = details) else q
                    }
                },
                onNotesChanged = { notes ->
                    questions = questions.mapIndexed { idx, q ->
                        if (idx == index) q.copy(notes = notes) else q
                    }
                }
            )
        }

        // Trainer Assessment Notes
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, OnyxBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AssignmentInd, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Coach Review & Modifications", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                }
                Text(
                    text = "Detail specific exercise accommodations, regressions, or warm-up protocols based on affirmative answers.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                OutlinedTextField(
                    value = trainerNotes,
                    onValueChange = { trainerNotes = it },
                    placeholder = { Text("e.g. Cleared for resistance training; avoid heavy axial spinal loading; prescribe box squats.") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )
            }
        }
    }
}

@Composable
private fun ScreeningQuestionCard(
    index: Int,
    question: ScreeningQuestion,
    onAnswerChanged: (Boolean) -> Unit,
    onFollowUpChanged: (String) -> Unit,
    onNotesChanged: (String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (question.answerYes) AmberWarning.copy(alpha = 0.5f) else OnyxBorder,
                RoundedCornerShape(14.dp)
            ),
        colors = CardDefaults.cardColors(
            containerColor = if (question.answerYes) OnyxSurfaceElevated else OnyxSurface
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "$index.",
                        style = MaterialTheme.typography.titleSmall,
                        color = CyanAccent,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = question.questionText,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                        lineHeight = 20.sp
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                // Yes / No Toggle Buttons
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = { onAnswerChanged(false) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (!question.answerYes) EmeraldPrimary.copy(alpha = 0.2f) else OnyxSurfaceHigh,
                            contentColor = if (!question.answerYes) EmeraldPrimary else TextSecondary
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("NO", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    Button(
                        onClick = { onAnswerChanged(true) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (question.answerYes) AmberWarning else OnyxSurfaceHigh,
                            contentColor = if (question.answerYes) Color.Black else TextSecondary
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("YES", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            // Conditional Follow-up details if "YES"
            AnimatedVisibility(visible = question.answerYes) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(OnyxSurfaceHigh)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "⚠️ Follow-up Details: ${question.followUpPrompt}",
                        style = MaterialTheme.typography.labelMedium,
                        color = AmberWarning,
                        fontWeight = FontWeight.SemiBold
                    )
                    OutlinedTextField(
                        value = question.followUpAnswer,
                        onValueChange = onFollowUpChanged,
                        label = { Text("Client explanation & medical history") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                    OutlinedTextField(
                        value = question.notes,
                        onValueChange = onNotesChanged,
                        label = { Text("Coach adaptation notes") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                }
            }
        }
    }
}
