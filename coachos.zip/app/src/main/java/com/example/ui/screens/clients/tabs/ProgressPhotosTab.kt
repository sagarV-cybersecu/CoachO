package com.example.ui.screens.clients.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.CoachRepository
import com.example.model.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressPhotosTab(
    client: Client,
    trainerId: String,
    repository: CoachRepository,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val photos: List<ProgressPhoto> by repository.getProgressPhotosForClient(trainerId, client.id).collectAsState(initial = emptyList())

    var showAddDialog by remember { mutableStateOf(false) }
    var selectedCategoryFilter by remember { mutableStateOf<PhotoCategory?>(null) }
    var viewingPhoto by remember { mutableStateOf<ProgressPhoto?>(null) }
    var photoToDelete by remember { mutableStateOf<ProgressPhoto?>(null) }

    // Comparison Mode
    var comparisonMode by remember { mutableStateOf(false) }
    var comparePhotoA by remember { mutableStateOf<ProgressPhoto?>(null) }
    var comparePhotoB by remember { mutableStateOf<ProgressPhoto?>(null) }

    val filteredPhotos = photos.filter {
        selectedCategoryFilter == null || it.category == selectedCategoryFilter
    }

    // Add Photo Dialog
    if (showAddDialog) {
        var category by remember { mutableStateOf(PhotoCategory.FRONT) }
        var date by remember { mutableStateOf("2026-09-08") }
        var notes by remember { mutableStateOf("") }
        var uriText by remember { mutableStateOf("https://images.unsplash.com/photo-1517838277536-f5f99be501cd") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Progress Photo Entry", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Angle / Pose Category", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        PhotoCategory.entries.forEach { cat ->
                            FilterChip(
                                selected = category == cat,
                                onClick = { category = cat },
                                label = { Text(cat.label, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CyanContainer,
                                    selectedLabelColor = CyanAccent,
                                    containerColor = OnyxSurfaceHigh,
                                    labelColor = TextSecondary
                                )
                            )
                        }
                    }

                    OutlinedTextField(
                        value = date,
                        onValueChange = { date = it },
                        label = { Text("Date (YYYY-MM-DD)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Lighting, Posture & Coach Notes") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            repository.addProgressPhoto(
                                ProgressPhoto(
                                    id = UUID.randomUUID().toString(),
                                    clientId = client.id,
                                    trainerId = trainerId,
                                    photoUri = uriText,
                                    category = category,
                                    customCategoryName = null,
                                    date = date.trim(),
                                    notes = notes.trim(),
                                    createdAt = System.currentTimeMillis()
                                )
                            )
                            showAddDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = Color.Black)
                ) {
                    Text("Save Photo Record", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = OnyxSurface
        )
    }

    // Delete Confirmation
    if (photoToDelete != null) {
        val target = photoToDelete!!
        AlertDialog(
            onDismissRequest = { photoToDelete = null },
            title = { Text("Delete Photo?", color = TextPrimary) },
            text = { Text("Remove photo taken on ${target.date}?", color = TextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            repository.deleteProgressPhoto(trainerId, target.id)
                            photoToDelete = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonError, contentColor = Color.White)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { photoToDelete = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = OnyxSurface
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Action Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Visual Transformation", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                Text("${photos.size} progress milestones recorded", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        comparisonMode = !comparisonMode
                        if (!comparisonMode) {
                            comparePhotoA = null
                            comparePhotoB = null
                        }
                    },
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (comparisonMode) CyanAccent else TextSecondary
                    )
                ) {
                    Icon(Icons.Default.Compare, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (comparisonMode) "Done" else "Compare")
                }

                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = Color.Black),
                    modifier = Modifier.testTag("btn_add_photo")
                ) {
                    Icon(Icons.Default.AddAPhoto, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Upload", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Side-by-Side Comparison Box if in comparison mode
        if (comparisonMode) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyanAccent.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
                colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Side-by-Side Visual Comparison", style = MaterialTheme.typography.titleSmall, color = CyanAccent, fontWeight = FontWeight.Bold)
                    Text("Tap two photo cards below to inspect physical transformation", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(130.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(OnyxSurfaceHigh)
                                .border(1.dp, OnyxBorder, RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (comparePhotoA != null) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.Photo, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(32.dp))
                                    Text("Photo A: ${comparePhotoA!!.date}", style = MaterialTheme.typography.labelSmall, color = TextPrimary)
                                    Text(comparePhotoA!!.category.label, style = MaterialTheme.typography.bodySmall, color = CyanAccent)
                                }
                            } else {
                                Text("Select Photo 1", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(130.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(OnyxSurfaceHigh)
                                .border(1.dp, OnyxBorder, RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (comparePhotoB != null) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.Photo, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(32.dp))
                                    Text("Photo B: ${comparePhotoB!!.date}", style = MaterialTheme.typography.labelSmall, color = TextPrimary)
                                    Text(comparePhotoB!!.category.label, style = MaterialTheme.typography.bodySmall, color = EmeraldPrimary)
                                }
                            } else {
                                Text("Select Photo 2", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }

        // Category Filter Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FilterChip(
                selected = selectedCategoryFilter == null,
                onClick = { selectedCategoryFilter = null },
                label = { Text("All (${photos.size})") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = EmeraldContainer,
                    selectedLabelColor = EmeraldPrimary,
                    containerColor = OnyxSurfaceElevated,
                    labelColor = TextSecondary
                )
            )
            PhotoCategory.entries.forEach { cat ->
                val count = photos.count { it.category == cat }
                if (count > 0) {
                    FilterChip(
                        selected = selectedCategoryFilter == cat,
                        onClick = { selectedCategoryFilter = cat },
                        label = { Text("${cat.label} ($count)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyanContainer,
                            selectedLabelColor = CyanAccent,
                            containerColor = OnyxSurfaceElevated,
                            labelColor = TextSecondary
                        )
                    )
                }
            }
        }

        // Photos Grid
        if (filteredPhotos.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.PhotoCamera, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No progress photos yet", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Text("Capture baseline and follow-up transformation photos", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredPhotos, key = { it.id }) { photo ->
                    val isSelectedA = comparePhotoA?.id == photo.id
                    val isSelectedB = comparePhotoB?.id == photo.id

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.5.dp,
                                when {
                                    isSelectedA -> CyanAccent
                                    isSelectedB -> EmeraldPrimary
                                    else -> OnyxBorder
                                },
                                RoundedCornerShape(14.dp)
                            )
                            .clickable {
                                if (comparisonMode) {
                                    if (comparePhotoA == null) {
                                        comparePhotoA = photo
                                    } else if (comparePhotoB == null && comparePhotoA?.id != photo.id) {
                                        comparePhotoB = photo
                                    } else {
                                        comparePhotoA = photo
                                        comparePhotoB = null
                                    }
                                } else {
                                    viewingPhoto = photo
                                }
                            },
                        colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(130.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(OnyxSurfaceHigh),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = if (isSelectedA) CyanAccent else if (isSelectedB) EmeraldPrimary else TextSecondary,
                                        modifier = Modifier.size(48.dp)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(photo.category.label, style = MaterialTheme.typography.labelSmall, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                                }

                                IconButton(
                                    onClick = { photoToDelete = photo },
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .size(28.dp)
                                ) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = CrimsonError, modifier = Modifier.size(16.dp))
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(photo.date, style = MaterialTheme.typography.labelSmall, color = CyanAccent, fontWeight = FontWeight.Bold)
                                Text(photo.category.name, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }

                            if (photo.notes.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(photo.notes, style = MaterialTheme.typography.bodySmall, color = TextSecondary, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
    }
}
