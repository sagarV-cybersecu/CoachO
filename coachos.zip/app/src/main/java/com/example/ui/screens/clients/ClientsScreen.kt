package com.example.ui.screens.clients

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.CoachRepository
import com.example.model.Client
import com.example.model.ClientStatus
import com.example.model.PrimaryGoalType
import com.example.ui.components.ClientListItemCard
import com.example.ui.components.EmptyStateView
import com.example.ui.components.SearchBarField
import com.example.ui.theme.*

enum class ClientFilter {
    ALL,
    NEEDS_ATTENTION,
    ACTIVE,
    ON_HOLD
}

enum class ClientSort {
    LAST_UPDATED,
    ATTENDANCE_HIGH,
    NAME_AZ
}

@Composable
fun ClientsScreen(
    trainerId: String,
    repository: CoachRepository,
    onClientClick: (String) -> Unit,
    onAddClientClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val clients by repository.getClients(trainerId).collectAsState(initial = emptyList())

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(ClientFilter.ALL) }
    var selectedSort by remember { mutableStateOf(ClientSort.LAST_UPDATED) }
    var showSortMenu by remember { mutableStateOf(false) }

    val filteredClients = remember(clients, searchQuery, selectedFilter, selectedSort) {
        clients.filter { client ->
            val matchesQuery = searchQuery.isBlank() ||
                    client.fullName.contains(searchQuery, ignoreCase = true) ||
                    client.primaryGoal.contains(searchQuery, ignoreCase = true) ||
                    client.email.contains(searchQuery, ignoreCase = true) ||
                    client.phone.contains(searchQuery, ignoreCase = true)

            val matchesFilter = when (selectedFilter) {
                ClientFilter.ALL -> true
                ClientFilter.NEEDS_ATTENTION -> client.needsAttention
                ClientFilter.ACTIVE -> client.status == ClientStatus.ACTIVE
                ClientFilter.ON_HOLD -> client.status == ClientStatus.ON_HOLD
            }

            matchesQuery && matchesFilter
        }.sortedWith { a, b ->
            when (selectedSort) {
                ClientSort.LAST_UPDATED -> b.updatedAt.compareTo(a.updatedAt)
                ClientSort.ATTENDANCE_HIGH -> b.attendanceRatePercent.compareTo(a.attendanceRatePercent)
                ClientSort.NAME_AZ -> a.fullName.compareTo(b.fullName, ignoreCase = true)
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = OnyxBackground,
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddClientClick,
                containerColor = EmeraldPrimary,
                contentColor = Color.Black,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .padding(bottom = 72.dp)
                    .testTag("fab_add_client")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = "Add Client")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Add Client", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Header with Title & Sort
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Client Roster",
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${filteredClients.size} of ${clients.size} clients displayed",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }

                Box {
                    IconButton(onClick = { showSortMenu = true }) {
                        Icon(
                            imageVector = Icons.Default.Sort,
                            contentDescription = "Sort clients",
                            tint = CyanAccent
                        )
                    }

                    DropdownMenu(
                        expanded = showSortMenu,
                        onDismissRequest = { showSortMenu = false },
                        modifier = Modifier.background(OnyxSurfaceElevated)
                    ) {
                        DropdownMenuItem(
                            text = { Text("Recently Updated", color = TextPrimary) },
                            onClick = {
                                selectedSort = ClientSort.LAST_UPDATED
                                showSortMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Highest Attendance", color = TextPrimary) },
                            onClick = {
                                selectedSort = ClientSort.ATTENDANCE_HIGH
                                showSortMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Alphabetical (A-Z)", color = TextPrimary) },
                            onClick = {
                                selectedSort = ClientSort.NAME_AZ
                                showSortMenu = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Search Bar
            SearchBarField(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                placeholder = "Search by client name, goal, phone, or email..."
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedFilter == ClientFilter.ALL,
                    onClick = { selectedFilter = ClientFilter.ALL },
                    label = { Text("All (${clients.size})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EmeraldContainer,
                        selectedLabelColor = EmeraldPrimary,
                        containerColor = OnyxSurfaceElevated,
                        labelColor = TextSecondary
                    )
                )

                val attentionCount = clients.count { it.needsAttention }
                FilterChip(
                    selected = selectedFilter == ClientFilter.NEEDS_ATTENTION,
                    onClick = { selectedFilter = ClientFilter.NEEDS_ATTENTION },
                    label = { Text("Needs Attention ($attentionCount)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = AmberContainer,
                        selectedLabelColor = AmberWarning,
                        containerColor = OnyxSurfaceElevated,
                        labelColor = TextSecondary
                    )
                )

                val activeCount = clients.count { it.status == ClientStatus.ACTIVE }
                FilterChip(
                    selected = selectedFilter == ClientFilter.ACTIVE,
                    onClick = { selectedFilter = ClientFilter.ACTIVE },
                    label = { Text("Active ($activeCount)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CyanContainer,
                        selectedLabelColor = CyanAccent,
                        containerColor = OnyxSurfaceElevated,
                        labelColor = TextSecondary
                    )
                )

                val onHoldCount = clients.count { it.status == ClientStatus.ON_HOLD }
                FilterChip(
                    selected = selectedFilter == ClientFilter.ON_HOLD,
                    onClick = { selectedFilter = ClientFilter.ON_HOLD },
                    label = { Text("On Hold ($onHoldCount)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = OnyxSurfaceHigh,
                        selectedLabelColor = TextPrimary,
                        containerColor = OnyxSurfaceElevated,
                        labelColor = TextSecondary
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Client Cards List
            if (filteredClients.isEmpty()) {
                EmptyStateView(
                    title = if (searchQuery.isNotEmpty()) "No clients match \"$searchQuery\"" else "No clients found",
                    message = if (searchQuery.isNotEmpty()) "Try clearing search or filters" else "Add your first client to begin tracking workouts and AI insights.",
                    icon = Icons.Default.PersonSearch,
                    actionButtonText = if (searchQuery.isEmpty()) "Add New Client" else null,
                    onActionClick = onAddClientClick
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredClients, key = { it.id }) { client ->
                        ClientListItemCard(
                            client = client,
                            onClick = { onClientClick(client.id) }
                        )
                    }
                }
            }
        }
    }
}
