package com.example.ui.screens.clients.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.CoachRepository
import com.example.model.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssessmentsTab(
    client: Client,
    trainerId: String,
    repository: CoachRepository,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val assessments by repository.getAssessmentsForClient(trainerId, client.id).collectAsState(initial = emptyList())
    val baselineSession = assessments.firstOrNull { it.isBaseline }

    var showAddDialog by remember { mutableStateOf(false) }
    var viewingSession by remember { mutableStateOf<AssessmentSession?>(null) }
    var sessionToDelete by remember { mutableStateOf<AssessmentSession?>(null) }

    // New Assessment Dialog
    if (showAddDialog) {
        var title by remember { mutableStateOf("Movement & Performance Evaluation") }
        var date by remember { mutableStateOf("2026-09-08") }
        var isBaseline by remember { mutableStateOf(assessments.isEmpty()) }
        var summaryObservations by remember { mutableStateOf("") }
        var trainerRecommendations by remember { mutableStateOf("") }

        // Test items
        var testItems by remember {
            mutableStateOf(
                listOf(
                    AssessmentItem(id = UUID.randomUUID().toString(), category = AssessmentCategory.MOVEMENT_OBSERVATIONS, testName = "Overhead Squat", resultValue = "Knee valgus, forward lean", unit = "observation", baselineValue = baselineSession?.items?.firstOrNull { it.testName == "Overhead Squat" }?.resultValue, notes = "Tight calves/ankles"),
                    AssessmentItem(id = UUID.randomUUID().toString(), category = AssessmentCategory.STRENGTH, testName = "Goblet Squat (8 reps)", resultValue = "16", unit = "kg", baselineValue = baselineSession?.items?.firstOrNull { it.testName.contains("Goblet") }?.resultValue, notes = "Solid depth"),
                    AssessmentItem(id = UUID.randomUUID().toString(), category = AssessmentCategory.ENDURANCE, testName = "Plank Hold", resultValue = "45", unit = "sec", baselineValue = baselineSession?.items?.firstOrNull { it.testName.contains("Plank") }?.resultValue, notes = "Lumbar dropped at 40s"),
                    AssessmentItem(id = UUID.randomUUID().toString(), category = AssessmentCategory.MOBILITY, testName = "Shoulder Mobility", resultValue = "Good", unit = "grade", baselineValue = null, notes = "Right side slightly tighter")
                )
            )
        }

        var newTestName by remember { mutableStateOf("") }
        var newTestValue by remember { mutableStateOf("") }
        var newTestUnit by remember { mutableStateOf("") }
        var newTestCategory by remember { mutableStateOf(AssessmentCategory.STRENGTH) }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Record Assessment Session", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Session Title") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = date,
                            onValueChange = { date = it },
                            label = { Text("Date (YYYY-MM-DD)") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                        )
                    }

                    // Is Baseline Toggle
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isBaseline) AmberContainer.copy(alpha = 0.3f) else OnyxSurfaceHigh)
                            .clickable { isBaseline = !isBaseline }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = isBaseline,
                            onCheckedChange = { isBaseline = it },
                            colors = CheckboxDefaults.colors(checkedColor = AmberWarning)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text("Designate as Client Baseline", style = MaterialTheme.typography.bodyMedium, color = if (isBaseline) AmberWarning else TextPrimary, fontWeight = FontWeight.SemiBold)
                            Text("All future assessments will benchmark against this session", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                    }

                    Divider(color = OnyxBorder)

                    Text("Screening & Test Battery", style = MaterialTheme.typography.titleSmall, color = CyanAccent, fontWeight = FontWeight.Bold)

                    testItems.forEachIndexed { idx, item ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = OnyxSurfaceHigh)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(item.testName, style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                                    IconButton(
                                        onClick = { testItems = testItems.filterIndexed { i, _ -> i != idx } },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Close, contentDescription = "Remove", tint = CrimsonError, modifier = Modifier.size(16.dp))
                                    }
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = item.resultValue,
                                        onValueChange = { newVal ->
                                            testItems = testItems.mapIndexed { i, old -> if (i == idx) old.copy(resultValue = newVal) else old }
                                        },
                                        label = { Text("Result") },
                                        modifier = Modifier.weight(1f),
                                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                                    )
                                    OutlinedTextField(
                                        value = item.unit,
                                        onValueChange = { newUnit ->
                                            testItems = testItems.mapIndexed { i, old -> if (i == idx) old.copy(unit = newUnit) else old }
                                        },
                                        label = { Text("Unit") },
                                        modifier = Modifier.weight(1f),
                                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                                    )
                                }

                                if (item.baselineValue != null) {
                                    Text("Baseline was: ${item.baselineValue} ${item.unit}", style = MaterialTheme.typography.labelSmall, color = EmeraldPrimary)
                                }
                            }
                        }
                    }

                    // Add Custom Test Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newTestName,
                            onValueChange = { newTestName = it },
                            placeholder = { Text("Add test (e.g. 1RM Deadlift)") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                        )
                        IconButton(
                            onClick = {
                                if (newTestName.isNotBlank()) {
                                    testItems = testItems + AssessmentItem(
                                        id = UUID.randomUUID().toString(),
                                        category = newTestCategory,
                                        testName = newTestName.trim(),
                                        resultValue = "",
                                        unit = "",
                                        baselineValue = null,
                                        notes = ""
                                    )
                                    newTestName = ""
                                }
                            }
                        ) {
                            Icon(Icons.Default.AddCircle, contentDescription = "Add Test", tint = CyanAccent)
                        }
                    }

                    Divider(color = OnyxBorder)

                    OutlinedTextField(
                        value = summaryObservations,
                        onValueChange = { summaryObservations = it },
                        label = { Text("Overall Observations") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )

                    OutlinedTextField(
                        value = trainerRecommendations,
                        onValueChange = { trainerRecommendations = it },
                        label = { Text("Actionable Recommendations") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val session = AssessmentSession(
                            id = UUID.randomUUID().toString(),
                            clientId = client.id,
                            trainerId = trainerId,
                            title = title.trim(),
                            date = date.trim(),
                            isBaseline = isBaseline,
                            selectedCategories = testItems.map { it.category }.distinct(),
                            items = testItems,
                            summaryObservations = summaryObservations.trim(),
                            trainerRecommendations = trainerRecommendations.trim(),
                            createdAt = System.currentTimeMillis()
                        )
                        coroutineScope.launch {
                            repository.saveAssessmentSession(session)
                            showAddDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = Color.Black)
                ) {
                    Text("Save Assessment", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = OnyxSurface
        )
    }

    // Delete confirmation
    if (sessionToDelete != null) {
        val target = sessionToDelete!!
        AlertDialog(
            onDismissRequest = { sessionToDelete = null },
            title = { Text("Delete Assessment?", color = TextPrimary) },
            text = { Text("Are you sure you want to remove '${target.title}' from history?", color = TextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            repository.deleteAssessmentSession(trainerId, target.id)
                            sessionToDelete = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonError, contentColor = Color.White)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { sessionToDelete = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = OnyxSurface
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Card with Baseline Status
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    1.dp,
                    if (baselineSession != null) AmberWarning.copy(alpha = 0.6f) else OnyxBorder,
                    RoundedCornerShape(16.dp)
                ),
            colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Analytics,
                            contentDescription = null,
                            tint = if (baselineSession != null) AmberWarning else CyanAccent,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Assessments & Baselines", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (baselineSession != null) "Baseline established: ${baselineSession.title} (${baselineSession.date})" else "No baseline established yet",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (baselineSession != null) AmberWarning else TextSecondary
                    )
                }

                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = Color.Black),
                    modifier = Modifier.testTag("btn_record_assessment")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("New Test", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Sessions List
        if (assessments.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.FitnessCenter, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No assessments recorded yet", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Text("Conduct movement & strength screenings to track progress", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(assessments, key = { it.id }) { session ->
                    AssessmentSessionCard(
                        session = session,
                        onDelete = { sessionToDelete = session },
                        onToggleBaseline = {
                            coroutineScope.launch {
                                repository.setSessionAsBaseline(trainerId, client.id, session.id)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun AssessmentSessionCard(
    session: AssessmentSession,
    onDelete: () -> Unit,
    onToggleBaseline: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (session.isBaseline) AmberWarning.copy(alpha = 0.8f) else OnyxBorder,
                RoundedCornerShape(16.dp)
            ),
        colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (session.isBaseline) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(AmberContainer)
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text("★ BASELINE", style = MaterialTheme.typography.labelSmall, color = AmberWarning, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                    }

                    Text(
                        text = session.date,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (!session.isBaseline) {
                        TextButton(onClick = onToggleBaseline) {
                            Text("Set as Baseline", fontSize = 12.sp, color = CyanAccent)
                        }
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = CrimsonError, modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = session.title,
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Test Battery Results
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(OnyxSurface)
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                session.items.forEach { item ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(item.testName, style = MaterialTheme.typography.bodyMedium, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                            if (item.notes.isNotBlank()) {
                                Text(item.notes, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${item.resultValue} ${item.unit}".trim(),
                                style = MaterialTheme.typography.bodyMedium,
                                color = EmeraldPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            if (item.baselineValue != null && !session.isBaseline) {
                                Text("Baseline: ${item.baselineValue}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                    }
                }
            }

            if (session.summaryObservations.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text("Observations:", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Text(session.summaryObservations, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
            }

            if (session.trainerRecommendations.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text("Recommendations:", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                Text(session.trainerRecommendations, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
            }
        }
    }
}
