package com.example.ui.screens.clients.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.CoachRepository
import com.example.model.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoalsTab(
    client: Client,
    trainerId: String,
    repository: CoachRepository,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val goals by repository.getGoalsForClient(trainerId, client.id).collectAsState(initial = emptyList())

    var showAddDialog by remember { mutableStateOf(false) }
    var editingGoal by remember { mutableStateOf<ClientGoal?>(null) }
    var goalToDelete by remember { mutableStateOf<ClientGoal?>(null) }
    var selectedCategoryFilter by remember { mutableStateOf<GoalCategory?>(null) }

    val filteredGoals = goals.filter { goal ->
        selectedCategoryFilter == null || goal.category == selectedCategoryFilter
    }

    // Add / Edit Goal Dialog
    if (showAddDialog || editingGoal != null) {
        val targetGoal = editingGoal
        var title by remember { mutableStateOf(targetGoal?.title ?: "") }
        var isPrimary by remember { mutableStateOf(targetGoal?.isPrimary ?: (goals.none { it.isPrimary })) }
        var category by remember { mutableStateOf(targetGoal?.category ?: GoalCategory.FAT_LOSS) }
        var targetDate by remember { mutableStateOf(targetGoal?.targetDate ?: "2026-12-31") }
        var targetMetric by remember { mutableStateOf(targetGoal?.targetMetric ?: "Weight (kg)") }
        var startingValue by remember { mutableStateOf(targetGoal?.startingValue ?: "${client.currentWeightKg} kg") }
        var currentValue by remember { mutableStateOf(targetGoal?.currentValue ?: "${client.currentWeightKg} kg") }
        var targetValue by remember { mutableStateOf(targetGoal?.targetValue ?: "${client.targetWeightKg ?: 65.0} kg") }
        var status by remember { mutableStateOf(targetGoal?.status ?: GoalStatus.IN_PROGRESS) }
        var notes by remember { mutableStateOf(targetGoal?.notes ?: "") }

        AlertDialog(
            onDismissRequest = {
                showAddDialog = false
                editingGoal = null
            },
            title = {
                Text(
                    text = if (targetGoal != null) "Edit Goal" else "Add New Client Goal",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Goal Title") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )

                    // Primary Goal Checkbox
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(OnyxSurfaceHigh)
                            .clickable { isPrimary = !isPrimary }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = isPrimary,
                            onCheckedChange = { isPrimary = it },
                            colors = CheckboxDefaults.colors(checkedColor = CyanAccent)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Mark as Primary Target Goal", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    }

                    // Category Selector
                    Text("Category", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        GoalCategory.entries.forEach { cat ->
                            FilterChip(
                                selected = category == cat,
                                onClick = { category = cat },
                                label = { Text(cat.label, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CyanContainer,
                                    selectedLabelColor = CyanAccent,
                                    containerColor = OnyxSurfaceHigh,
                                    labelColor = TextSecondary
                                )
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = startingValue,
                            onValueChange = { startingValue = it },
                            label = { Text("Starting") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                        )
                        OutlinedTextField(
                            value = currentValue,
                            onValueChange = { currentValue = it },
                            label = { Text("Current") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                        )
                        OutlinedTextField(
                            value = targetValue,
                            onValueChange = { targetValue = it },
                            label = { Text("Target") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = targetDate,
                            onValueChange = { targetDate = it },
                            label = { Text("Target Date") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                        )
                        OutlinedTextField(
                            value = targetMetric,
                            onValueChange = { targetMetric = it },
                            label = { Text("Metric") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                        )
                    }

                    // Status
                    Text("Current Status", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        GoalStatus.entries.forEach { stat ->
                            FilterChip(
                                selected = status == stat,
                                onClick = { status = stat },
                                label = { Text(stat.label, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EmeraldContainer,
                                    selectedLabelColor = EmeraldPrimary,
                                    containerColor = OnyxSurfaceHigh,
                                    labelColor = TextSecondary
                                )
                            )
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Action Steps & Notes") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (title.isNotBlank()) {
                            coroutineScope.launch {
                                val goal = ClientGoal(
                                    id = targetGoal?.id ?: UUID.randomUUID().toString(),
                                    clientId = client.id,
                                    trainerId = trainerId,
                                    title = title.trim(),
                                    isPrimary = isPrimary,
                                    category = category,
                                    targetDate = targetDate.trim(),
                                    targetMetric = targetMetric.trim(),
                                    startingValue = startingValue.trim(),
                                    currentValue = currentValue.trim(),
                                    targetValue = targetValue.trim(),
                                    status = status,
                                    notes = notes.trim(),
                                    createdAt = targetGoal?.createdAt ?: System.currentTimeMillis(),
                                    updatedAt = System.currentTimeMillis()
                                )
                                if (targetGoal != null) {
                                    repository.updateGoal(goal)
                                } else {
                                    repository.addGoal(goal)
                                }
                                showAddDialog = false
                                editingGoal = null
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = Color.Black)
                ) {
                    Text("Save Goal", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showAddDialog = false
                    editingGoal = null
                }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = OnyxSurface
        )
    }

    // Delete Confirmation
    if (goalToDelete != null) {
        val target = goalToDelete!!
        AlertDialog(
            onDismissRequest = { goalToDelete = null },
            title = { Text("Delete Goal?", color = TextPrimary) },
            text = { Text("Are you sure you want to remove '${target.title}'?", color = TextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            repository.deleteGoal(trainerId, target.id)
                            goalToDelete = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonError, contentColor = Color.White)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { goalToDelete = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = OnyxSurface
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header & Add Goal Action
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Client Goals & Milestones", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                Text("${goals.size} active objectives tracked", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }

            Button(
                onClick = { showAddDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = Color.Black),
                modifier = Modifier.testTag("btn_add_goal")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Goal", fontWeight = FontWeight.Bold)
            }
        }

        // Category Filter Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FilterChip(
                selected = selectedCategoryFilter == null,
                onClick = { selectedCategoryFilter = null },
                label = { Text("All (${goals.size})") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = EmeraldContainer,
                    selectedLabelColor = EmeraldPrimary,
                    containerColor = OnyxSurfaceElevated,
                    labelColor = TextSecondary
                )
            )
            GoalCategory.entries.forEach { cat ->
                val count = goals.count { it.category == cat }
                if (count > 0) {
                    FilterChip(
                        selected = selectedCategoryFilter == cat,
                        onClick = { selectedCategoryFilter = cat },
                        label = { Text("${cat.label} ($count)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyanContainer,
                            selectedLabelColor = CyanAccent,
                            containerColor = OnyxSurfaceElevated,
                            labelColor = TextSecondary
                        )
                    )
                }
            }
        }

        // Goals List
        if (filteredGoals.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Flag, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No goals recorded yet", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Text("Tap 'Add Goal' to establish primary and secondary targets", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredGoals, key = { it.id }) { goal ->
                    GoalItemCard(
                        goal = goal,
                        onEdit = { editingGoal = goal },
                        onDelete = { goalToDelete = goal },
                        onToggleAchieved = {
                            coroutineScope.launch {
                                val nextStatus = if (goal.status == GoalStatus.ACHIEVED) GoalStatus.IN_PROGRESS else GoalStatus.ACHIEVED
                                repository.updateGoal(goal.copy(status = nextStatus, updatedAt = System.currentTimeMillis()))
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun GoalItemCard(
    goal: ClientGoal,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onToggleAchieved: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (goal.isPrimary) CyanAccent.copy(alpha = 0.8f) else OnyxBorder,
                RoundedCornerShape(16.dp)
            ),
        colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    if (goal.isPrimary) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(CyanContainer)
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text("PRIMARY", style = MaterialTheme.typography.labelSmall, color = CyanAccent, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(OnyxSurfaceHigh)
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(goal.category.label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onToggleAchieved, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = if (goal.status == GoalStatus.ACHIEVED) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                            contentDescription = "Toggle Achieved",
                            tint = if (goal.status == GoalStatus.ACHIEVED) EmeraldPrimary else TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = TextSecondary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = CrimsonError, modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = goal.title,
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )

            if (goal.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = goal.notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Metric Progression Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(OnyxSurface)
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Starting", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Text(goal.startingValue.ifEmpty { "--" }, style = MaterialTheme.typography.bodyMedium, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                }

                Icon(Icons.Default.ArrowForward, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))

                Column {
                    Text("Current", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                    Text(goal.currentValue.ifEmpty { "--" }, style = MaterialTheme.typography.bodyMedium, color = CyanAccent, fontWeight = FontWeight.Bold)
                }

                Icon(Icons.Default.ArrowForward, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(16.dp))

                Column {
                    Text("Target", style = MaterialTheme.typography.labelSmall, color = EmeraldPrimary)
                    Text(goal.targetValue.ifEmpty { "--" }, style = MaterialTheme.typography.bodyMedium, color = EmeraldPrimary, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Target Date: ${goal.targetDate}",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            when (goal.status) {
                                GoalStatus.ACHIEVED -> EmeraldContainer
                                GoalStatus.IN_PROGRESS -> CyanContainer
                                GoalStatus.ON_HOLD -> AmberContainer
                                GoalStatus.ARCHIVED -> OnyxSurfaceHigh
                            }
                        )
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = goal.status.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = when (goal.status) {
                            GoalStatus.ACHIEVED -> EmeraldPrimary
                            GoalStatus.IN_PROGRESS -> CyanAccent
                            GoalStatus.ON_HOLD -> AmberWarning
                            GoalStatus.ARCHIVED -> TextSecondary
                        },
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
