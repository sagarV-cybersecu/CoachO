package com.example.ui.screens.clients.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.CoachRepository
import com.example.model.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun ConsultationTab(
    client: Client,
    trainerId: String,
    repository: CoachRepository,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val consultationState by repository.getConsultation(trainerId, client.id).collectAsState(initial = null)

    // Form states
    var isEditing by remember { mutableStateOf(false) }
    var saveMessage by remember { mutableStateOf<String?>(null) }

    // State holders populated from existing consultation or initialized with client defaults
    var occupation by remember(consultationState) { mutableStateOf(consultationState?.personal?.occupation ?: client.occupation) }
    var emergencyContactName by remember(consultationState) { mutableStateOf(consultationState?.personal?.emergencyContactName ?: "") }
    var emergencyContactPhone by remember(consultationState) { mutableStateOf(consultationState?.personal?.emergencyContactPhone ?: "") }

    var dailyActivity by remember(consultationState) { mutableStateOf(consultationState?.lifestyle?.dailyActivity ?: "") }
    var averageSteps by remember(consultationState) { mutableStateOf(consultationState?.lifestyle?.averageSteps?.toString() ?: "8000") }
    var sleepHours by remember(consultationState) { mutableStateOf(consultationState?.lifestyle?.sleepDurationHours?.toString() ?: "7.0") }
    var sleepQuality by remember(consultationState) { mutableStateOf(consultationState?.lifestyle?.sleepQuality ?: 3) }
    var stressLevel by remember(consultationState) { mutableStateOf(consultationState?.lifestyle?.stressLevel ?: 3) }
    var workSchedule by remember(consultationState) { mutableStateOf(consultationState?.lifestyle?.workSchedule ?: "") }
    var lifestyleNotes by remember(consultationState) { mutableStateOf(consultationState?.lifestyle?.lifestyleNotes ?: "") }

    var previousExperience by remember(consultationState) { mutableStateOf(consultationState?.trainingHistory?.previousExperience ?: "") }
    var currentActivity by remember(consultationState) { mutableStateOf(consultationState?.trainingHistory?.currentActivity ?: "") }
    var favouriteExercises by remember(consultationState) { mutableStateOf(consultationState?.trainingHistory?.favouriteExercises ?: "") }
    var dislikedExercises by remember(consultationState) { mutableStateOf(consultationState?.trainingHistory?.dislikedExercises ?: "") }
    var trainingLimitations by remember(consultationState) { mutableStateOf(consultationState?.trainingHistory?.trainingLimitations ?: "") }
    var equipmentAvailability by remember(consultationState) { mutableStateOf(consultationState?.trainingHistory?.equipmentAvailability ?: "Full Commercial Gym") }

    var primaryGoal by remember(consultationState) { mutableStateOf(consultationState?.goals?.primaryGoal ?: client.primaryGoal) }
    var secondaryGoals by remember(consultationState) { mutableStateOf(consultationState?.goals?.secondaryGoals ?: "") }
    var targetDate by remember(consultationState) { mutableStateOf(consultationState?.goals?.targetDate ?: "") }
    var motivation by remember(consultationState) { mutableStateOf(consultationState?.goals?.motivation ?: "") }
    var desiredOutcome by remember(consultationState) { mutableStateOf(consultationState?.goals?.desiredOutcome ?: "") }

    var eatingPattern by remember(consultationState) { mutableStateOf(consultationState?.nutrition?.eatingPattern ?: "3 meals per day") }
    var mealsPerDay by remember(consultationState) { mutableStateOf(consultationState?.nutrition?.mealsPerDay?.toString() ?: "3") }
    var waterIntake by remember(consultationState) { mutableStateOf(consultationState?.nutrition?.waterIntakeLiters?.toString() ?: "2.5") }
    var foodPreferences by remember(consultationState) { mutableStateOf(consultationState?.nutrition?.foodPreferences ?: "") }
    var dietaryRestrictions by remember(consultationState) { mutableStateOf(consultationState?.nutrition?.dietaryRestrictions ?: "None") }
    var nutritionNotes by remember(consultationState) { mutableStateOf(consultationState?.nutrition?.nutritionNotes ?: "") }

    var trainerNotes by remember(consultationState) { mutableStateOf(consultationState?.trainerNotes ?: "") }
    var isCompleted by remember(consultationState) { mutableStateOf(consultationState?.isCompleted ?: false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Status & Action Bar
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (isCompleted) EmeraldPrimary else AmberWarning)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isCompleted) "Consultation Completed" else "Intake In Progress",
                        style = MaterialTheme.typography.titleSmall,
                        color = if (isCompleted) EmeraldPrimary else AmberWarning,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = {
                        val consultation = ClientConsultation(
                            clientId = client.id,
                            trainerId = trainerId,
                            personal = ConsultationPersonalInfo(
                                fullName = client.fullName,
                                dateOfBirth = "1995-01-01",
                                gender = "Not Specified",
                                phone = client.phone,
                                email = client.email,
                                occupation = occupation,
                                emergencyContactName = emergencyContactName,
                                emergencyContactPhone = emergencyContactPhone
                            ),
                            lifestyle = ConsultationLifestyle(
                                dailyActivity = dailyActivity,
                                averageSteps = averageSteps.toIntOrNull() ?: 8000,
                                sleepDurationHours = sleepHours.toDoubleOrNull() ?: 7.0,
                                sleepQuality = sleepQuality,
                                stressLevel = stressLevel,
                                workSchedule = workSchedule,
                                lifestyleNotes = lifestyleNotes
                            ),
                            trainingHistory = ConsultationTrainingHistory(
                                previousExperience = previousExperience,
                                currentActivity = currentActivity,
                                previousProgrammes = "",
                                favouriteExercises = favouriteExercises,
                                dislikedExercises = dislikedExercises,
                                trainingLimitations = trainingLimitations,
                                equipmentAvailability = equipmentAvailability
                            ),
                            goals = ConsultationGoals(
                                primaryGoal = primaryGoal,
                                secondaryGoals = secondaryGoals,
                                targetDate = targetDate,
                                motivation = motivation,
                                desiredOutcome = desiredOutcome
                            ),
                            nutrition = ConsultationNutrition(
                                eatingPattern = eatingPattern,
                                mealsPerDay = mealsPerDay.toIntOrNull() ?: 3,
                                waterIntakeLiters = waterIntake.toDoubleOrNull() ?: 2.5,
                                foodPreferences = foodPreferences,
                                dietaryRestrictions = dietaryRestrictions,
                                nutritionNotes = nutritionNotes
                            ),
                            trainerNotes = trainerNotes,
                            isCompleted = isCompleted,
                            lastSavedAt = System.currentTimeMillis()
                        )

                        coroutineScope.launch {
                            repository.saveConsultation(consultation)
                            saveMessage = "Consultation saved successfully!"
                            isEditing = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = Color.Black),
                    modifier = Modifier.testTag("btn_save_consultation")
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Save Intake", fontWeight = FontWeight.Bold)
                }
            }
        }

        if (saveMessage != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = EmeraldContainer.copy(alpha = 0.25f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(saveMessage ?: "", color = EmeraldPrimary, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        // Completion Toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(OnyxSurfaceElevated)
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("Mark as Formally Completed", style = MaterialTheme.typography.bodyMedium, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                Text("Triggers consultation completion milestone in timeline", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            Switch(
                checked = isCompleted,
                onCheckedChange = { isCompleted = it },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = EmeraldPrimary,
                    checkedTrackColor = EmeraldContainer
                )
            )
        }

        // Section 1: Emergency & Occupation
        ConsultationSectionCard(title = "1. Personal & Emergency Details", icon = Icons.Default.Person) {
            OutlinedTextField(
                value = occupation,
                onValueChange = { occupation = it },
                label = { Text("Occupation & Workplace Demands") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = emergencyContactName,
                    onValueChange = { emergencyContactName = it },
                    label = { Text("Emergency Contact") },
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )
                OutlinedTextField(
                    value = emergencyContactPhone,
                    onValueChange = { emergencyContactPhone = it },
                    label = { Text("Emergency Phone") },
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )
            }
        }

        // Section 2: Goals & Desired Outcome
        ConsultationSectionCard(title = "2. Client Goals & Vision", icon = Icons.Default.Flag) {
            OutlinedTextField(
                value = primaryGoal,
                onValueChange = { primaryGoal = it },
                label = { Text("Primary Goal") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
            )
            OutlinedTextField(
                value = secondaryGoals,
                onValueChange = { secondaryGoals = it },
                label = { Text("Secondary Goals") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = targetDate,
                    onValueChange = { targetDate = it },
                    label = { Text("Target Date (e.g. Nov 2026)") },
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )
                OutlinedTextField(
                    value = motivation,
                    onValueChange = { motivation = it },
                    label = { Text("Deep Motivation / Why") },
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )
            }
            OutlinedTextField(
                value = desiredOutcome,
                onValueChange = { desiredOutcome = it },
                label = { Text("Specific Desired Outcome (Physical & Psychological)") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
            )
        }

        // Section 3: Training History & Limitations
        ConsultationSectionCard(title = "3. Training Background & Limitations", icon = Icons.Default.FitnessCenter) {
            OutlinedTextField(
                value = previousExperience,
                onValueChange = { previousExperience = it },
                label = { Text("Previous Training Experience") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
            )
            OutlinedTextField(
                value = currentActivity,
                onValueChange = { currentActivity = it },
                label = { Text("Current Weekly Activity & Frequency") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
            )
            OutlinedTextField(
                value = trainingLimitations,
                onValueChange = { trainingLimitations = it },
                label = { Text("Physical Limitations / Past Injuries") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = favouriteExercises,
                    onValueChange = { favouriteExercises = it },
                    label = { Text("Favourite Exercises") },
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )
                OutlinedTextField(
                    value = dislikedExercises,
                    onValueChange = { dislikedExercises = it },
                    label = { Text("Disliked Exercises") },
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )
            }
        }

        // Section 4: Lifestyle & Recovery
        ConsultationSectionCard(title = "4. Lifestyle, Sleep & Stress", icon = Icons.Default.Bedtime) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = sleepHours,
                    onValueChange = { sleepHours = it },
                    label = { Text("Sleep (Hours/night)") },
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )
                OutlinedTextField(
                    value = averageSteps,
                    onValueChange = { averageSteps = it },
                    label = { Text("Daily Steps") },
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )
            }

            // Stress & Sleep Quality Rating Selectors
            Text("Stress Level (1 = Low, 5 = Extreme): $stressLevel", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            Slider(
                value = stressLevel.toFloat(),
                onValueChange = { stressLevel = it.toInt() },
                valueRange = 1f..5f,
                steps = 3,
                colors = SliderDefaults.colors(thumbColor = CyanAccent, activeTrackColor = CyanAccent)
            )

            Text("Sleep Quality (1 = Poor, 5 = Deep): $sleepQuality", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            Slider(
                value = sleepQuality.toFloat(),
                onValueChange = { sleepQuality = it.toInt() },
                valueRange = 1f..5f,
                steps = 3,
                colors = SliderDefaults.colors(thumbColor = EmeraldPrimary, activeTrackColor = EmeraldPrimary)
            )

            OutlinedTextField(
                value = lifestyleNotes,
                onValueChange = { lifestyleNotes = it },
                label = { Text("Lifestyle & Work Schedule Notes") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
            )
        }

        // Section 5: Nutrition & Hydration
        ConsultationSectionCard(title = "5. Nutrition & Dietary Profile", icon = Icons.Default.Restaurant) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = mealsPerDay,
                    onValueChange = { mealsPerDay = it },
                    label = { Text("Meals/Day") },
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )
                OutlinedTextField(
                    value = waterIntake,
                    onValueChange = { waterIntake = it },
                    label = { Text("Water (Liters)") },
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )
            }
            OutlinedTextField(
                value = dietaryRestrictions,
                onValueChange = { dietaryRestrictions = it },
                label = { Text("Allergies & Dietary Restrictions") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
            )
            OutlinedTextField(
                value = foodPreferences,
                onValueChange = { foodPreferences = it },
                label = { Text("Preferred Protein, Carb & Veggie Sources") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
            )
        }

        // Section 6: Trainer Internal Observations
        ConsultationSectionCard(title = "6. Coach Intake Notes (Internal)", icon = Icons.Default.EditNote) {
            OutlinedTextField(
                value = trainerNotes,
                onValueChange = { trainerNotes = it },
                label = { Text("Trainer Observations & Strategy Plan") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp),
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
            )
        }
    }
}

@Composable
private fun ConsultationSectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, OnyxBorder, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(title, style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
            }
            content()
        }
    }
}
