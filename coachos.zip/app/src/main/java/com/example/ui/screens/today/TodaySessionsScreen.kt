package com.example.ui.screens.today

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.AiResult
import com.example.ai.ClientIntelligenceService
import com.example.data.repository.CoachRepository
import com.example.model.*
import com.example.ui.components.EmptyStateView
import com.example.ui.components.StatusChip
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.util.UUID

@Composable
fun TodaySessionsScreen(
    trainerId: String,
    repository: CoachRepository,
    intelligenceService: ClientIntelligenceService,
    onClientClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val todaySessions by repository.getTodaySessions(trainerId).collectAsState(initial = emptyList())
    val allClients by repository.getClients(trainerId).collectAsState(initial = emptyList())

    var showAddSessionDialog by remember { mutableStateOf(false) }
    var showAiBriefDialog by remember { mutableStateOf<Pair<ScheduledSession, String>?>(null) }
    var isGeneratingBrief by remember { mutableStateOf(false) }

    // Add Session Dialog
    if (showAddSessionDialog) {
        var selectedClientId by remember { mutableStateOf(allClients.firstOrNull()?.id ?: "") }
        var sessionTime by remember { mutableStateOf("02:00 PM") }
        var sessionFocus by remember { mutableStateOf("Hypertrophy & Core Training") }
        var location by remember { mutableStateOf("Main Gym Platform") }

        AlertDialog(
            onDismissRequest = { showAddSessionDialog = false },
            title = { Text("Schedule Training Session", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select Client", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    allClients.forEach { c ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selectedClientId == c.id) CyanContainer else OnyxSurfaceElevated)
                                .padding(8.dp)
                        ) {
                            RadioButton(
                                selected = selectedClientId == c.id,
                                onClick = { selectedClientId = c.id },
                                colors = RadioButtonDefaults.colors(selectedColor = CyanAccent)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(c.fullName, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    OutlinedTextField(
                        value = sessionTime,
                        onValueChange = { sessionTime = it },
                        label = { Text("Time (e.g. 02:00 PM)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )

                    OutlinedTextField(
                        value = sessionFocus,
                        onValueChange = { sessionFocus = it },
                        label = { Text("Workout Focus") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val client = allClients.find { it.id == selectedClientId }
                        if (client != null) {
                            coroutineScope.launch {
                                repository.saveSession(
                                    ScheduledSession(
                                        id = UUID.randomUUID().toString(),
                                        trainerId = trainerId,
                                        clientId = client.id,
                                        clientName = client.fullName,
                                        sessionTimeText = sessionTime,
                                        sessionDateText = "Today",
                                        durationMinutes = 60,
                                        status = SessionStatus.SCHEDULED,
                                        sessionFocus = sessionFocus,
                                        location = location
                                    )
                                )
                                showAddSessionDialog = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = Color.Black)
                ) {
                    Text("Save Session")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddSessionDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = OnyxSurface
        )
    }

    // AI Brief Dialog
    if (showAiBriefDialog != null) {
        val (sess, briefText) = showAiBriefDialog!!
        AlertDialog(
            onDismissRequest = { showAiBriefDialog = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CyanAccent)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Coaching Brief: ${sess.clientName}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column {
                    Text("Workout Focus: ${sess.sessionFocus}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(briefText, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                }
            },
            confirmButton = {
                Button(
                    onClick = { showAiBriefDialog = null },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = Color.Black)
                ) {
                    Text("Got It")
                }
            },
            containerColor = OnyxSurface
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(OnyxBackground)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Today's Schedule",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${todaySessions.size} coaching appointments scheduled",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            Button(
                onClick = { showAddSessionDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = Color.Black),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Session", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (todaySessions.isEmpty()) {
            EmptyStateView(
                title = "No sessions today",
                message = "You can schedule one-on-one personal training sessions anytime.",
                icon = Icons.Default.EventAvailable,
                actionButtonText = "Schedule Session",
                onActionClick = { showAddSessionDialog = true }
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(todaySessions, key = { it.id }) { session ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.dp, OnyxBorder, RoundedCornerShape(16.dp)),
                        colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = session.sessionTimeText,
                                        style = MaterialTheme.typography.titleLarge,
                                        color = EmeraldPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = session.clientName,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.clickable { onClientClick(session.clientId) }
                                    )
                                }

                                val statusColor = when (session.status) {
                                    SessionStatus.COMPLETED -> EmeraldPrimary
                                    SessionStatus.CANCELLED -> CrimsonError
                                    SessionStatus.NO_SHOW -> AmberWarning
                                    else -> CyanAccent
                                }
                                StatusChip(text = session.status.name, color = statusColor)
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = "Focus: ${session.sessionFocus}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary
                            )

                            Text(
                                text = "Location: ${session.location} (${session.durationMinutes} mins)",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Fast Actions Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Toggle Complete
                                Button(
                                    onClick = {
                                        val newStatus = if (session.status == SessionStatus.COMPLETED)
                                            SessionStatus.SCHEDULED
                                        else
                                            SessionStatus.COMPLETED
                                        coroutineScope.launch {
                                            repository.updateSessionStatus(session, newStatus)
                                        }
                                    },
                                    modifier = Modifier.weight(1f).height(36.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (session.status == SessionStatus.COMPLETED) OnyxSurfaceHigh else EmeraldPrimary,
                                        contentColor = if (session.status == SessionStatus.COMPLETED) TextSecondary else Color.Black
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = if (session.status == SessionStatus.COMPLETED) Icons.Default.Check else Icons.Default.Done,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (session.status == SessionStatus.COMPLETED) "Completed" else "Complete", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                // AI Coaching Brief Button
                                OutlinedButton(
                                    onClick = {
                                        val client = allClients.find { it.id == session.clientId }
                                        if (client != null) {
                                            coroutineScope.launch {
                                                isGeneratingBrief = true
                                                when (val brief = intelligenceService.getTodaySessionBrief(client, session.sessionFocus)) {
                                                    is AiResult.Success -> showAiBriefDialog = Pair(session, brief.data)
                                                    is AiResult.NotConfigured -> showAiBriefDialog = Pair(session, brief.message)
                                                    is AiResult.Error -> showAiBriefDialog = Pair(session, "Error: ${brief.message}")
                                                }
                                                isGeneratingBrief = false
                                            }
                                        }
                                    },
                                    modifier = Modifier.weight(1f).height(36.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(CyanAccent)),
                                    contentPadding = PaddingValues(horizontal = 4.dp)
                                ) {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("AI Brief", color = CyanAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
