package com.example.ui.screens.clients.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.CoachRepository
import com.example.model.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MeasurementsTab(
    client: Client,
    trainerId: String,
    repository: CoachRepository,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val measurements by repository.getMeasurementsForClient(trainerId, client.id).collectAsState(initial = emptyList())

    var showAddDialog by remember { mutableStateOf(false) }
    var measurementToDelete by remember { mutableStateOf<ClientMeasurement?>(null) }
    var selectedTypeFilter by remember { mutableStateOf<MeasurementType?>(null) }

    val filteredMeasurements = measurements.filter {
        selectedTypeFilter == null || it.type == selectedTypeFilter
    }

    // Add Measurement Dialog
    if (showAddDialog) {
        var selectedType by remember { mutableStateOf(MeasurementType.WEIGHT) }
        var customTypeName by remember { mutableStateOf("") }
        var valueText by remember { mutableStateOf("") }
        var unitText by remember { mutableStateOf("kg") }
        var dateText by remember { mutableStateOf("2026-09-08") }
        var notesText by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Log New Measurement", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Measurement Type", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        MeasurementType.entries.forEach { type ->
                            FilterChip(
                                selected = selectedType == type,
                                onClick = {
                                    selectedType = type
                                    unitText = type.defaultUnit
                                },
                                label = { Text(type.label, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EmeraldContainer,
                                    selectedLabelColor = EmeraldPrimary,
                                    containerColor = OnyxSurfaceHigh,
                                    labelColor = TextSecondary
                                )
                            )
                        }
                    }

                    if (selectedType == MeasurementType.CUSTOM) {
                        OutlinedTextField(
                            value = customTypeName,
                            onValueChange = { customTypeName = it },
                            label = { Text("Custom Measurement Name") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = valueText,
                            onValueChange = { valueText = it },
                            label = { Text("Value (e.g. 68.2)") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                        )
                        OutlinedTextField(
                            value = unitText,
                            onValueChange = { unitText = it },
                            label = { Text("Unit") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                        )
                    }

                    OutlinedTextField(
                        value = dateText,
                        onValueChange = { dateText = it },
                        label = { Text("Date (YYYY-MM-DD)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )

                    OutlinedTextField(
                        value = notesText,
                        onValueChange = { notesText = it },
                        label = { Text("Context & Measurement Conditions") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val parsedValue = valueText.toDoubleOrNull()
                        if (parsedValue != null) {
                            coroutineScope.launch {
                                repository.addMeasurement(
                                    ClientMeasurement(
                                        id = UUID.randomUUID().toString(),
                                        clientId = client.id,
                                        trainerId = trainerId,
                                        type = selectedType,
                                        customTypeName = customTypeName.takeIf { it.isNotBlank() },
                                        value = parsedValue,
                                        unit = unitText.trim(),
                                        date = dateText.trim(),
                                        notes = notesText.trim(),
                                        createdAt = System.currentTimeMillis()
                                    )
                                )
                                showAddDialog = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = Color.Black)
                ) {
                    Text("Save Measurement", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = OnyxSurface
        )
    }

    // Delete Confirmation
    if (measurementToDelete != null) {
        val target = measurementToDelete!!
        AlertDialog(
            onDismissRequest = { measurementToDelete = null },
            title = { Text("Delete Measurement?", color = TextPrimary) },
            text = { Text("Remove record of ${target.value} ${target.unit} on ${target.date}?", color = TextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            repository.deleteMeasurement(trainerId, target.id)
                            measurementToDelete = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonError, contentColor = Color.White)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { measurementToDelete = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = OnyxSurface
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Summary Cards Grid
        val latestWeight = measurements.firstOrNull { it.type == MeasurementType.WEIGHT }
        val latestWaist = measurements.firstOrNull { it.type == MeasurementType.WAIST }
        val latestBodyFat = measurements.firstOrNull { it.type == MeasurementType.BODY_FAT_PERCENT }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Card(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, OnyxBorder, RoundedCornerShape(14.dp)),
                colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Weight", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Text(
                        text = if (latestWeight != null) "${latestWeight.value} ${latestWeight.unit}" else "${client.currentWeightKg} kg",
                        style = MaterialTheme.typography.titleMedium,
                        color = EmeraldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text("Target: ${client.targetWeightKg ?: 65.0} kg", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                }
            }

            Card(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, OnyxBorder, RoundedCornerShape(14.dp)),
                colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Body Fat", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Text(
                        text = if (latestBodyFat != null) "${latestBodyFat.value}%" else "--",
                        style = MaterialTheme.typography.titleMedium,
                        color = CyanAccent,
                        fontWeight = FontWeight.Bold
                    )
                    Text(latestBodyFat?.date ?: "No entry", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }

            Card(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, OnyxBorder, RoundedCornerShape(14.dp)),
                colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Waist", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Text(
                        text = if (latestWaist != null) "${latestWaist.value} cm" else "--",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(latestWaist?.date ?: "No entry", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
        }

        // Header & Log Action
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Body Composition History", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)

            Button(
                onClick = { showAddDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = Color.Black),
                modifier = Modifier.testTag("btn_add_measurement")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Log Entry", fontWeight = FontWeight.Bold)
            }
        }

        // Filter chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FilterChip(
                selected = selectedTypeFilter == null,
                onClick = { selectedTypeFilter = null },
                label = { Text("All (${measurements.size})") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = EmeraldContainer,
                    selectedLabelColor = EmeraldPrimary,
                    containerColor = OnyxSurfaceElevated,
                    labelColor = TextSecondary
                )
            )
            MeasurementType.entries.forEach { type ->
                val count = measurements.count { it.type == type }
                if (count > 0) {
                    FilterChip(
                        selected = selectedTypeFilter == type,
                        onClick = { selectedTypeFilter = type },
                        label = { Text("${type.label} ($count)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyanContainer,
                            selectedLabelColor = CyanAccent,
                            containerColor = OnyxSurfaceElevated,
                            labelColor = TextSecondary
                        )
                    )
                }
            }
        }

        // List
        if (filteredMeasurements.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Straighten, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No measurements recorded", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Text("Log body weight, girth, and vitals to track transformation", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredMeasurements, key = { it.id }) { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, OnyxBorder, RoundedCornerShape(14.dp)),
                        colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = item.customTypeName ?: item.type.label,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = item.date,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary
                                    )
                                }
                                if (item.notes.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = item.notes,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${item.value} ${item.unit}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = EmeraldPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                IconButton(
                                    onClick = { measurementToDelete = item },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = CrimsonError, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
