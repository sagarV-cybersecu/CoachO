package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Fitness Tech Palette
val OnyxBackground = Color(0xFF090D14)
val OnyxSurface = Color(0xFF121824)
val OnyxSurfaceElevated = Color(0xFF1A2232)
val OnyxSurfaceHigh = Color(0xFF222C3F)
val OnyxBorder = Color(0xFF2A364B)

// Accents
val EmeraldPrimary = Color(0xFF10B981) // High-energy training green
val EmeraldContainer = Color(0xFF064E3B)
val CyanAccent = Color(0xFF06B6D4) // AI intelligence cyan
val CyanContainer = Color(0xFF164E63)
val AmberWarning = Color(0xFFF59E0B) // Attention indicator
val AmberContainer = Color(0xFF78350F)
val CrimsonError = Color(0xFFEF4444)
val CrimsonContainer = Color(0xFF7F1D1D)

// Typography & Neutrals
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Badges & Indicators
val StatusReady = Color(0xFF10B981)
val StatusModerate = Color(0xFFF59E0B)
val StatusRecovery = Color(0xFF38BDF8)
val StatusArchived = Color(0xFF64748B)
