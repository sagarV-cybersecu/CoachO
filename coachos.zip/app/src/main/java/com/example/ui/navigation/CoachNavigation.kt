package com.example.ui.navigation

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.ClientIntelligenceService
import com.example.data.repository.CoachRepository
import com.example.data.session.SessionManager
import com.example.ui.screens.ai.AiBrainScreen
import com.example.ui.screens.auth.AuthScreen
import com.example.ui.screens.clients.AddEditClientScreen
import com.example.ui.screens.clients.ClientDetailScreen
import com.example.ui.screens.clients.ClientsScreen
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.today.TodaySessionsScreen
import com.example.ui.theme.*

enum class BottomNavDestination(val label: String, val icon: ImageVector) {
    DASHBOARD("Dashboard", Icons.Default.Dashboard),
    CLIENTS("Clients", Icons.Default.People),
    TODAY("Today", Icons.Default.CalendarToday),
    AI_BRAIN("AI Brain", Icons.Default.Psychology),
    SETTINGS("Settings", Icons.Default.Settings)
}

sealed class Screen {
    object Main : Screen()
    data class ClientDetail(val clientId: String) : Screen()
    data class AddEditClient(val clientId: String? = null) : Screen()
}

@Composable
fun CoachAppRoot(
    repository: CoachRepository,
    sessionManager: SessionManager,
    intelligenceService: ClientIntelligenceService
) {
    val isLoggedIn by sessionManager.isLoggedIn.collectAsState()
    val currentTrainerId by sessionManager.currentTrainerId.collectAsState()

    var currentScreen by remember { mutableStateOf<Screen>(Screen.Main) }
    var selectedBottomNav by remember { mutableStateOf(BottomNavDestination.DASHBOARD) }

    Crossfade(targetState = isLoggedIn, label = "auth_crossfade") { loggedIn ->
        if (!loggedIn || currentTrainerId == null) {
            AuthScreen(
                repository = repository,
                sessionManager = sessionManager,
                onAuthSuccess = {
                    currentScreen = Screen.Main
                    selectedBottomNav = BottomNavDestination.DASHBOARD
                }
            )
        } else {
            val trainerId = currentTrainerId!!

            when (val screen = currentScreen) {
                is Screen.Main -> {
                    Scaffold(
                        bottomBar = {
                            NavigationBar(
                                containerColor = OnyxSurfaceElevated,
                                contentColor = TextPrimary,
                                tonalElevation = 8.dp,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                                    .border(1.dp, OnyxBorder, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                            ) {
                                BottomNavDestination.entries.forEach { destination ->
                                    val isSelected = selectedBottomNav == destination
                                    NavigationBarItem(
                                        selected = isSelected,
                                        onClick = { selectedBottomNav = destination },
                                        icon = {
                                            Icon(
                                                imageVector = destination.icon,
                                                contentDescription = destination.label,
                                                tint = if (isSelected) EmeraldPrimary else TextMuted
                                            )
                                        },
                                        label = {
                                            Text(
                                                text = destination.label,
                                                fontSize = 11.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                color = if (isSelected) EmeraldPrimary else TextMuted
                                            )
                                        },
                                        colors = NavigationBarItemDefaults.colors(
                                            indicatorColor = OnyxSurfaceHigh
                                        ),
                                        modifier = Modifier.testTag("nav_${destination.name.lowercase()}")
                                    )
                                }
                            }
                        },
                        containerColor = OnyxBackground
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            when (selectedBottomNav) {
                                BottomNavDestination.DASHBOARD -> DashboardScreen(
                                    trainerId = trainerId,
                                    repository = repository,
                                    sessionManager = sessionManager,
                                    onClientClick = { clientId -> currentScreen = Screen.ClientDetail(clientId) },
                                    onAddClientClick = { currentScreen = Screen.AddEditClient() },
                                    onViewAllClients = { selectedBottomNav = BottomNavDestination.CLIENTS },
                                    onViewTodaySessions = { selectedBottomNav = BottomNavDestination.TODAY }
                                )
                                BottomNavDestination.CLIENTS -> ClientsScreen(
                                    trainerId = trainerId,
                                    repository = repository,
                                    onClientClick = { clientId -> currentScreen = Screen.ClientDetail(clientId) },
                                    onAddClientClick = { currentScreen = Screen.AddEditClient() }
                                )
                                BottomNavDestination.TODAY -> TodaySessionsScreen(
                                    trainerId = trainerId,
                                    repository = repository,
                                    intelligenceService = intelligenceService,
                                    onClientClick = { clientId -> currentScreen = Screen.ClientDetail(clientId) }
                                )
                                BottomNavDestination.AI_BRAIN -> AiBrainScreen(
                                    trainerId = trainerId,
                                    repository = repository,
                                    intelligenceService = intelligenceService,
                                    onClientClick = { clientId -> currentScreen = Screen.ClientDetail(clientId) }
                                )
                                BottomNavDestination.SETTINGS -> SettingsScreen(
                                    trainerId = trainerId,
                                    repository = repository,
                                    sessionManager = sessionManager,
                                    onSignOut = {
                                        currentScreen = Screen.Main
                                    }
                                )
                            }
                        }
                    }
                }

                is Screen.ClientDetail -> {
                    ClientDetailScreen(
                        trainerId = trainerId,
                        clientId = screen.clientId,
                        repository = repository,
                        intelligenceService = intelligenceService,
                        onBack = { currentScreen = Screen.Main },
                        onEditClient = { cId -> currentScreen = Screen.AddEditClient(cId) }
                    )
                }

                is Screen.AddEditClient -> {
                    AddEditClientScreen(
                        trainerId = trainerId,
                        clientId = screen.clientId,
                        repository = repository,
                        onBack = { currentScreen = Screen.Main },
                        onSaved = { currentScreen = Screen.Main }
                    )
                }
            }
        }
    }
}
