package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CoachOSColorScheme = darkColorScheme(
    primary = EmeraldPrimary,
    onPrimary = Color.Black,
    primaryContainer = EmeraldContainer,
    onPrimaryContainer = Color(0xFFD1FAE5),
    secondary = CyanAccent,
    onSecondary = Color.Black,
    secondaryContainer = CyanContainer,
    onSecondaryContainer = Color(0xFFCFFAFE),
    tertiary = AmberWarning,
    onTertiary = Color.Black,
    tertiaryContainer = AmberContainer,
    onTertiaryContainer = Color(0xFFFEF3C7),
    background = OnyxBackground,
    onBackground = TextPrimary,
    surface = OnyxSurface,
    onSurface = TextPrimary,
    surfaceVariant = OnyxSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = OnyxBorder,
    outlineVariant = OnyxSurfaceHigh,
    error = CrimsonError,
    onError = Color.White,
    errorContainer = CrimsonContainer,
    onErrorContainer = Color(0xFFFEE2E2)
)

@Composable
fun CoachOSTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CoachOSColorScheme,
        typography = Typography,
        content = content
    )
}
