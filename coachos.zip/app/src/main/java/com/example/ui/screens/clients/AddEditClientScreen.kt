package com.example.ui.screens.clients

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.CoachRepository
import com.example.model.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditClientScreen(
    trainerId: String,
    clientId: String?,
    repository: CoachRepository,
    onBack: () -> Unit,
    onSaved: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var isLoadingExisting by remember { mutableStateOf(clientId != null) }

    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var primaryGoal by remember { mutableStateOf("Body Recomposition & Core Strength") }
    var goalType by remember { mutableStateOf(PrimaryGoalType.BODY_RECOMPOSITION) }
    var currentProgram by remember { mutableStateOf("Hypertrophy Phase 1") }
    var status by remember { mutableStateOf(ClientStatus.ACTIVE) }
    var fitnessLevel by remember { mutableStateOf(FitnessLevel.INTERMEDIATE) }
    var occupation by remember { mutableStateOf("") }
    var packageTotal by remember { mutableStateOf("20") }
    var packageRemaining by remember { mutableStateOf("16") }
    var currentWeight by remember { mutableStateOf("75.0") }
    var targetWeight by remember { mutableStateOf("70.0") }
    var readiness by remember { mutableStateOf("READY") }
    var needsAttention by remember { mutableStateOf(false) }
    var attentionReason by remember { mutableStateOf("") }
    var notesSummary by remember { mutableStateOf("") }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSaving by remember { mutableStateOf(false) }

    LaunchedEffect(clientId) {
        if (clientId != null) {
            val existing = repository.getClientByIdOnce(trainerId, clientId)
            if (existing != null) {
                fullName = existing.fullName
                email = existing.email
                phone = existing.phone
                primaryGoal = existing.primaryGoal
                goalType = existing.goalType
                currentProgram = existing.currentProgram
                status = existing.status
                fitnessLevel = existing.fitnessLevel
                occupation = existing.occupation
                packageTotal = existing.packageTotalSessions.toString()
                packageRemaining = existing.packageRemainingSessions.toString()
                currentWeight = existing.currentWeightKg.toString()
                targetWeight = existing.targetWeightKg.toString()
                readiness = existing.readinessScore
                needsAttention = existing.needsAttention
                attentionReason = existing.attentionReason ?: ""
                notesSummary = existing.notesSummary
            }
            isLoadingExisting = false
        }
    }

    fun handleSave() {
        if (fullName.isBlank()) {
            errorMessage = "Full name is required."
            return
        }
        if (email.isBlank()) {
            errorMessage = "Email is required."
            return
        }

        coroutineScope.launch {
            isSaving = true
            errorMessage = null
            try {
                val totalSessions = packageTotal.toIntOrNull() ?: 20
                val remainingSessions = packageRemaining.toIntOrNull() ?: 20
                val cWeight = currentWeight.toDoubleOrNull() ?: 70.0
                val tWeight = targetWeight.toDoubleOrNull() ?: 70.0

                val client = Client(
                    id = clientId ?: UUID.randomUUID().toString(),
                    trainerId = trainerId,
                    fullName = fullName.trim(),
                    email = email.trim(),
                    phone = phone.trim(),
                    primaryGoal = primaryGoal.trim(),
                    goalType = goalType,
                    currentProgram = currentProgram.trim(),
                    status = status,
                    fitnessLevel = fitnessLevel,
                    occupation = occupation.trim(),
                    packageTotalSessions = totalSessions,
                    packageRemainingSessions = remainingSessions,
                    sessionsCompleted = (totalSessions - remainingSessions).coerceAtLeast(0),
                    currentWeightKg = cWeight,
                    targetWeightKg = tWeight,
                    readinessScore = readiness,
                    readinessReason = if (readiness == "READY") "High energy and optimal recovery reported." else "Recovery focus indicated.",
                    needsAttention = needsAttention,
                    attentionReason = if (needsAttention) attentionReason.ifBlank { "Flagged for trainer review" } else null,
                    notesSummary = notesSummary.trim(),
                    updatedAt = System.currentTimeMillis()
                )

                repository.saveClient(client)
                onSaved()
            } catch (e: Exception) {
                errorMessage = "Error saving client: ${e.message}"
            } finally {
                isSaving = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (clientId == null) "Add New Client" else "Edit Client Profile",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Cancel", tint = TextPrimary)
                    }
                },
                actions = {
                    IconButton(
                        onClick = { handleSave() },
                        enabled = !isSaving,
                        modifier = Modifier.testTag("btn_save_client")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = "Save Client", tint = EmeraldPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = OnyxBackground)
            )
        },
        containerColor = OnyxBackground,
        modifier = modifier.fillMaxSize()
    ) { paddingValues ->
        if (isLoadingExisting) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = EmeraldPrimary)
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (errorMessage != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = CrimsonContainer.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = errorMessage ?: "",
                            color = Color.White,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                Text("Basic Information", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("Client Full Name *") },
                    modifier = Modifier.fillMaxWidth().testTag("input_client_name"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address *") },
                    modifier = Modifier.fillMaxWidth().testTag("input_client_email"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )

                OutlinedTextField(
                    value = occupation,
                    onValueChange = { occupation = it },
                    label = { Text("Occupation / Lifestyle") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )

                Spacer(modifier = Modifier.height(4.dp))
                Text("Coaching & Goals", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = primaryGoal,
                    onValueChange = { primaryGoal = it },
                    label = { Text("Primary Goal Statement") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )

                // Goal Type Chips
                Text("Goal Category", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PrimaryGoalType.entries.forEach { type ->
                        FilterChip(
                            selected = goalType == type,
                            onClick = { goalType = type },
                            label = { Text(type.name.replace("_", " "), fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyanContainer,
                                selectedLabelColor = CyanAccent,
                                containerColor = OnyxSurfaceElevated,
                                labelColor = TextSecondary
                            )
                        )
                    }
                }

                OutlinedTextField(
                    value = currentProgram,
                    onValueChange = { currentProgram = it },
                    label = { Text("Assigned Training Program") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )

                // Fitness Level Chips
                Text("Experience Level", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FitnessLevel.entries.forEach { level ->
                        FilterChip(
                            selected = fitnessLevel == level,
                            onClick = { fitnessLevel = level },
                            label = { Text(level.name) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EmeraldContainer,
                                selectedLabelColor = EmeraldPrimary,
                                containerColor = OnyxSurfaceElevated,
                                labelColor = TextSecondary
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text("Metrics & Packages", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = currentWeight,
                        onValueChange = { currentWeight = it },
                        label = { Text("Weight (kg)") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                    OutlinedTextField(
                        value = targetWeight,
                        onValueChange = { targetWeight = it },
                        label = { Text("Target (kg)") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = packageTotal,
                        onValueChange = { packageTotal = it },
                        label = { Text("Total Sessions") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                    OutlinedTextField(
                        value = packageRemaining,
                        onValueChange = { packageRemaining = it },
                        label = { Text("Remaining") },
                        modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                }

                // Needs Attention Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Flag as 'Needs Attention'", style = MaterialTheme.typography.bodyMedium, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        Text("Triggers priority indicator on coach dashboard", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    Switch(
                        checked = needsAttention,
                        onCheckedChange = { needsAttention = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = AmberWarning,
                            checkedTrackColor = AmberContainer
                        )
                    )
                }

                if (needsAttention) {
                    OutlinedTextField(
                        value = attentionReason,
                        onValueChange = { attentionReason = it },
                        label = { Text("Attention Reason (e.g. Missed sessions, Plateau)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                    )
                }

                OutlinedTextField(
                    value = notesSummary,
                    onValueChange = { notesSummary = it },
                    label = { Text("Coach Notes / Intake Summary") },
                    modifier = Modifier.fillMaxWidth().height(100.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = { handleSave() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = Color.Black),
                    shape = RoundedCornerShape(12.dp),
                    enabled = !isSaving
                ) {
                    if (isSaving) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.Black, strokeWidth = 2.dp)
                    } else {
                        Text(if (clientId == null) "Create Client Profile" else "Save Changes", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
