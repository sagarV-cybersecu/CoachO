package com.example.ui.screens.ai

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.AiResult
import com.example.ai.ClientIntelligenceService
import com.example.data.repository.CoachRepository
import com.example.model.*
import com.example.ui.components.AiRecommendationCard
import com.example.ui.components.EmptyStateView
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun AiBrainScreen(
    trainerId: String,
    repository: CoachRepository,
    intelligenceService: ClientIntelligenceService,
    onClientClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val aiRecommendations by repository.getAiRecommendations().collectAsState(initial = emptyList())
    val clients by repository.getClients(trainerId).collectAsState(initial = emptyList())
    val isConfigured = intelligenceService.isAiConfigured()

    var selectedStatusFilter by remember { mutableStateOf(ActionStatus.PENDING) }
    var globalQuery by remember { mutableStateOf("") }
    var globalAiResponse by remember { mutableStateOf<String?>(null) }
    var isQuerying by remember { mutableStateOf(false) }
    var queryError by remember { mutableStateOf<String?>(null) }

    val filteredRecommendations = remember(aiRecommendations, selectedStatusFilter) {
        aiRecommendations.filter { it.status == selectedStatusFilter }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OnyxBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // AI Brain Status Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, if (isConfigured) CyanAccent.copy(alpha = 0.5f) else AmberWarning.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(if (isConfigured) CyanContainer else AmberContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Psychology,
                                    contentDescription = null,
                                    tint = if (isConfigured) CyanAccent else AmberWarning,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "CoachOS AI Brain",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (isConfigured) "Gemini 2.5 Active • Server-Side Injected" else "AI Service Standby • Set GEMINI_API_KEY",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (isConfigured) CyanAccent else AmberWarning
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isConfigured) EmeraldContainer else AmberContainer)
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = if (isConfigured) "READY" else "UNCONFIGURED",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isConfigured) EmeraldPrimary else AmberWarning,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Core Rule: The trainer remains in control. All AI suggestions are presented as recommendations for trainer review, editing, approval, or rejection.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        // Global Coach Prompt Bar
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Roster Intelligence Assistant",
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val prompts = listOf(
                            "Identify clients with stalled weight progress",
                            "Review weekly attendance anomalies",
                            "Suggest recovery protocol for sore clients"
                        )
                        prompts.forEach { p ->
                            SuggestionChip(
                                onClick = {
                                    globalQuery = p
                                    val attentionClient = clients.firstOrNull { it.needsAttention } ?: clients.firstOrNull()
                                    if (attentionClient != null) {
                                        coroutineScope.launch {
                                            isQuerying = true
                                            queryError = null
                                            when (val res = intelligenceService.queryClientBrain(attentionClient, p)) {
                                                is AiResult.Success -> globalAiResponse = res.data
                                                is AiResult.NotConfigured -> queryError = res.message
                                                is AiResult.Error -> queryError = res.message
                                            }
                                            isQuerying = false
                                        }
                                    }
                                },
                                label = { Text(p, fontSize = 11.sp, color = TextPrimary) },
                                colors = SuggestionChipDefaults.suggestionChipColors(containerColor = OnyxSurfaceHigh)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = globalQuery,
                        onValueChange = { globalQuery = it },
                        label = { Text("Ask coaching question across roster...") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = CyanAccent
                        ),
                        trailingIcon = {
                            IconButton(
                                onClick = {
                                    val client = clients.firstOrNull { it.needsAttention } ?: clients.firstOrNull()
                                    if (client != null && globalQuery.isNotBlank()) {
                                        coroutineScope.launch {
                                            isQuerying = true
                                            queryError = null
                                            when (val res = intelligenceService.queryClientBrain(client, globalQuery)) {
                                                is AiResult.Success -> globalAiResponse = res.data
                                                is AiResult.NotConfigured -> queryError = res.message
                                                is AiResult.Error -> queryError = res.message
                                            }
                                            isQuerying = false
                                        }
                                    }
                                },
                                enabled = !isQuerying && globalQuery.isNotBlank()
                            ) {
                                Icon(Icons.Default.Send, contentDescription = "Query", tint = CyanAccent)
                            }
                        }
                    )

                    if (isQuerying) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = CyanAccent, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Analyzing client telemetry and coaching guidelines...", style = MaterialTheme.typography.bodySmall, color = CyanAccent)
                        }
                    }

                    if (queryError != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(queryError ?: "", style = MaterialTheme.typography.bodySmall, color = AmberWarning)
                    }

                    if (globalAiResponse != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = OnyxSurfaceHigh)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("AI Intelligence Output", style = MaterialTheme.typography.labelSmall, color = CyanAccent, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(globalAiResponse ?: "", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                            }
                        }
                    }
                }
            }
        }

        // Filter Tabs for Recommendations
        item {
            SectionHeader(title = "Next Best Action Recommendations")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(ActionStatus.PENDING, ActionStatus.APPROVED, ActionStatus.REJECTED).forEach { st ->
                    FilterChip(
                        selected = selectedStatusFilter == st,
                        onClick = { selectedStatusFilter = st },
                        label = { Text(st.name) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = when (st) {
                                ActionStatus.APPROVED -> EmeraldContainer
                                ActionStatus.REJECTED -> CrimsonContainer
                                else -> CyanContainer
                            },
                            selectedLabelColor = when (st) {
                                ActionStatus.APPROVED -> EmeraldPrimary
                                ActionStatus.REJECTED -> CrimsonError
                                else -> CyanAccent
                            },
                            containerColor = OnyxSurfaceElevated,
                            labelColor = TextSecondary
                        )
                    )
                }
            }
        }

        if (filteredRecommendations.isEmpty()) {
            item {
                EmptyStateView(
                    title = "No ${selectedStatusFilter.name.lowercase()} actions",
                    message = "All recommendations for this status have been reviewed.",
                    icon = Icons.Default.CheckCircle
                )
            }
        } else {
            items(filteredRecommendations, key = { it.id }) { rec ->
                AiRecommendationCard(
                    recommendation = rec,
                    onApprove = {
                        coroutineScope.launch {
                            repository.updateAiRecommendationStatus(rec.id, ActionStatus.APPROVED)
                        }
                    },
                    onEdit = {
                        coroutineScope.launch {
                            repository.updateAiRecommendationStatus(rec.id, ActionStatus.EDITED)
                        }
                    },
                    onReject = {
                        coroutineScope.launch {
                            repository.updateAiRecommendationStatus(rec.id, ActionStatus.REJECTED)
                        }
                    },
                    onAskWhy = {}
                )
            }
        }
    }
}
