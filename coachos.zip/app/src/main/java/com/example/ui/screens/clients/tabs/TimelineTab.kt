package com.example.ui.screens.clients.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.CoachRepository
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun TimelineTab(
    client: Client,
    trainerId: String,
    repository: CoachRepository,
    modifier: Modifier = Modifier
) {
    val timelineEvents: List<TimelineEvent> by repository.getTimelineForClient(trainerId, client.id).collectAsState(initial = emptyList())
    var selectedFilter by remember { mutableStateOf<TimelineEventType?>(null) }

    val filteredEvents = timelineEvents.filter {
        selectedFilter == null || it.eventType == selectedFilter
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Client Journey Timeline", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                Text("${timelineEvents.size} historical milestones recorded", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
        }

        // Filters
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FilterChip(
                selected = selectedFilter == null,
                onClick = { selectedFilter = null },
                label = { Text("All (${timelineEvents.size})") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = EmeraldContainer,
                    selectedLabelColor = EmeraldPrimary,
                    containerColor = OnyxSurfaceElevated,
                    labelColor = TextSecondary
                )
            )
            TimelineEventType.entries.forEach { type ->
                val count = timelineEvents.count { it.eventType == type }
                if (count > 0) {
                    FilterChip(
                        selected = selectedFilter == type,
                        onClick = { selectedFilter = type },
                        label = { Text("${type.label} ($count)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyanContainer,
                            selectedLabelColor = CyanAccent,
                            containerColor = OnyxSurfaceElevated,
                            labelColor = TextSecondary
                        )
                    )
                }
            }
        }

        // Timeline List
        if (filteredEvents.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.History, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No timeline milestones yet", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Text("Events will appear here as client records, assessments, and notes are logged", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(0.dp)
            ) {
                items(filteredEvents, key = { it.id }) { event ->
                    TimelineItemRow(event = event)
                }
            }
        }
    }
}

@Composable
private fun TimelineItemRow(event: TimelineEvent) {
    val (color, icon) = when (event.eventType) {
        TimelineEventType.CLIENT_JOINED -> Pair(CyanAccent, Icons.Default.PersonAdd)
        TimelineEventType.CONSULTATION_COMPLETED -> Pair(EmeraldPrimary, Icons.Default.AssignmentTurnedIn)
        TimelineEventType.HEALTH_SCREENING_COMPLETED -> Pair(AmberWarning, Icons.Default.HealthAndSafety)
        TimelineEventType.ASSESSMENT_RECORDED -> Pair(Color(0xFF38BDF8), Icons.Default.Analytics)
        TimelineEventType.MEASUREMENT_RECORDED -> Pair(EmeraldPrimary, Icons.Default.Straighten)
        TimelineEventType.PHOTO_UPLOADED -> Pair(Color(0xFFA78BFA), Icons.Default.CameraAlt)
        TimelineEventType.PROGRAMME_CREATED -> Pair(CyanAccent, Icons.Default.FitnessCenter)
        TimelineEventType.WORKOUT_COMPLETED -> Pair(EmeraldPrimary, Icons.Default.CheckCircle)
        TimelineEventType.CHECK_IN_SUBMITTED -> Pair(Color(0xFFFBBF24), Icons.Default.Assignment)
        TimelineEventType.PAYMENT_RECORDED -> Pair(EmeraldPrimary, Icons.Default.Payments)
        TimelineEventType.TRAINER_NOTE_ADDED -> Pair(TextSecondary, Icons.Default.EditNote)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        // Vertical Timeline line and Node
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.width(36.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.2f))
                    .border(1.5.dp, color, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            }
            Box(
                modifier = Modifier
                    .width(2.dp)
                    .height(60.dp)
                    .background(OnyxBorder)
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        // Card Content
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, OnyxBorder, RoundedCornerShape(14.dp)),
            colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = event.title,
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = event.date,
                        style = MaterialTheme.typography.labelSmall,
                        color = CyanAccent
                    )
                }

                if (event.description.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = event.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        lineHeight = 20.sp
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(color.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = event.eventType.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = color,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
