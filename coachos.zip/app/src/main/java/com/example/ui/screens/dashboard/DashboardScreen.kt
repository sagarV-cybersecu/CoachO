package com.example.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.CoachRepository
import com.example.data.session.SessionManager
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun DashboardScreen(
    trainerId: String,
    repository: CoachRepository,
    sessionManager: SessionManager,
    onClientClick: (String) -> Unit,
    onAddClientClick: () -> Unit,
    onViewAllClients: () -> Unit,
    onViewTodaySessions: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val clients by repository.getClients(trainerId).collectAsState(initial = emptyList())
    val attentionClients by repository.getClientsNeedingAttention(trainerId).collectAsState(initial = emptyList())
    val todaySessions by repository.getTodaySessions(trainerId).collectAsState(initial = emptyList())
    val aiRecommendations by repository.getAiRecommendations().collectAsState(initial = emptyList())

    val pendingAiRecommendations = remember(aiRecommendations) {
        aiRecommendations.filter { it.status == ActionStatus.PENDING }
    }

    var selectedEditRec by remember { mutableStateOf<AiRecommendation?>(null) }
    var editRecText by remember { mutableStateOf("") }

    if (selectedEditRec != null) {
        AlertDialog(
            onDismissRequest = { selectedEditRec = null },
            title = { Text("Edit AI Recommendation", color = TextPrimary) },
            text = {
                OutlinedTextField(
                    value = editRecText,
                    onValueChange = { editRecText = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Action Details") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val rec = selectedEditRec ?: return@Button
                        coroutineScope.launch {
                            repository.updateAiRecommendationStatus(rec.id, ActionStatus.EDITED)
                            selectedEditRec = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = Color.Black)
                ) {
                    Text("Save & Approve")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedEditRec = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = OnyxSurface
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OnyxBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Coach Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "WELCOME BACK,",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Coach ${sessionManager.getTrainerDisplayName().substringBefore(" ")}",
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(EmeraldContainer.copy(alpha = 0.4f))
                        .border(1.dp, EmeraldPrimary.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(EmeraldPrimary)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "LIVE SYSTEM",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Key Metrics 2x2 Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "Active Clients",
                        value = "${clients.count { it.status == ClientStatus.ACTIVE }}",
                        subtitle = "${clients.size} total on roster",
                        icon = Icons.Default.People,
                        accentColor = CyanAccent,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("stat_active_clients"),
                        onClick = onViewAllClients
                    )

                    StatCard(
                        title = "Today's Sessions",
                        value = "${todaySessions.size}",
                        subtitle = "${todaySessions.count { it.status == SessionStatus.COMPLETED }} completed",
                        icon = Icons.Default.CalendarToday,
                        accentColor = EmeraldPrimary,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("stat_today_sessions"),
                        onClick = onViewTodaySessions
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "Needs Attention",
                        value = "${attentionClients.size}",
                        subtitle = "Plateau & attendance alerts",
                        icon = Icons.Default.WarningAmber,
                        accentColor = AmberWarning,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("stat_needs_attention")
                    )

                    val avgAttendance = if (clients.isNotEmpty()) {
                        clients.map { it.attendanceRatePercent }.average().toInt()
                    } else 0

                    StatCard(
                        title = "Attendance Rate",
                        value = "$avgAttendance%",
                        subtitle = "Last 30-day average",
                        icon = Icons.Default.TrendingUp,
                        accentColor = EmeraldPrimary,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("stat_attendance")
                    )
                }
            }
        }

        // AI Coaching Priorities (Trainer in Control)
        if (pendingAiRecommendations.isNotEmpty()) {
            item {
                SectionHeader(
                    title = "AI Coaching Priorities",
                    actionLabel = "${pendingAiRecommendations.size} pending review"
                )
            }

            items(pendingAiRecommendations, key = { it.id }) { rec ->
                AiRecommendationCard(
                    recommendation = rec,
                    onApprove = {
                        coroutineScope.launch {
                            repository.updateAiRecommendationStatus(rec.id, ActionStatus.APPROVED)
                        }
                    },
                    onEdit = {
                        selectedEditRec = rec
                        editRecText = rec.recommendation
                    },
                    onReject = {
                        coroutineScope.launch {
                            repository.updateAiRecommendationStatus(rec.id, ActionStatus.REJECTED)
                        }
                    },
                    onAskWhy = { /* Toggled directly in card */ }
                )
            }
        }

        // Clients Needing Attention
        item {
            SectionHeader(
                title = "Clients Needing Attention",
                actionLabel = "View Roster",
                onActionClick = onViewAllClients
            )
        }

        if (attentionClients.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "All clients are on track. No flags or pending issues.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }
            }
        } else {
            items(attentionClients, key = { it.id }) { client ->
                ClientListItemCard(
                    client = client,
                    onClick = { onClientClick(client.id) }
                )
            }
        }

        // Today's Scheduled Sessions Preview
        item {
            SectionHeader(
                title = "Today's Schedule",
                actionLabel = "Manage Schedule",
                onActionClick = onViewTodaySessions
            )
        }

        if (todaySessions.isEmpty()) {
            item {
                EmptyStateView(
                    title = "No sessions scheduled today",
                    message = "Your training schedule is clear for today.",
                    icon = Icons.Default.CalendarToday
                )
            }
        } else {
            items(todaySessions, key = { it.id }) { session ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, OnyxBorder, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = session.sessionTimeText,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = EmeraldPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "• ${session.clientName}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${session.sessionFocus} • ${session.location}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }

                        // Quick Status Button
                        IconButton(
                            onClick = {
                                val nextStatus = if (session.status == SessionStatus.COMPLETED)
                                    SessionStatus.SCHEDULED
                                else
                                    SessionStatus.COMPLETED
                                coroutineScope.launch {
                                    repository.updateSessionStatus(session, nextStatus)
                                }
                            }
                        ) {
                            Icon(
                                imageVector = if (session.status == SessionStatus.COMPLETED)
                                    Icons.Default.CheckCircle
                                else
                                    Icons.Default.RadioButtonUnchecked,
                                contentDescription = "Toggle session completion",
                                tint = if (session.status == SessionStatus.COMPLETED) EmeraldPrimary else TextMuted
                            )
                        }
                    }
                }
            }
        }
    }
}
