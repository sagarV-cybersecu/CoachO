package com.example.ui.screens.clients

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.AiResult
import com.example.ai.ClientIntelligenceService
import com.example.data.repository.CoachRepository
import com.example.model.*
import com.example.ui.components.EmptyStateView
import com.example.ui.components.ReadinessBadge
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.ui.screens.clients.tabs.*
import kotlinx.coroutines.launch
import java.util.UUID

enum class ClientDetailTab(val label: String) {
    OVERVIEW("Overview"),
    PERSONAL_INFO("Personal"),
    CONSULTATION("Consultation"),
    HEALTH_SCREENING("Health (PAR-Q)"),
    GOALS("Goals"),
    LIFESTYLE("Lifestyle"),
    ASSESSMENTS("Assessments"),
    MEASUREMENTS("Measurements"),
    PROGRESS_PHOTOS("Photos"),
    NOTES("Notes"),
    TIMELINE("Timeline"),
    AI_BRAIN("AI Coach")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClientDetailScreen(
    trainerId: String,
    clientId: String,
    repository: CoachRepository,
    intelligenceService: ClientIntelligenceService,
    onBack: () -> Unit,
    onEditClient: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val client by repository.getClientById(trainerId, clientId).collectAsState(initial = null)
    val notes by repository.getNotesForClient(trainerId, clientId).collectAsState(initial = emptyList())

    var selectedTab by remember { mutableStateOf(ClientDetailTab.OVERVIEW) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showAddNoteDialog by remember { mutableStateOf(false) }

    // AI Brain State
    var aiQuery by remember { mutableStateOf("") }
    var aiResponse by remember { mutableStateOf<String?>(null) }
    var isAiLoading by remember { mutableStateOf(false) }
    var aiError by remember { mutableStateOf<String?>(null) }

    if (client == null) {
        Box(modifier = Modifier.fillMaxSize().background(OnyxBackground), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = EmeraldPrimary)
        }
        return
    }

    val currentClient = client!!

    // Add Note Dialog
    if (showAddNoteDialog) {
        var noteTitle by remember { mutableStateOf("") }
        var noteContent by remember { mutableStateOf("") }
        var noteCategory by remember { mutableStateOf(NoteCategory.COACHING) }

        AlertDialog(
            onDismissRequest = { showAddNoteDialog = false },
            title = { Text("Add Client Note", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = noteTitle,
                        onValueChange = { noteTitle = it },
                        label = { Text("Note Title") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    OutlinedTextField(
                        value = noteContent,
                        onValueChange = { noteContent = it },
                        label = { Text("Details & Observations") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        NoteCategory.entries.forEach { cat ->
                            FilterChip(
                                selected = noteCategory == cat,
                                onClick = { noteCategory = cat },
                                label = { Text(cat.name.replace("_", " "), fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EmeraldContainer,
                                    selectedLabelColor = EmeraldPrimary,
                                    containerColor = OnyxSurfaceHigh,
                                    labelColor = TextSecondary
                                )
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (noteTitle.isNotBlank()) {
                            coroutineScope.launch {
                                repository.addNote(
                                    ClientNote(
                                        id = UUID.randomUUID().toString(),
                                        clientId = currentClient.id,
                                        trainerId = trainerId,
                                        title = noteTitle.trim(),
                                        content = noteContent.trim(),
                                        category = noteCategory,
                                        createdAt = System.currentTimeMillis()
                                    )
                                )
                                showAddNoteDialog = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = Color.Black)
                ) {
                    Text("Save Note")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddNoteDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = OnyxSurface
        )
    }

    // Delete Client Confirmation
    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Client Profile?", color = TextPrimary) },
            text = {
                Text(
                    "Are you sure you want to delete ${currentClient.fullName}? All associated notes and records will be permanently removed.",
                    color = TextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            repository.deleteClient(trainerId, currentClient.id)
                            showDeleteConfirm = false
                            onBack()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonError, contentColor = Color.White)
                ) {
                    Text("Delete Permanently")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = OnyxSurface
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = currentClient.fullName,
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("btn_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                actions = {
                    IconButton(
                        onClick = { onEditClient(currentClient.id) },
                        modifier = Modifier.testTag("btn_edit_client")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Client", tint = CyanAccent)
                    }
                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete Client", tint = CrimsonError)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = OnyxBackground)
            )
        },
        containerColor = OnyxBackground,
        modifier = modifier.fillMaxSize()
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Client Summary Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, OnyxBorder, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val initials = currentClient.fullName.split(" ")
                            .mapNotNull { it.firstOrNull()?.toString() }
                            .take(2)
                            .joinToString("")

                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(CircleShape)
                                .background(CyanContainer)
                                .border(1.5.dp, CyanAccent, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = initials.ifEmpty { "C" },
                                style = MaterialTheme.typography.headlineSmall,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = currentClient.primaryGoal,
                                style = MaterialTheme.typography.titleMedium,
                                color = EmeraldPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = currentClient.currentProgram,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                ReadinessBadge(readiness = currentClient.readinessScore)
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(OnyxSurfaceHigh)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = currentClient.fitnessLevel.name,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Package Sessions Progress
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Package Sessions",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                        Text(
                            text = "${currentClient.sessionsCompleted} completed • ${currentClient.packageRemainingSessions} remaining",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (currentClient.packageRemainingSessions <= 4) AmberWarning else TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    val progress = if (currentClient.packageTotalSessions > 0)
                        (currentClient.sessionsCompleted.toFloat() / currentClient.packageTotalSessions.toFloat()).coerceIn(0f, 1f)
                    else 0f

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = EmeraldPrimary,
                        trackColor = OnyxSurfaceHigh
                    )

                    if (currentClient.needsAttention && !currentClient.attentionReason.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(AmberContainer.copy(alpha = 0.3f))
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.WarningAmber, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = currentClient.attentionReason ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFFDE68A)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Navigation Tabs (Scrollable)
            ScrollableTabRow(
                selectedTabIndex = selectedTab.ordinal,
                containerColor = OnyxBackground,
                contentColor = EmeraldPrimary,
                edgePadding = 16.dp,
                divider = {}
            ) {
                ClientDetailTab.entries.forEach { tab ->
                    Tab(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        text = {
                            Text(
                                text = tab.label,
                                color = if (selectedTab == tab) EmeraldPrimary else TextSecondary,
                                fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Tab Content
            when (selectedTab) {
                ClientDetailTab.OVERVIEW -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        SectionHeader(title = "Health & Readiness")
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = "Readiness: ${currentClient.readinessScore}",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = EmeraldPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = currentClient.readinessReason,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                            }
                        }

                        SectionHeader(title = "Metrics & Adherence")
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Current Weight", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                    Text("${currentClient.currentWeightKg} kg", style = MaterialTheme.typography.titleLarge, color = TextPrimary, fontWeight = FontWeight.Bold)
                                    Text("Target: ${currentClient.targetWeightKg} kg", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                }
                            }
                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Attendance", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                    Text("${currentClient.attendanceRatePercent}%", style = MaterialTheme.typography.titleLarge, color = EmeraldPrimary, fontWeight = FontWeight.Bold)
                                    Text("Last: ${currentClient.lastWorkoutDate}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                }
                            }
                        }

                        if (currentClient.notesSummary.isNotBlank()) {
                            SectionHeader(title = "Coach Summary")
                            Text(
                                text = currentClient.notesSummary,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary
                            )
                        }
                    }
                }

                ClientDetailTab.PERSONAL_INFO -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        InfoRow(label = "Full Name", value = currentClient.fullName)
                        InfoRow(label = "Email Address", value = currentClient.email)
                        InfoRow(label = "Phone", value = currentClient.phone)
                        InfoRow(label = "Occupation", value = currentClient.occupation.ifEmpty { "Not specified" })
                        InfoRow(label = "Date of Birth", value = currentClient.dateOfBirth)
                        InfoRow(label = "Gender", value = currentClient.gender)
                        InfoRow(label = "Timeline Target", value = "${currentClient.targetTimelineWeeks} weeks")
                        InfoRow(label = "Account Status", value = currentClient.status.name)
                    }
                }

                ClientDetailTab.CONSULTATION -> {
                    ConsultationTab(
                        client = currentClient,
                        trainerId = trainerId,
                        repository = repository
                    )
                }

                ClientDetailTab.HEALTH_SCREENING -> {
                    HealthScreeningTab(
                        client = currentClient,
                        trainerId = trainerId,
                        repository = repository
                    )
                }

                ClientDetailTab.GOALS -> {
                    GoalsTab(
                        client = currentClient,
                        trainerId = trainerId,
                        repository = repository
                    )
                }

                ClientDetailTab.LIFESTYLE -> {
                    LifestyleTab(
                        client = currentClient,
                        trainerId = trainerId,
                        repository = repository
                    )
                }

                ClientDetailTab.ASSESSMENTS -> {
                    AssessmentsTab(
                        client = currentClient,
                        trainerId = trainerId,
                        repository = repository
                    )
                }

                ClientDetailTab.MEASUREMENTS -> {
                    MeasurementsTab(
                        client = currentClient,
                        trainerId = trainerId,
                        repository = repository
                    )
                }

                ClientDetailTab.PROGRESS_PHOTOS -> {
                    ProgressPhotosTab(
                        client = currentClient,
                        trainerId = trainerId,
                        repository = repository
                    )
                }

                ClientDetailTab.NOTES -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Coaching Notes (${notes.size})", style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                            Button(
                                onClick = { showAddNoteDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = Color.Black),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add Note", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        if (notes.isEmpty()) {
                            EmptyStateView(
                                title = "No notes recorded yet",
                                message = "Track biomechanical observations, nutrition check-ins, or injury precautions.",
                                icon = Icons.Default.EditNote
                            )
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(notes, key = { it.id }) { note ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(note.title, style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
                                                IconButton(
                                                    onClick = { coroutineScope.launch { repository.deleteNote(trainerId, note.id) } },
                                                    modifier = Modifier.size(24.dp)
                                                ) {
                                                    Icon(Icons.Default.Close, contentDescription = "Delete note", tint = TextMuted, modifier = Modifier.size(14.dp))
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(note.content, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .background(OnyxSurfaceHigh)
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(note.category.name, style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                ClientDetailTab.AI_BRAIN -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .border(1.dp, CyanAccent.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
                            colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Psychology, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(24.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Client Digital Twin & Intelligence",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = CyanAccent,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Ask questions about ${currentClient.fullName}'s readiness, progress plateaus, or get tailored session focus.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                // Fast prompt chips
                                Text("Suggested Queries:", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    val quickQueries = listOf(
                                        "Analyze recent progress & plateaus",
                                        "Generate today's workout focus",
                                        "Why is readiness ${currentClient.readinessScore}?",
                                        "Suggest volume adjustment"
                                    )
                                    quickQueries.forEach { q ->
                                        SuggestionChip(
                                            onClick = {
                                                aiQuery = q
                                                coroutineScope.launch {
                                                    isAiLoading = true
                                                    aiError = null
                                                    when (val res = intelligenceService.queryClientBrain(currentClient, q)) {
                                                        is AiResult.Success -> aiResponse = res.data
                                                        is AiResult.NotConfigured -> aiError = res.message
                                                        is AiResult.Error -> aiError = res.message
                                                    }
                                                    isAiLoading = false
                                                }
                                            },
                                            label = { Text(q, fontSize = 11.sp, color = TextPrimary) },
                                            colors = SuggestionChipDefaults.suggestionChipColors(
                                                containerColor = OnyxSurfaceHigh
                                            )
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                OutlinedTextField(
                                    value = aiQuery,
                                    onValueChange = { aiQuery = it },
                                    label = { Text("Ask CoachOS AI about ${currentClient.fullName.substringBefore(" ")}") },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary,
                                        focusedBorderColor = CyanAccent
                                    ),
                                    trailingIcon = {
                                        IconButton(
                                            onClick = {
                                                if (aiQuery.isNotBlank()) {
                                                    coroutineScope.launch {
                                                        isAiLoading = true
                                                        aiError = null
                                                        when (val res = intelligenceService.queryClientBrain(currentClient, aiQuery)) {
                                                            is AiResult.Success -> aiResponse = res.data
                                                            is AiResult.NotConfigured -> aiError = res.message
                                                            is AiResult.Error -> aiError = res.message
                                                        }
                                                        isAiLoading = false
                                                    }
                                                }
                                            },
                                            enabled = !isAiLoading && aiQuery.isNotBlank()
                                        ) {
                                            Icon(Icons.Default.Send, contentDescription = "Query AI", tint = CyanAccent)
                                        }
                                    }
                                )

                                if (isAiLoading) {
                                    Spacer(modifier = Modifier.height(14.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = CyanAccent, strokeWidth = 2.dp)
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text("Synthesizing client metrics with coaching philosophy...", style = MaterialTheme.typography.bodySmall, color = CyanAccent)
                                    }
                                }

                                if (aiError != null) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = AmberContainer.copy(alpha = 0.3f))
                                    ) {
                                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Info, contentDescription = null, tint = AmberWarning)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(aiError ?: "", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                                        }
                                    }
                                }

                                if (aiResponse != null) {
                                    Spacer(modifier = Modifier.height(14.dp))
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = OnyxSurfaceHigh)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp)) {
                                            Text("AI Analysis & Recommendations", style = MaterialTheme.typography.labelSmall, color = CyanAccent, fontWeight = FontWeight.Bold)
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(aiResponse ?: "", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                ClientDetailTab.TIMELINE -> {
                    TimelineTab(
                        client = currentClient,
                        trainerId = trainerId,
                        repository = repository
                    )
                }
            }
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            Text(value, style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun StagePlaceholderCard(title: String, stage: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = OnyxSurfaceElevated)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(OnyxSurfaceHigh)
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(stage, style = MaterialTheme.typography.labelSmall, color = CyanAccent, fontWeight = FontWeight.Bold)
            }
        }
    }
}
