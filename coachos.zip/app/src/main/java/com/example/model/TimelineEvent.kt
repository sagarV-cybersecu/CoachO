package com.example.model

enum class TimelineEventType(val label: String) {
    CLIENT_JOINED("Client Joined"),
    CONSULTATION_COMPLETED("Consultation Completed"),
    HEALTH_SCREENING_COMPLETED("Health Screening Completed"),
    ASSESSMENT_RECORDED("Assessment Recorded"),
    MEASUREMENT_RECORDED("Measurement Recorded"),
    PHOTO_UPLOADED("Photo Uploaded"),
    PROGRAMME_CREATED("Programme Created"),
    WORKOUT_COMPLETED("Workout Completed"),
    CHECK_IN_SUBMITTED("Check-in Submitted"),
    PAYMENT_RECORDED("Payment Recorded"),
    TRAINER_NOTE_ADDED("Trainer Note Added")
}

data class TimelineEvent(
    val id: String,
    val clientId: String,
    val trainerId: String,
    val eventType: TimelineEventType,
    val title: String,
    val description: String,
    val date: String,
    val timestamp: Long = System.currentTimeMillis()
)
