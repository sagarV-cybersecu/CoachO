package com.example.model

enum class ActionPriority {
    HIGH,
    MEDIUM,
    LOW
}

enum class ActionStatus {
    PENDING,
    APPROVED,
    EDITED,
    REJECTED,
    SNOOZED
}

data class AiRecommendation(
    val id: String,
    val clientId: String,
    val clientName: String,
    val priority: ActionPriority,
    val recommendation: String,
    val reason: String,
    val supportingData: List<String>,
    val confidence: String, // "High", "Medium", "Low"
    val considerations: List<String>,
    val status: ActionStatus = ActionStatus.PENDING,
    val timestamp: Long = System.currentTimeMillis()
)
