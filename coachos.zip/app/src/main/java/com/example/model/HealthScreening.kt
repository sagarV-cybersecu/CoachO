package com.example.model

enum class ScreeningReviewStatus(val label: String) {
    CLEAR("Clear"),
    REVIEW_REQUIRED("Review Required"),
    PROFESSIONAL_CLEARANCE_RECOMMENDED("Professional Clearance Recommended")
}

data class ScreeningQuestion(
    val id: String,
    val questionText: String,
    val answerYes: Boolean = false,
    val followUpPrompt: String = "",
    val followUpAnswer: String = "",
    val notes: String = ""
)

data class HealthScreening(
    val clientId: String,
    val trainerId: String,
    val date: String,
    val reviewStatus: ScreeningReviewStatus = ScreeningReviewStatus.CLEAR,
    val questions: List<ScreeningQuestion> = defaultScreeningQuestions(),
    val trainerNotes: String = "",
    val disclaimerAcknowledged: Boolean = true,
    val updatedAt: Long = System.currentTimeMillis()
) {
    companion object {
        fun defaultScreeningQuestions(): List<ScreeningQuestion> = listOf(
            ScreeningQuestion(
                id = "q1_heart",
                questionText = "Has a doctor ever said you have a heart condition or high blood pressure?",
                followUpPrompt = "Specify diagnosis, medications, or any activity restrictions prescribed by your physician:"
            ),
            ScreeningQuestion(
                id = "q2_chest_pain",
                questionText = "Do you ever experience chest pain or pressure during physical activity or at rest?",
                followUpPrompt = "Describe the frequency, intensity, and circumstances under which chest discomfort occurs:"
            ),
            ScreeningQuestion(
                id = "q3_dizziness",
                questionText = "Do you ever feel faint, dizzy, or lose balance during exercise?",
                followUpPrompt = "When does dizziness occur (e.g. standing up quickly, heavy exertion) and how often?"
            ),
            ScreeningQuestion(
                id = "q4_joint_injury",
                questionText = "Do you have any bone, joint, or spinal problems that could be aggravated by physical activity?",
                followUpPrompt = "Specify affected joints (knees, lumbar spine, shoulders) and movements that cause pain:"
            ),
            ScreeningQuestion(
                id = "q5_medications",
                questionText = "Are you currently taking any prescription medications that alter heart rate, blood pressure, or hydration?",
                followUpPrompt = "List medications (e.g., beta blockers, diuretics, asthma inhalers) and dosages:"
            ),
            ScreeningQuestion(
                id = "q6_chronic_condition",
                questionText = "Do you have any chronic medical condition (e.g. diabetes, asthma, epilepsy, metabolic disorders)?",
                followUpPrompt = "Provide details on condition management, emergency protocols, and monitoring:"
            ),
            ScreeningQuestion(
                id = "q7_recent_surgery",
                questionText = "Have you had any surgery, serious injury, or medical hospitalization in the last 12 months?",
                followUpPrompt = "Specify surgical procedure, date, rehab status, and if doctor clearance was provided:"
            ),
            ScreeningQuestion(
                id = "q8_other_reason",
                questionText = "Do you know of any other physical reason why you should not undergo physical exercise?",
                followUpPrompt = "Please explain any other health concerns or physical limitations:"
            )
        )
    }
}
