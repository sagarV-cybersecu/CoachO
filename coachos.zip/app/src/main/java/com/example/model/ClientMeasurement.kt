package com.example.model

enum class MeasurementType(val label: String, val defaultUnit: String) {
    WEIGHT("Body Weight", "kg"),
    HEIGHT("Height", "cm"),
    WAIST("Waist", "cm"),
    HIP("Hip", "cm"),
    CHEST("Chest", "cm"),
    ARM("Arm (Biceps)", "cm"),
    THIGH("Thigh", "cm"),
    BODY_FAT_PERCENT("Body Fat", "%"),
    RESTING_HEART_RATE("Resting Heart Rate", "bpm"),
    CUSTOM("Custom Measurement", "")
}

data class ClientMeasurement(
    val id: String,
    val clientId: String,
    val trainerId: String,
    val type: MeasurementType,
    val customTypeName: String? = null,
    val value: Double,
    val unit: String,
    val date: String,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
