package com.example.model

enum class ClientStatus {
    ACTIVE,
    NEEDS_ATTENTION,
    ON_HOLD,
    ARCHIVED
}

enum class PrimaryGoalType {
    FAT_LOSS,
    MUSCLE_GAIN,
    STRENGTH,
    BODY_RECOMPOSITION,
    ATHLETIC_PERFORMANCE,
    MOBILITY_HEALTH
}

enum class FitnessLevel {
    BEGINNER,
    INTERMEDIATE,
    ADVANCED
}

data class Client(
    val id: String,
    val trainerId: String,
    val fullName: String,
    val email: String,
    val phone: String,
    val avatarUrl: String? = null,
    val primaryGoal: String,
    val goalType: PrimaryGoalType = PrimaryGoalType.BODY_RECOMPOSITION,
    val currentProgram: String = "Hypertrophy Phase 1",
    val status: ClientStatus = ClientStatus.ACTIVE,
    val fitnessLevel: FitnessLevel = FitnessLevel.INTERMEDIATE,
    val dateOfBirth: String = "1994-05-12",
    val gender: String = "Unspecified",
    val occupation: String = "",
    val targetTimelineWeeks: Int = 12,
    val packageTotalSessions: Int = 20,
    val packageRemainingSessions: Int = 14,
    val sessionsCompleted: Int = 6,
    val attendanceRatePercent: Int = 92,
    val lastWorkoutDate: String = "Yesterday",
    val lastCheckInDate: String = "3 days ago",
    val needsAttention: Boolean = false,
    val attentionReason: String? = null,
    val readinessScore: String = "READY", // READY, MODERATE, RECOVERY FOCUS
    val readinessReason: String = "Good sleep (7.5h) and consistent energy reported",
    val currentWeightKg: Double = 76.5,
    val targetWeightKg: Double = 72.0,
    val notesSummary: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
