package com.example.model

enum class PhotoCategory(val label: String) {
    FRONT("Front"),
    BACK("Back"),
    LEFT("Left Side"),
    RIGHT("Right Side"),
    CUSTOM("Custom")
}

data class ProgressPhoto(
    val id: String,
    val clientId: String,
    val trainerId: String,
    val photoUri: String,
    val category: PhotoCategory,
    val customCategoryName: String? = null,
    val date: String,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
