package com.example.model

enum class ExerciseStructure(val label: String) {
    STANDARD("Standard Sets"),
    SUPERSET("Superset"),
    CIRCUIT("Circuit"),
    DROPSET("Drop Set"),
    AMRAP("AMRAP"),
    TIMED("Timed Interval")
}

data class TrainingDay(
    val id: String,
    val programmeId: String,
    val dayName: String, // e.g. "Day 1: Upper Body Strength"
    val dayOfWeek: String = "Monday",
    val orderIndex: Int = 0,
    val focusNotes: String = ""
)

data class WorkoutExercise(
    val id: String,
    val workoutDayId: String,
    val exerciseId: String,
    val exerciseName: String,
    val orderIndex: Int = 0,
    val isWarmup: Boolean = false,
    val exerciseStructure: ExerciseStructure = ExerciseStructure.STANDARD,
    val groupTag: String = "", // e.g. "A1", "A2", "B1"
    val targetSets: Int = 3,
    val targetReps: String = "8-10",
    val targetWeightKg: Double? = null,
    val targetDurationSec: Int? = null,
    val targetDistanceMeters: Double? = null,
    val restSec: Int = 90,
    val tempo: String = "3-0-1-0",
    val targetRpe: Double? = 8.0,
    val notes: String = ""
)
