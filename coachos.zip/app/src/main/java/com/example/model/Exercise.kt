package com.example.model

enum class ExerciseCategory(val label: String) {
    STRENGTH("Strength"),
    HYPERTROPHY("Hypertrophy"),
    CARDIO("Cardio"),
    MOBILITY("Mobility"),
    WARM_UP("Warm-up"),
    CORE("Core"),
    CONDITIONING("Conditioning"),
    RECOVERY("Recovery"),
    CUSTOM("Custom")
}

enum class MuscleGroup(val label: String) {
    CHEST("Chest"),
    BACK("Back"),
    LATS("Lats"),
    SHOULDERS("Shoulders"),
    BICEPS("Biceps"),
    TRICEPS("Triceps"),
    QUADS("Quads"),
    HAMSTRINGS("Hamstrings"),
    GLUTES("Glutes"),
    CALVES("Calves"),
    CORE("Core / Abs"),
    FULL_BODY("Full Body")
}

enum class MovementPattern(val label: String) {
    SQUAT("Squat"),
    HINGE("Hinge"),
    PUSH_HORIZONTAL("Horizontal Push"),
    PUSH_VERTICAL("Vertical Push"),
    PULL_HORIZONTAL("Horizontal Pull"),
    PULL_VERTICAL("Vertical Pull"),
    LUNGE("Lunge / Unilateral"),
    CARRY("Carry / Locomotion"),
    ROTATION("Rotational / Anti-Rotation"),
    ISOLATION("Isolation"),
    CARDIO("Cardiovascular")
}

enum class EquipmentType(val label: String) {
    BARBELL("Barbell"),
    DUMBBELL("Dumbbell"),
    KETTLEBELL("Kettlebell"),
    CABLE("Cable Machine"),
    MACHINE("Plate / Pin Machine"),
    BODYWEIGHT("Bodyweight"),
    RESISTANCE_BAND("Resistance Band"),
    SMITH_MACHINE("Smith Machine"),
    TRAP_BAR("Trap Bar"),
    CARDIO_MACHINE("Cardio Machine"),
    OTHER("Other / Freeform")
}

enum class ExerciseDifficulty(val label: String) {
    BEGINNER("Beginner"),
    INTERMEDIATE("Intermediate"),
    ADVANCED("Advanced")
}

data class Exercise(
    val id: String,
    val trainerId: String? = null, // null for standard library, non-null for custom
    val name: String,
    val category: ExerciseCategory,
    val primaryMuscle: MuscleGroup,
    val secondaryMuscles: List<MuscleGroup> = emptyList(),
    val movementPattern: MovementPattern,
    val equipment: EquipmentType,
    val difficulty: ExerciseDifficulty = ExerciseDifficulty.INTERMEDIATE,
    val instructions: List<String> = emptyList(),
    val coachingCues: List<String> = emptyList(),
    val commonMistakes: List<String> = emptyList(),
    val trainerNotes: String = "",
    val alternativeExerciseIds: List<String> = emptyList(),
    val videoReference: String = "",
    val isCustom: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
