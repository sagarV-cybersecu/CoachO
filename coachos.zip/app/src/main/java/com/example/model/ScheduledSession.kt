package com.example.model

enum class SessionStatus {
    SCHEDULED,
    COMPLETED,
    NO_SHOW,
    CANCELLED,
    RESCHEDULED
}

data class ScheduledSession(
    val id: String,
    val trainerId: String,
    val clientId: String,
    val clientName: String,
    val sessionTimeText: String, // e.g. "09:00 AM"
    val sessionDateText: String, // e.g. "Today" or "2026-09-08"
    val durationMinutes: Int = 60,
    val status: SessionStatus = SessionStatus.SCHEDULED,
    val sessionFocus: String = "Upper Body Hypertrophy",
    val location: String = "Main Gym / Weight Room",
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
