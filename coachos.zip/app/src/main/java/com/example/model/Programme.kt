package com.example.model

enum class ProgrammeGoal(val label: String) {
    HYPERTROPHY("Hypertrophy / Muscle Building"),
    STRENGTH("Max Strength & Power"),
    FAT_LOSS("Fat Loss & Conditioning"),
    ATHLETIC_PERFORMANCE("Athletic Performance"),
    RECOMPOSITION("Body Recomposition"),
    GENERAL_FITNESS("General Fitness & Health"),
    REHABILITATION("Rehabilitation & Longevity")
}

enum class ProgrammeStatus(val label: String) {
    DRAFT("Draft"),
    ACTIVE("Active"),
    COMPLETED("Completed"),
    ARCHIVED("Archived"),
    TEMPLATE("Template")
}

data class Programme(
    val id: String,
    val trainerId: String,
    val clientId: String? = null, // null for reusable templates
    val name: String,
    val goal: ProgrammeGoal = ProgrammeGoal.HYPERTROPHY,
    val durationWeeks: Int = 8,
    val weeklyFrequency: Int = 4,
    val startDate: String = "",
    val endDate: String = "",
    val notes: String = "",
    val isTemplate: Boolean = false,
    val version: Int = 1,
    val parentProgrammeId: String? = null,
    val status: ProgrammeStatus = ProgrammeStatus.ACTIVE,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class ProgrammeVersion(
    val id: String,
    val programmeId: String,
    val trainerId: String,
    val versionNumber: Int,
    val date: String,
    val changesSummary: String,
    val reasonForChange: String,
    val snapshotJson: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
