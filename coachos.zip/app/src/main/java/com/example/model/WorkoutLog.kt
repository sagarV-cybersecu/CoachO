package com.example.model

enum class LoggedSetType(val label: String) {
    NORMAL("Normal"),
    WARMUP("Warmup"),
    DROP("Drop Set"),
    FAILURE("To Failure")
}

data class LoggedSet(
    val id: String,
    val workoutLogId: String,
    val exerciseId: String,
    val exerciseName: String,
    val setNumber: Int,
    val plannedWeightKg: Double? = null,
    val plannedReps: Int? = null,
    val plannedRpe: Double? = null,
    val actualWeightKg: Double = 0.0,
    val actualReps: Int = 0,
    val actualRpe: Double? = null,
    val actualDurationSec: Int? = null,
    val setType: LoggedSetType = LoggedSetType.NORMAL,
    val isCompleted: Boolean = true,
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    // Calculated progression metrics
    val volumeKg: Double
        get() = if (isCompleted && actualWeightKg > 0 && actualReps > 0) actualWeightKg * actualReps else 0.0

    // Estimated 1RM using Brzycki / Epley formula
    // For reps == 1, 1RM is 100% of weight. For reps between 2 and 10, Epley formula: weight * (1 + reps / 30.0)
    val estimatedOneRepMaxKg: Double
        get() {
            if (!isCompleted || actualWeightKg <= 0.0 || actualReps <= 0) return 0.0
            return when {
                actualReps == 1 -> actualWeightKg
                actualReps in 2..15 -> Math.round(actualWeightKg * (1.0 + (actualReps / 30.0)) * 10.0) / 10.0
                else -> Math.round(actualWeightKg * (36.0 / (37.0 - actualReps.coerceAtMost(30))) * 10.0) / 10.0
            }
        }
}

data class WorkoutLog(
    val id: String,
    val trainerId: String,
    val clientId: String,
    val programmeId: String? = null,
    val workoutDayId: String? = null,
    val workoutTitle: String,
    val date: String,
    val startTimeMs: Long = System.currentTimeMillis(),
    val endTimeMs: Long? = null,
    val durationMinutes: Int = 0,
    val totalVolumeKg: Double = 0.0, // Calculated sum of completed set volumes
    val totalReps: Int = 0, // Calculated sum of completed reps
    val totalSetsCompleted: Int = 0,
    val completionPercentage: Int = 100,
    val averageRpe: Double? = null,
    val sessionNotes: String = "",
    val isCompleted: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

data class ExerciseProgressionSummary(
    val exerciseId: String,
    val exerciseName: String,
    val totalSessionsLogged: Int,
    val personalRecordWeightKg: Double,
    val personalRecordEstimated1RMKg: Double,
    val bestSetVolumeKg: Double,
    val lastWeightKg: Double,
    val lastReps: Int,
    val historyDataPoints: List<ProgressionDataPoint> = emptyList()
)

data class ProgressionDataPoint(
    val date: String,
    val weightKg: Double,
    val reps: Int,
    val estimated1RMKg: Double,
    val totalSessionVolumeKg: Double
)
