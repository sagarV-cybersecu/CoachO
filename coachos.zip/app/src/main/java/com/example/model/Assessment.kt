package com.example.model

enum class AssessmentCategory(val label: String) {
    BODY_MEASUREMENTS("Body Measurements"),
    BODY_COMPOSITION("Body Composition"),
    STRENGTH("Strength"),
    ENDURANCE("Endurance"),
    MOBILITY("Mobility"),
    FLEXIBILITY("Flexibility"),
    MOVEMENT_OBSERVATIONS("Movement Observations"),
    FITNESS_TESTS("Fitness Tests"),
    CUSTOM("Custom")
}

data class AssessmentItem(
    val id: String,
    val category: AssessmentCategory,
    val testName: String,
    val resultValue: String,
    val unit: String = "",
    val baselineValue: String? = null,
    val notes: String = ""
)

data class AssessmentSession(
    val id: String,
    val clientId: String,
    val trainerId: String,
    val title: String,
    val date: String,
    val isBaseline: Boolean = false,
    val selectedCategories: List<AssessmentCategory> = listOf(
        AssessmentCategory.MOVEMENT_OBSERVATIONS,
        AssessmentCategory.STRENGTH,
        AssessmentCategory.MOBILITY
    ),
    val items: List<AssessmentItem> = emptyList(),
    val summaryObservations: String = "",
    val trainerRecommendations: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
