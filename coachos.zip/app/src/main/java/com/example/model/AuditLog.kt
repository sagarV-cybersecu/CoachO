package com.example.model

data class AuditLog(
    val id: String,
    val trainerId: String,
    val action: String,
    val entityType: String,
    val entityId: String,
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)
