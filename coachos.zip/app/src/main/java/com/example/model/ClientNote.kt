package com.example.model

enum class NoteCategory(val label: String) {
    TRAINING("Training"),
    NUTRITION("Nutrition"),
    LIFESTYLE("Lifestyle"),
    PROGRESS("Progress"),
    GENERAL("General"),
    IMPORTANT("Important"),
    COACHING("Coaching"),
    TECHNIQUE("Technique"),
    INJURY_PREVENTION("Injury Prevention"),
    MINDSET("Mindset"),
    ADMINISTRATIVE("Administrative")
}

enum class NoteType(val label: String) {
    QUICK("Quick Note"),
    DETAILED("Detailed Note")
}

data class ClientNote(
    val id: String,
    val clientId: String,
    val trainerId: String,
    val title: String,
    val content: String,
    val category: NoteCategory = NoteCategory.TRAINING,
    val noteType: NoteType = NoteType.DETAILED,
    val isPinned: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
