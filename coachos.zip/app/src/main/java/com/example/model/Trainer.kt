package com.example.model

enum class UserRole {
    TRAINER,
    CLIENT,
    ADMIN
}

data class TrainerUser(
    val id: String,
    val email: String,
    val displayName: String,
    val role: UserRole = UserRole.TRAINER,
    val specialization: String = "Strength & Conditioning, Hypertrophy, Body Recomposition",
    val bio: String = "Dedicated personal trainer focused on sustainable performance and data-driven client progression.",
    val clientCapacity: Int = 25,
    val phone: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class CoachingMethod(
    val trainerId: String,
    val preferredSplit: String = "Upper / Lower or Push-Pull-Legs",
    val progressionPhilosophy: String = "Double progression (rep range targets before weight increments)",
    val avoidedExercises: String = "Behind-the-neck presses, upright rows with high elbow flaring",
    val warmUpPhilosophy: String = "Dynamic mobility + movement prep + 2 ramp-up sets",
    val repRanges: String = "Hypertrophy 8-12, Strength 4-6, Endurance 15+",
    val rpeTargets: String = "RPE 7-9 on main working sets, RPE 6 on deloads",
    val nutritionPhilosophy: String = "High protein (1.6-2.2g/kg), calorie deficit for fat loss, surplus for building",
    val clientCommunicationStyle: String = "Empathetic, structured, actionable, and encouraging"
)
