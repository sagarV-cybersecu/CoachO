package com.example.model

data class ClientLifestyle(
    val clientId: String,
    val trainerId: String,
    val sleepDurationHours: Double = 7.5,
    val sleepQualityRating: Int = 4, // 1 to 5
    val stressRating: Int = 3, // 1 to 5
    val activityLevel: String = "Moderately Active", // Sedentary, Lightly Active, Moderately Active, Very Active
    val dailyAverageSteps: Int = 8500,
    val workScheduleType: String = "Office / Desk 9-5",
    val recoveryRating: Int = 4, // 1 to 5
    val hydrationLiters: Double = 2.5,
    val nutritionHabitsSummary: String = "3 meals/day, adequate protein, occasional weekend snacking",
    val trainingAvailabilityDays: String = "Monday, Wednesday, Friday mornings, Saturday flexible",
    val lifestyleNotes: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)
