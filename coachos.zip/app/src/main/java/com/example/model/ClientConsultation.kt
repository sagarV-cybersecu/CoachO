package com.example.model

data class ConsultationPersonalInfo(
    val fullName: String = "",
    val dateOfBirth: String = "",
    val gender: String = "",
    val phone: String = "",
    val email: String = "",
    val occupation: String = "",
    val emergencyContactName: String = "",
    val emergencyContactPhone: String = ""
)

data class ConsultationLifestyle(
    val dailyActivity: String = "Moderately active (desk job + walking)",
    val averageSteps: Int = 8000,
    val sleepDurationHours: Double = 7.5,
    val sleepQuality: Int = 4, // 1 to 5
    val stressLevel: Int = 3, // 1 to 5
    val workSchedule: String = "Monday to Friday, 9am - 5pm",
    val lifestyleNotes: String = ""
)

data class ConsultationTrainingHistory(
    val previousExperience: String = "",
    val currentActivity: String = "",
    val previousProgrammes: String = "",
    val favouriteExercises: String = "",
    val dislikedExercises: String = "",
    val trainingLimitations: String = "",
    val equipmentAvailability: String = "Full gym access"
)

data class ConsultationGoals(
    val primaryGoal: String = "",
    val secondaryGoals: String = "",
    val targetDate: String = "",
    val motivation: String = "",
    val desiredOutcome: String = ""
)

data class ConsultationNutrition(
    val eatingPattern: String = "3 balanced meals + afternoon snack",
    val mealsPerDay: Int = 3,
    val waterIntakeLiters: Double = 2.5,
    val foodPreferences: String = "",
    val dietaryRestrictions: String = "None",
    val nutritionNotes: String = ""
)

data class ClientConsultation(
    val clientId: String,
    val trainerId: String,
    val personal: ConsultationPersonalInfo = ConsultationPersonalInfo(),
    val lifestyle: ConsultationLifestyle = ConsultationLifestyle(),
    val trainingHistory: ConsultationTrainingHistory = ConsultationTrainingHistory(),
    val goals: ConsultationGoals = ConsultationGoals(),
    val nutrition: ConsultationNutrition = ConsultationNutrition(),
    val trainerNotes: String = "",
    val isCompleted: Boolean = false,
    val lastSavedAt: Long = System.currentTimeMillis()
)
