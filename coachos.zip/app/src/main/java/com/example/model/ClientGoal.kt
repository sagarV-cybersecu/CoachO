package com.example.model

enum class GoalCategory(val label: String) {
    FAT_LOSS("Fat Loss"),
    MUSCLE_GAIN("Muscle Gain"),
    STRENGTH("Strength"),
    ENDURANCE("Endurance"),
    FITNESS("Fitness"),
    MOBILITY("Mobility"),
    GENERAL_HEALTH("General Health / Fitness"),
    CUSTOM("Custom")
}

enum class GoalStatus(val label: String) {
    IN_PROGRESS("In Progress"),
    ACHIEVED("Achieved"),
    ON_HOLD("On Hold"),
    ARCHIVED("Archived")
}

data class ClientGoal(
    val id: String,
    val clientId: String,
    val trainerId: String,
    val title: String,
    val isPrimary: Boolean = false,
    val category: GoalCategory = GoalCategory.GENERAL_HEALTH,
    val targetDate: String = "",
    val targetMetric: String = "Weight (kg)",
    val startingValue: String = "",
    val currentValue: String = "",
    val targetValue: String = "",
    val status: GoalStatus = GoalStatus.IN_PROGRESS,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
