package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.*
import com.example.data.local.entity.*

@Database(
    entities = [
        TrainerEntity::class,
        ClientEntity::class,
        ClientNoteEntity::class,
        ScheduledSessionEntity::class,
        CoachingMethodEntity::class,
        AiRecommendationEntity::class,
        AuditLogEntity::class,
        ClientConsultationEntity::class,
        HealthScreeningEntity::class,
        ClientGoalEntity::class,
        ClientLifestyleEntity::class,
        AssessmentSessionEntity::class,
        ClientMeasurementEntity::class,
        ProgressPhotoEntity::class,
        TimelineEventEntity::class,
        ExerciseEntity::class,
        ProgrammeEntity::class,
        ProgrammeVersionEntity::class,
        TrainingDayEntity::class,
        WorkoutExerciseEntity::class,
        WorkoutLogEntity::class,
        LoggedSetEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun trainerDao(): TrainerDao
    abstract fun clientDao(): ClientDao
    abstract fun clientNoteDao(): ClientNoteDao
    abstract fun sessionDao(): SessionDao
    abstract fun coachingMethodDao(): CoachingMethodDao
    abstract fun aiRecommendationDao(): AiRecommendationDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun clientConsultationDao(): ClientConsultationDao
    abstract fun healthScreeningDao(): HealthScreeningDao
    abstract fun clientGoalDao(): ClientGoalDao
    abstract fun clientLifestyleDao(): ClientLifestyleDao
    abstract fun assessmentDao(): AssessmentDao
    abstract fun measurementDao(): MeasurementDao
    abstract fun progressPhotoDao(): ProgressPhotoDao
    abstract fun timelineEventDao(): TimelineEventDao
    abstract fun exerciseDao(): ExerciseDao
    abstract fun programmeDao(): ProgrammeDao
    abstract fun programmeVersionDao(): ProgrammeVersionDao
    abstract fun trainingDayDao(): TrainingDayDao
    abstract fun workoutExerciseDao(): WorkoutExerciseDao
    abstract fun workoutLogDao(): WorkoutLogDao
    abstract fun loggedSetDao(): LoggedSetDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "coach_os_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
