package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ClientConsultationDao {
    @Query("SELECT * FROM client_consultations WHERE trainerId = :trainerId AND clientId = :clientId LIMIT 1")
    fun getConsultation(trainerId: String, clientId: String): Flow<ClientConsultationEntity?>

    @Query("SELECT * FROM client_consultations WHERE trainerId = :trainerId AND clientId = :clientId LIMIT 1")
    suspend fun getConsultationOnce(trainerId: String, clientId: String): ClientConsultationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateConsultation(consultation: ClientConsultationEntity)
}

@Dao
interface HealthScreeningDao {
    @Query("SELECT * FROM health_screenings WHERE trainerId = :trainerId AND clientId = :clientId LIMIT 1")
    fun getHealthScreening(trainerId: String, clientId: String): Flow<HealthScreeningEntity?>

    @Query("SELECT * FROM health_screenings WHERE trainerId = :trainerId AND clientId = :clientId LIMIT 1")
    suspend fun getHealthScreeningOnce(trainerId: String, clientId: String): HealthScreeningEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateHealthScreening(screening: HealthScreeningEntity)
}

@Dao
interface ClientGoalDao {
    @Query("SELECT * FROM client_goals WHERE trainerId = :trainerId AND clientId = :clientId ORDER BY isPrimary DESC, createdAt DESC")
    fun getGoalsForClient(trainerId: String, clientId: String): Flow<List<ClientGoalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: ClientGoalEntity)

    @Update
    suspend fun updateGoal(goal: ClientGoalEntity)

    @Query("DELETE FROM client_goals WHERE trainerId = :trainerId AND id = :goalId")
    suspend fun deleteGoal(trainerId: String, goalId: String)
}

@Dao
interface ClientLifestyleDao {
    @Query("SELECT * FROM client_lifestyles WHERE trainerId = :trainerId AND clientId = :clientId LIMIT 1")
    fun getLifestyle(trainerId: String, clientId: String): Flow<ClientLifestyleEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateLifestyle(lifestyle: ClientLifestyleEntity)
}

@Dao
interface AssessmentDao {
    @Query("SELECT * FROM assessment_sessions WHERE trainerId = :trainerId AND clientId = :clientId ORDER BY isBaseline DESC, date DESC, createdAt DESC")
    fun getAssessmentsForClient(trainerId: String, clientId: String): Flow<List<AssessmentSessionEntity>>

    @Query("SELECT * FROM assessment_sessions WHERE trainerId = :trainerId AND clientId = :clientId AND isBaseline = 1 LIMIT 1")
    fun getBaselineAssessment(trainerId: String, clientId: String): Flow<AssessmentSessionEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAssessment(assessment: AssessmentSessionEntity)

    @Update
    suspend fun updateAssessment(assessment: AssessmentSessionEntity)

    @Query("UPDATE assessment_sessions SET isBaseline = 0 WHERE trainerId = :trainerId AND clientId = :clientId AND id != :exceptId")
    suspend fun clearOtherBaselines(trainerId: String, clientId: String, exceptId: String)

    @Query("UPDATE assessment_sessions SET isBaseline = 1 WHERE trainerId = :trainerId AND id = :assessmentId")
    suspend fun markAsBaseline(trainerId: String, assessmentId: String)

    @Query("DELETE FROM assessment_sessions WHERE trainerId = :trainerId AND id = :assessmentId")
    suspend fun deleteAssessment(trainerId: String, assessmentId: String)
}

@Dao
interface MeasurementDao {
    @Query("SELECT * FROM client_measurements WHERE trainerId = :trainerId AND clientId = :clientId ORDER BY date DESC, createdAt DESC")
    fun getMeasurementsForClient(trainerId: String, clientId: String): Flow<List<ClientMeasurementEntity>>

    @Query("SELECT * FROM client_measurements WHERE trainerId = :trainerId AND clientId = :clientId AND type = :type ORDER BY date DESC, createdAt DESC LIMIT 1")
    fun getLatestMeasurement(trainerId: String, clientId: String, type: String): Flow<ClientMeasurementEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMeasurement(measurement: ClientMeasurementEntity)

    @Query("DELETE FROM client_measurements WHERE trainerId = :trainerId AND id = :measurementId")
    suspend fun deleteMeasurement(trainerId: String, measurementId: String)
}

@Dao
interface ProgressPhotoDao {
    @Query("SELECT * FROM progress_photos WHERE trainerId = :trainerId AND clientId = :clientId ORDER BY date DESC, createdAt DESC")
    fun getPhotosForClient(trainerId: String, clientId: String): Flow<List<ProgressPhotoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhoto(photo: ProgressPhotoEntity)

    @Query("DELETE FROM progress_photos WHERE trainerId = :trainerId AND id = :photoId")
    suspend fun deletePhoto(trainerId: String, photoId: String)
}

@Dao
interface TimelineEventDao {
    @Query("SELECT * FROM timeline_events WHERE trainerId = :trainerId AND clientId = :clientId ORDER BY timestamp DESC")
    fun getTimelineEvents(trainerId: String, clientId: String): Flow<List<TimelineEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTimelineEvent(event: TimelineEventEntity)

    @Query("DELETE FROM timeline_events WHERE trainerId = :trainerId AND id = :eventId")
    suspend fun deleteTimelineEvent(trainerId: String, eventId: String)
}
