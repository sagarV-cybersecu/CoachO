package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TrainerDao {
    @Query("SELECT * FROM trainers WHERE id = :id LIMIT 1")
    suspend fun getTrainerById(id: String): TrainerEntity?

    @Query("SELECT * FROM trainers WHERE email = :email LIMIT 1")
    suspend fun getTrainerByEmail(email: String): TrainerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrainer(trainer: TrainerEntity)

    @Update
    suspend fun updateTrainer(trainer: TrainerEntity)
}

@Dao
interface ClientDao {
    @Query("SELECT * FROM clients WHERE trainerId = :trainerId ORDER BY updatedAt DESC")
    fun getClientsByTrainer(trainerId: String): Flow<List<ClientEntity>>

    @Query("SELECT * FROM clients WHERE trainerId = :trainerId AND id = :clientId LIMIT 1")
    fun getClientById(trainerId: String, clientId: String): Flow<ClientEntity?>

    @Query("SELECT * FROM clients WHERE trainerId = :trainerId AND id = :clientId LIMIT 1")
    suspend fun getClientByIdOnce(trainerId: String, clientId: String): ClientEntity?

    @Query("SELECT * FROM clients WHERE trainerId = :trainerId AND needsAttention = 1")
    fun getClientsNeedingAttention(trainerId: String): Flow<List<ClientEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClient(client: ClientEntity)

    @Update
    suspend fun updateClient(client: ClientEntity)

    @Query("DELETE FROM clients WHERE trainerId = :trainerId AND id = :clientId")
    suspend fun deleteClient(trainerId: String, clientId: String)

    @Query("SELECT COUNT(*) FROM clients WHERE trainerId = :trainerId")
    fun getClientCount(trainerId: String): Flow<Int>
}

@Dao
interface ClientNoteDao {
    @Query("SELECT * FROM client_notes WHERE trainerId = :trainerId AND clientId = :clientId ORDER BY isPinned DESC, createdAt DESC")
    fun getNotesForClient(trainerId: String, clientId: String): Flow<List<ClientNoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: ClientNoteEntity)

    @Query("DELETE FROM client_notes WHERE id = :noteId AND trainerId = :trainerId")
    suspend fun deleteNote(noteId: String, trainerId: String)
}

@Dao
interface SessionDao {
    @Query("SELECT * FROM scheduled_sessions WHERE trainerId = :trainerId ORDER BY timestamp ASC")
    fun getSessionsForTrainer(trainerId: String): Flow<List<ScheduledSessionEntity>>

    @Query("SELECT * FROM scheduled_sessions WHERE trainerId = :trainerId AND sessionDateText = :dateText ORDER BY timestamp ASC")
    fun getSessionsForDate(trainerId: String, dateText: String): Flow<List<ScheduledSessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: ScheduledSessionEntity)

    @Update
    suspend fun updateSession(session: ScheduledSessionEntity)

    @Query("DELETE FROM scheduled_sessions WHERE id = :sessionId AND trainerId = :trainerId")
    suspend fun deleteSession(sessionId: String, trainerId: String)
}

@Dao
interface CoachingMethodDao {
    @Query("SELECT * FROM coaching_methods WHERE trainerId = :trainerId LIMIT 1")
    fun getCoachingMethod(trainerId: String): Flow<CoachingMethodEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveCoachingMethod(method: CoachingMethodEntity)
}

@Dao
interface AiRecommendationDao {
    @Query("SELECT * FROM ai_recommendations ORDER BY timestamp DESC")
    fun getAllRecommendations(): Flow<List<AiRecommendationEntity>>

    @Query("SELECT * FROM ai_recommendations WHERE clientId = :clientId ORDER BY timestamp DESC")
    fun getRecommendationsForClient(clientId: String): Flow<List<AiRecommendationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecommendation(rec: AiRecommendationEntity)

    @Query("UPDATE ai_recommendations SET status = :newStatus WHERE id = :id")
    suspend fun updateRecommendationStatus(id: String, newStatus: String)
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_logs WHERE trainerId = :trainerId ORDER BY timestamp DESC LIMIT 50")
    fun getLogsForTrainer(trainerId: String): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AuditLogEntity)
}
