package com.example.data.seed

import com.example.model.*

object ExerciseLibrarySeed {
    fun getDefaultExercises(): List<Exercise> = listOf(
        Exercise(
            id = "ex_bb_squat",
            name = "Barbell Back Squat",
            category = ExerciseCategory.STRENGTH,
            primaryMuscle = MuscleGroup.QUADS,
            secondaryMuscles = listOf(MuscleGroup.GLUTES, MuscleGroup.HAMSTRINGS, MuscleGroup.CORE),
            movementPattern = MovementPattern.SQUAT,
            equipment = EquipmentType.BARBELL,
            difficulty = ExerciseDifficulty.INTERMEDIATE,
            instructions = listOf(
                "Position barbell across upper traps (high bar) or rear delts (low bar) in rack.",
                "Unrack with a firm braced core and take two controlled steps backward into shoulder-width stance.",
                "Inhale deeply into abdomen, set ribcage down, and initiate descent by simultaneously breaking at hips and knees.",
                "Descend until hip crease is slightly below top of knees while maintaining neutral spine.",
                "Drive through whole foot, extending knees and hips simultaneously back to lockout."
            ),
            coachingCues = listOf(
                "Brace 360 degrees into your belt/abs before descending",
                "Keep chest tall without arching lower back",
                "Knees track over second and third toes",
                "Drive the floor away out of the hole"
            ),
            commonMistakes = listOf(
                "Collapsing chest forward during ascent (good-morning squat)",
                "Knees caving inward (valgus collapse)",
                "Heels lifting off the ground due to limited ankle dorsiflexion",
                "Hyperextending lumbar spine at top lockout"
            ),
            trainerNotes = "Gold standard compound lower-body builder. Screen ankle dorsiflexion and hip mobility first.",
            alternativeExerciseIds = listOf("ex_db_goblet_squat", "ex_leg_press", "ex_smith_squat"),
            videoReference = "https://coachos.ai/exercises/barbell-back-squat"
        ),
        Exercise(
            id = "ex_db_goblet_squat",
            name = "Dumbbell Goblet Squat",
            category = ExerciseCategory.HYPERTROPHY,
            primaryMuscle = MuscleGroup.QUADS,
            secondaryMuscles = listOf(MuscleGroup.GLUTES, MuscleGroup.CORE),
            movementPattern = MovementPattern.SQUAT,
            equipment = EquipmentType.DUMBBELL,
            difficulty = ExerciseDifficulty.BEGINNER,
            instructions = listOf(
                "Hold dumbbell vertically against upper chest with both hands cradling top weight plate.",
                "Set feet shoulder-width apart with slight toe flare (15-30 degrees).",
                "Brace core and sit down between your hips, keeping elbows pointing down inside knees.",
                "Pause briefly at parallel or slightly below, then drive up through midfoot."
            ),
            coachingCues = listOf(
                "Elbows track inside knees at bottom",
                "Keep dumbbell glued to sternum",
                "Stay tall through crown of head"
            ),
            commonMistakes = listOf(
                "Letting dumbbell drift away from torso",
                "Rounding thoracic spine under fatigue"
            ),
            trainerNotes = "Exceptional regression or warm-up drill for teaching upright squat mechanics.",
            alternativeExerciseIds = listOf("ex_bb_squat", "ex_kb_goblet_squat"),
            videoReference = "https://coachos.ai/exercises/goblet-squat"
        ),
        Exercise(
            id = "ex_bb_bench_press",
            name = "Barbell Flat Bench Press",
            category = ExerciseCategory.STRENGTH,
            primaryMuscle = MuscleGroup.CHEST,
            secondaryMuscles = listOf(MuscleGroup.SHOULDERS, MuscleGroup.TRICEPS),
            movementPattern = MovementPattern.PUSH_HORIZONTAL,
            equipment = EquipmentType.BARBELL,
            difficulty = ExerciseDifficulty.INTERMEDIATE,
            instructions = listOf(
                "Lie on flat bench with eyes directly under bar, feet flat and driven into floor.",
                "Grip bar slightly wider than shoulder width with thumbs wrapped securely.",
                "Retract and depress scapulae to create a stable upper back shelf.",
                "Unrack bar and stabilize over chest. Inhale and lower bar with control to lower sternum.",
                "Press bar up and slightly backward in an arc back over shoulders."
            ),
            coachingCues = listOf(
                "Screw shoulders into sockets (external rotation)",
                "Tuck elbows at ~45-70 degree angle, not flared 90 degrees",
                "Maintain leg drive through whole press"
            ),
            commonMistakes = listOf(
                "Bouncing bar violently off sternum",
                "Lifting hips/glutes off bench",
                "Wrists bending backward excessively"
            ),
            trainerNotes = "Primary horizontal push strength indicator. Ensure safety pins/collars are set.",
            alternativeExerciseIds = listOf("ex_db_flat_bench", "ex_pushup", "ex_machine_chest_press"),
            videoReference = "https://coachos.ai/exercises/barbell-bench-press"
        ),
        Exercise(
            id = "ex_db_flat_bench",
            name = "Dumbbell Flat Bench Press",
            category = ExerciseCategory.HYPERTROPHY,
            primaryMuscle = MuscleGroup.CHEST,
            secondaryMuscles = listOf(MuscleGroup.SHOULDERS, MuscleGroup.TRICEPS),
            movementPattern = MovementPattern.PUSH_HORIZONTAL,
            equipment = EquipmentType.DUMBBELL,
            difficulty = ExerciseDifficulty.BEGINNER,
            instructions = listOf(
                "Sit on bench with dumbbells resting on thighs. Kick dumbbells up to shoulders and lie back.",
                "Plant feet firmly, retract shoulder blades, and rotate dumbbells to 45-degree angle.",
                "Lower dumbbells with control until thumbs touch outer chest level.",
                "Press dumbbells up in converging arc without clanking weights together."
            ),
            coachingCues = listOf(
                "Feel deep stretch across pectorals at bottom",
                "Drive elbows together at top contraction"
            ),
            commonMistakes = listOf(
                "Dropping elbows too low and over-stressing anterior shoulder capsule",
                "Losing upper back tightness"
            ),
            trainerNotes = "Allows natural joint freedom for clients with wrist or shoulder discomfort on barbells.",
            alternativeExerciseIds = listOf("ex_bb_bench_press", "ex_incline_db_bench"),
            videoReference = "https://coachos.ai/exercises/dumbbell-bench-press"
        ),
        Exercise(
            id = "ex_bb_deadlift",
            name = "Conventional Barbell Deadlift",
            category = ExerciseCategory.STRENGTH,
            primaryMuscle = MuscleGroup.HAMSTRINGS,
            secondaryMuscles = listOf(MuscleGroup.GLUTES, MuscleGroup.BACK, MuscleGroup.CORE),
            movementPattern = MovementPattern.HINGE,
            equipment = EquipmentType.BARBELL,
            difficulty = ExerciseDifficulty.ADVANCED,
            instructions = listOf(
                "Stand with midfoot directly under bar, feet hip-width apart.",
                "Hinge at hips, reach down and grip bar just outside shins without moving the bar.",
                "Pull shins forward until they touch bar, wedge hips into position, and pull slack out of bar.",
                "Lock lats tight (protect armpits) and push floor away with legs to lift bar vertically.",
                "Stand tall at lockout with glutes squeezed without hyperextending lower back."
            ),
            coachingCues = listOf(
                "Pull the slack out of the barbell before lifting",
                "Push the floor away like a leg press",
                "Bar travels in a laser-straight vertical path grazing shins"
            ),
            commonMistakes = listOf(
                "Bar drifting away from body during pull",
                "Hips shooting up first before bar leaves floor (stripper pull)",
                "Excessive lumbar flexion under heavy load"
            ),
            trainerNotes = "Ultimate posterior chain developer. Assess hip hinge and thoracic control first.",
            alternativeExerciseIds = listOf("ex_bb_rdl", "ex_trap_bar_deadlift"),
            videoReference = "https://coachos.ai/exercises/conventional-deadlift"
        ),
        Exercise(
            id = "ex_bb_rdl",
            name = "Romanian Deadlift (Barbell RDL)",
            category = ExerciseCategory.HYPERTROPHY,
            primaryMuscle = MuscleGroup.HAMSTRINGS,
            secondaryMuscles = listOf(MuscleGroup.GLUTES, MuscleGroup.BACK, MuscleGroup.CORE),
            movementPattern = MovementPattern.HINGE,
            equipment = EquipmentType.BARBELL,
            difficulty = ExerciseDifficulty.INTERMEDIATE,
            instructions = listOf(
                "Begin standing upright with bar held at mid-thighs, shoulders pulled back.",
                "Maintain soft bend in knees and initiate movement by pushing hips backward toward wall behind you.",
                "Trace bar closely down thighs and shins until end of active hamstring stretch (usually just below knees).",
                "Drive hips forward powerfully to return to starting position."
            ),
            coachingCues = listOf(
                "Imagine closing a car door with your butt",
                "Knee angle stays fixed once bent slightly",
                "Keep bar glued to your legs the entire rep"
            ),
            commonMistakes = listOf(
                "Squatting the weight instead of hinging hips back",
                "Allowing lower back to round to reach lower to the floor",
                "Looking up at ceiling, straining cervical spine"
            ),
            trainerNotes = "Best exercise for hypertrophy of biceps femoris and gluteus maximus.",
            alternativeExerciseIds = listOf("ex_db_rdl", "ex_bb_deadlift"),
            videoReference = "https://coachos.ai/exercises/barbell-rdl"
        ),
        Exercise(
            id = "ex_db_rdl",
            name = "Dumbbell Romanian Deadlift",
            category = ExerciseCategory.HYPERTROPHY,
            primaryMuscle = MuscleGroup.HAMSTRINGS,
            secondaryMuscles = listOf(MuscleGroup.GLUTES, MuscleGroup.CORE),
            movementPattern = MovementPattern.HINGE,
            equipment = EquipmentType.DUMBBELL,
            difficulty = ExerciseDifficulty.BEGINNER,
            instructions = listOf(
                "Hold dumbbells in front of thighs with palms facing body.",
                "Hinge at hips, pushing glutes backward while keeping dumbbells tight against legs.",
                "Descend until hamstrings are fully loaded, then fire glutes to return upright."
            ),
            coachingCues = listOf(
                "Keep shins vertical",
                "Weight on midfoot to heel",
                "Squeeze glutes at top"
            ),
            commonMistakes = listOf(
                "Dumbbells swinging out away from shins"
            ),
            trainerNotes = "Great for beginners learning the hip hinge movement pattern.",
            alternativeExerciseIds = listOf("ex_bb_rdl", "ex_kb_swing"),
            videoReference = "https://coachos.ai/exercises/dumbbell-rdl"
        ),
        Exercise(
            id = "ex_bb_overhead_press",
            name = "Overhead Barbell Military Press",
            category = ExerciseCategory.STRENGTH,
            primaryMuscle = MuscleGroup.SHOULDERS,
            secondaryMuscles = listOf(MuscleGroup.TRICEPS, MuscleGroup.CORE, MuscleGroup.CHEST),
            movementPattern = MovementPattern.PUSH_VERTICAL,
            equipment = EquipmentType.BARBELL,
            difficulty = ExerciseDifficulty.ADVANCED,
            instructions = listOf(
                "Stand with feet shoulder-width apart, holding barbell on front delts in front-rack grip.",
                "Brace abs and squeeze glutes tight to create a rigid pillar.",
                "Tilt chin back slightly and press bar straight up past nose.",
                "Once bar clears head, bring head forward through the window and lock bar over ears."
            ),
            coachingCues = listOf(
                "Squeeze glutes like you're holding a coin between cheeks",
                "Vertical bar path; move your face around the bar, not bar around face",
                "Shrug shoulders slightly at full overhead lockout"
            ),
            commonMistakes = listOf(
                "Over-arching lower back to turn it into an incline press",
                "Pressing bar forward in an arc",
                "Soft knees or lack of core bracing"
            ),
            trainerNotes = "Pure indicator of overhead vertical pressing capacity.",
            alternativeExerciseIds = listOf("ex_db_seated_ohp", "ex_cable_lateral_raise"),
            videoReference = "https://coachos.ai/exercises/overhead-press"
        ),
        Exercise(
            id = "ex_db_seated_ohp",
            name = "Seated Dumbbell Shoulder Press",
            category = ExerciseCategory.HYPERTROPHY,
            primaryMuscle = MuscleGroup.SHOULDERS,
            secondaryMuscles = listOf(MuscleGroup.TRICEPS),
            movementPattern = MovementPattern.PUSH_VERTICAL,
            equipment = EquipmentType.DUMBBELL,
            difficulty = ExerciseDifficulty.BEGINNER,
            instructions = listOf(
                "Sit on upright bench (80-85 degree incline) with dumbbells at shoulder height.",
                "Press dumbbells vertically until arms are extended overhead.",
                "Lower under control back to ear level."
            ),
            coachingCues = listOf(
                "Keep elbows slightly in front of shoulders (scapular plane)",
                "Full range of motion down to clavicles"
            ),
            commonMistakes = listOf(
                "Banging dumbbells at top",
                "Flaring elbows straight out sideways"
            ),
            trainerNotes = "Great hypertrophy exercise minimizing core and balance fatigue.",
            alternativeExerciseIds = listOf("ex_bb_overhead_press"),
            videoReference = "https://coachos.ai/exercises/seated-dumbbell-press"
        ),
        Exercise(
            id = "ex_pull_ups",
            name = "Bodyweight Pull-Up",
            category = ExerciseCategory.STRENGTH,
            primaryMuscle = MuscleGroup.LATS,
            secondaryMuscles = listOf(MuscleGroup.BICEPS, MuscleGroup.BACK, MuscleGroup.CORE),
            movementPattern = MovementPattern.PULL_VERTICAL,
            equipment = EquipmentType.BODYWEIGHT,
            difficulty = ExerciseDifficulty.ADVANCED,
            instructions = listOf(
                "Grip pull-up bar with overhand grip slightly wider than shoulders.",
                "Hang in dead hang with active shoulders (depressed scapulae).",
                "Pull chest up toward bar by driving elbows down into back pockets.",
                "Touch upper chest to bar, pause, and lower under 2-3 second control to full extension."
            ),
            coachingCues = listOf(
                "Drive elbows down toward your hips",
                "Keep legs together and core braced to avoid swinging",
                "Proud chest at top"
            ),
            commonMistakes = listOf(
                "Kicking or kipping with legs",
                "Partial reps cutting off bottom extension or top chin clearance",
                "Shrugging shoulders into ears"
            ),
            trainerNotes = "King of vertical pulling. Regress to assisted pull-up or lat pulldown as needed.",
            alternativeExerciseIds = listOf("ex_lat_pulldown", "ex_bb_bent_row"),
            videoReference = "https://coachos.ai/exercises/pull-ups"
        ),
        Exercise(
            id = "ex_lat_pulldown",
            name = "Cable Lat Pulldown",
            category = ExerciseCategory.HYPERTROPHY,
            primaryMuscle = MuscleGroup.LATS,
            secondaryMuscles = listOf(MuscleGroup.BICEPS, MuscleGroup.BACK),
            movementPattern = MovementPattern.PULL_VERTICAL,
            equipment = EquipmentType.CABLE,
            difficulty = ExerciseDifficulty.BEGINNER,
            instructions = listOf(
                "Sit at machine with thighs snug under roller pads.",
                "Grip bar with wide pronated grip and lean torso back 10-15 degrees.",
                "Pull bar smoothly down to upper collarbone by driving elbows downward.",
                "Control the cable return back up to full stretch."
            ),
            coachingCues = listOf(
                "Lead with elbows, not hands",
                "Squeeze shoulder blades down and together at contraction"
            ),
            commonMistakes = listOf(
                "Swinging torso excessively to generate momentum",
                "Pulling bar behind the neck"
            ),
            trainerNotes = "Ideal for controlled volume accumulation and strict hypertrophy.",
            alternativeExerciseIds = listOf("ex_pull_ups", "ex_seated_cable_row"),
            videoReference = "https://coachos.ai/exercises/lat-pulldown"
        ),
        Exercise(
            id = "ex_bb_bent_row",
            name = "Barbell Bent-Over Row",
            category = ExerciseCategory.STRENGTH,
            primaryMuscle = MuscleGroup.BACK,
            secondaryMuscles = listOf(MuscleGroup.LATS, MuscleGroup.BICEPS, MuscleGroup.CORE),
            movementPattern = MovementPattern.PULL_HORIZONTAL,
            equipment = EquipmentType.BARBELL,
            difficulty = ExerciseDifficulty.INTERMEDIATE,
            instructions = listOf(
                "Hinge forward until torso is roughly 45 degrees to floor, holding bar with shoulder-width grip.",
                "Brace core and let arms hang perpendicular to floor.",
                "Pull bar up towards lower ribs / belly button, retracting shoulder blades at top.",
                "Lower with control until arms are fully extended without rounding upper back."
            ),
            coachingCues = listOf(
                "Think about pulling with your elbows",
                "Keep torso angle locked stationary",
                "Squeeze shoulder blades together at apex"
            ),
            commonMistakes = listOf(
                "Using hip momentum and standing up on every rep",
                "Rounding lumbar spine under fatigue"
            ),
            trainerNotes = "Excellent thick back builder and postural strengthener.",
            alternativeExerciseIds = listOf("ex_seated_cable_row", "ex_db_single_arm_row"),
            videoReference = "https://coachos.ai/exercises/bent-over-row"
        ),
        Exercise(
            id = "ex_seated_cable_row",
            name = "Seated Cable Row",
            category = ExerciseCategory.HYPERTROPHY,
            primaryMuscle = MuscleGroup.BACK,
            secondaryMuscles = listOf(MuscleGroup.LATS, MuscleGroup.BICEPS),
            movementPattern = MovementPattern.PULL_HORIZONTAL,
            equipment = EquipmentType.CABLE,
            difficulty = ExerciseDifficulty.BEGINNER,
            instructions = listOf(
                "Sit with feet on footplates, knees slightly bent, and grab V-bar or neutral handles.",
                "Sit tall with chest proud and shoulders pulled down.",
                "Pull handle to abdomen, driving elbows back and squeezing rhomboids.",
                "Extend arms forward allowing a full controlled stretch through lats."
            ),
            coachingCues = listOf(
                "Do not shrug your shoulders up",
                "Chest stays proud throughout"
            ),
            commonMistakes = listOf(
                "Rocking back and forth from hips",
                "Over-rounding lower back at reach"
            ),
            trainerNotes = "Great horizontal row alternative with constant cable tension.",
            alternativeExerciseIds = listOf("ex_bb_bent_row", "ex_chest_supported_row"),
            videoReference = "https://coachos.ai/exercises/seated-cable-row"
        ),
        Exercise(
            id = "ex_bulgarian_split_squat",
            name = "Bulgarian Split Squat",
            category = ExerciseCategory.HYPERTROPHY,
            primaryMuscle = MuscleGroup.QUADS,
            secondaryMuscles = listOf(MuscleGroup.GLUTES, MuscleGroup.HAMSTRINGS, MuscleGroup.CORE),
            movementPattern = MovementPattern.LUNGE,
            equipment = EquipmentType.DUMBBELL,
            difficulty = ExerciseDifficulty.INTERMEDIATE,
            instructions = listOf(
                "Place rear foot shoelaces-down on bench behind you. Take a comfortable stride forward with front foot.",
                "Hold dumbbells by your sides, brace core, and descend straight down until front thigh is parallel to floor.",
                "Drive through whole front foot to return upright."
            ),
            coachingCues = listOf(
                "Slight forward torso lean shifts focus into glute/quad",
                "Drop back knee straight down toward floor",
                "70-80% of weight supported by front leg"
            ),
            commonMistakes = listOf(
                "Pushing off rear foot excessively",
                "Front heel lifting off floor"
            ),
            trainerNotes = "Unilateral strength and hypertrophy gold standard. Fixes left-right imbalances.",
            alternativeExerciseIds = listOf("ex_walking_lunges", "ex_leg_press"),
            videoReference = "https://coachos.ai/exercises/bulgarian-split-squat"
        ),
        Exercise(
            id = "ex_db_lateral_raise",
            name = "Dumbbell Lateral Raise",
            category = ExerciseCategory.HYPERTROPHY,
            primaryMuscle = MuscleGroup.SHOULDERS,
            secondaryMuscles = emptyList(),
            movementPattern = MovementPattern.ISOLATION,
            equipment = EquipmentType.DUMBBELL,
            difficulty = ExerciseDifficulty.BEGINNER,
            instructions = listOf(
                "Stand with dumbbells at sides, slight bend in elbows.",
                "Raise arms out to sides in scapular plane (slight 15-degree forward angle) until parallel to floor.",
                "Lower under 2-second control."
            ),
            coachingCues = listOf(
                "Pour out the water pitcher at top or lead with elbows",
                "Keep traps relaxed, don't shrug"
            ),
            commonMistakes = listOf(
                "Using heavy body swing momentum",
                "Raising hands higher than elbows"
            ),
            trainerNotes = "Lateral deltoid width builder. Emphasize strict form over load.",
            alternativeExerciseIds = listOf("ex_cable_lateral_raise"),
            videoReference = "https://coachos.ai/exercises/lateral-raise"
        ),
        Exercise(
            id = "ex_cable_tricep_pushdown",
            name = "Cable Tricep Pushdown",
            category = ExerciseCategory.HYPERTROPHY,
            primaryMuscle = MuscleGroup.TRICEPS,
            secondaryMuscles = emptyList(),
            movementPattern = MovementPattern.ISOLATION,
            equipment = EquipmentType.CABLE,
            difficulty = ExerciseDifficulty.BEGINNER,
            instructions = listOf(
                "Attach straight bar or rope to high pulley.",
                "Pin elbows against ribcage and lean forward slightly.",
                "Extend elbows fully downward until arms are straight, squeezing triceps.",
                "Return slowly until forearms reach 90 degrees."
            ),
            coachingCues = listOf(
                "Elbows stay glued in space like hinges",
                "Full lockout squeeze"
            ),
            commonMistakes = listOf(
                "Flaring elbows out",
                "Using shoulder movement to push down"
            ),
            trainerNotes = "Essential arm isolation builder.",
            alternativeExerciseIds = listOf("ex_skull_crushers"),
            videoReference = "https://coachos.ai/exercises/tricep-pushdown"
        ),
        Exercise(
            id = "ex_incline_db_curl",
            name = "Incline Dumbbell Bicep Curl",
            category = ExerciseCategory.HYPERTROPHY,
            primaryMuscle = MuscleGroup.BICEPS,
            secondaryMuscles = emptyList(),
            movementPattern = MovementPattern.ISOLATION,
            equipment = EquipmentType.DUMBBELL,
            difficulty = ExerciseDifficulty.INTERMEDIATE,
            instructions = listOf(
                "Sit on incline bench (45-60 degrees) with dumbbells hanging straight down.",
                "Curl dumbbells upward while supinating wrists (palms facing up).",
                "Squeeze biceps hard at top without lifting elbows forward.",
                "Lower slowly into deep stretch at bottom."
            ),
            coachingCues = listOf(
                "Full long-head stretch at bottom",
                "Keep shoulders pinned back on bench"
            ),
            commonMistakes = listOf(
                "Swinging torso off bench",
                "Cutting off the bottom stretch"
            ),
            trainerNotes = "Maximizes stretch-mediated hypertrophy for biceps long head.",
            alternativeExerciseIds = listOf("ex_bb_curl"),
            videoReference = "https://coachos.ai/exercises/incline-bicep-curl"
        ),
        Exercise(
            id = "ex_plank",
            name = "Hardstyle Forearm Plank",
            category = ExerciseCategory.CORE,
            primaryMuscle = MuscleGroup.CORE,
            secondaryMuscles = listOf(MuscleGroup.GLUTES, MuscleGroup.SHOULDERS),
            movementPattern = MovementPattern.ROTATION,
            equipment = EquipmentType.BODYWEIGHT,
            difficulty = ExerciseDifficulty.BEGINNER,
            instructions = listOf(
                "Set forearms parallel on floor, elbows directly under shoulders.",
                "Extend legs straight back, resting on toes.",
                "Tuck pelvis under (posterior pelvic tilt), squeeze glutes, quads, and pull elbows toward toes.",
                "Hold for prescribed time with steady belly breathing."
            ),
            coachingCues = listOf(
                "Create maximum full-body tension",
                "Don't let hips sag or hike into a tent"
            ),
            commonMistakes = listOf(
                "Sagging lower back causing lumbar compression",
                "Holding breath"
            ),
            trainerNotes = "Isometric anti-extension core foundation.",
            alternativeExerciseIds = listOf("ex_deadbug", "ex_ab_wheel_rollout"),
            videoReference = "https://coachos.ai/exercises/plank"
        ),
        Exercise(
            id = "ex_hanging_leg_raise",
            name = "Hanging Knee / Leg Raise",
            category = ExerciseCategory.CORE,
            primaryMuscle = MuscleGroup.CORE,
            secondaryMuscles = listOf(MuscleGroup.LATS),
            movementPattern = MovementPattern.ROTATION,
            equipment = EquipmentType.BODYWEIGHT,
            difficulty = ExerciseDifficulty.INTERMEDIATE,
            instructions = listOf(
                "Hang from pull-up bar with active shoulders.",
                "Roll pelvis upward and raise knees or toes towards chest under strict control.",
                "Pause at top, then lower with zero swinging."
            ),
            coachingCues = listOf(
                "Curl your pelvis up toward your sternum",
                "Zero momentum"
            ),
            commonMistakes = listOf(
                "Swinging legs like a pendulum",
                "Only flexing hips without curling pelvis"
            ),
            trainerNotes = "Advanced lower abdominal and anterior chain strengthener.",
            alternativeExerciseIds = listOf("ex_plank"),
            videoReference = "https://coachos.ai/exercises/hanging-leg-raise"
        ),
        Exercise(
            id = "ex_worlds_greatest_stretch",
            name = "World's Greatest Stretch",
            category = ExerciseCategory.MOBILITY,
            primaryMuscle = MuscleGroup.FULL_BODY,
            secondaryMuscles = listOf(MuscleGroup.HAMSTRINGS, MuscleGroup.GLUTES, MuscleGroup.BACK),
            movementPattern = MovementPattern.LUNGE,
            equipment = EquipmentType.BODYWEIGHT,
            difficulty = ExerciseDifficulty.BEGINNER,
            instructions = listOf(
                "Step forward into a deep lunge with both hands on inside of front foot.",
                "Drop back knee towards floor and drop inside elbow towards front instep.",
                "Rotate torso and reach inside arm up toward ceiling, following hand with eyes.",
                "Return hand to floor, shift hips back into hamstring stretch, then switch sides."
            ),
            coachingCues = listOf(
                "Breathe through each position",
                "Open up thoracic spine as you reach"
            ),
            commonMistakes = listOf(
                "Rushing through the transitions",
                "Hyperextending neck rather than rotating upper spine"
            ),
            trainerNotes = "Best all-in-one dynamic warm-up movement for hips, ankles, and thoracic spine.",
            alternativeExerciseIds = emptyList(),
            videoReference = "https://coachos.ai/exercises/worlds-greatest-stretch"
        ),
        Exercise(
            id = "ex_90_90_hip_flow",
            name = "90/90 Hip Mobility Flow",
            category = ExerciseCategory.MOBILITY,
            primaryMuscle = MuscleGroup.GLUTES,
            secondaryMuscles = listOf(MuscleGroup.CORE),
            movementPattern = MovementPattern.ISOLATION,
            equipment = EquipmentType.BODYWEIGHT,
            difficulty = ExerciseDifficulty.BEGINNER,
            instructions = listOf(
                "Sit on floor with front leg bent at 90 degrees and back leg bent at 90 degrees.",
                "Sit tall with proud spine, gently leaning over front shin to stretch external rotators.",
                "Press front knee and ankle into floor, then rotate through center to opposite side without hands if possible."
            ),
            coachingCues = listOf(
                "Keep spine tall and long",
                "Drive hip into external and internal rotation actively"
            ),
            commonMistakes = listOf(
                "Slouching into lower back",
                "Forcing through sharp hip joint impingement"
            ),
            trainerNotes = "Restores deep internal and external rotation before heavy squats and deadlifts.",
            alternativeExerciseIds = emptyList(),
            videoReference = "https://coachos.ai/exercises/90-90-hip-mobility"
        ),
        Exercise(
            id = "ex_assault_bike_intervals",
            name = "Echo / Assault Bike HIIT Intervals",
            category = ExerciseCategory.CONDITIONING,
            primaryMuscle = MuscleGroup.FULL_BODY,
            secondaryMuscles = listOf(MuscleGroup.QUADS, MuscleGroup.CORE),
            movementPattern = MovementPattern.CARDIO,
            equipment = EquipmentType.CARDIO_MACHINE,
            difficulty = ExerciseDifficulty.ADVANCED,
            instructions = listOf(
                "Adjust seat height so slight bend remains in knee at bottom pedal stroke.",
                "Pedal and push/pull handles with maximum explosive effort for interval duration (e.g. 20s work).",
                "Cruise at light recovery pace for rest period (e.g. 40s rest)."
            ),
            coachingCues = listOf(
                "Drive with legs and pull/push with arms in harmony",
                "Breathe through nose during rest intervals"
            ),
            commonMistakes = listOf(
                "Blowing out all energy in first 5 seconds with erratic pacing",
                "Slouching over handlebars"
            ),
            trainerNotes = "Brutal low-impact anaerobic conditioning tool.",
            alternativeExerciseIds = listOf("ex_rower_sprints"),
            videoReference = "https://coachos.ai/exercises/assault-bike"
        ),
        Exercise(
            id = "ex_foam_roll_upper_back",
            name = "Foam Roll Thoracic Spine & Lats",
            category = ExerciseCategory.RECOVERY,
            primaryMuscle = MuscleGroup.BACK,
            secondaryMuscles = listOf(MuscleGroup.LATS),
            movementPattern = MovementPattern.ISOLATION,
            equipment = EquipmentType.OTHER,
            difficulty = ExerciseDifficulty.BEGINNER,
            instructions = listOf(
                "Place foam roller perpendicular under mid-back, hands supporting head.",
                "Gently roll between mid-back and upper traps, pausing on tender spots for 20-30s.",
                "Perform gentle thoracic extensions over the roller without arching lower back."
            ),
            coachingCues = listOf(
                "Relax muscles as you breathe out over the roller",
                "Support neck with hands"
            ),
            commonMistakes = listOf(
                "Rolling excessively onto lower lumbar spine",
                "Holding breath during tight trigger points"
            ),
            trainerNotes = "Great pre-workout mobilization or post-workout recovery cool-down.",
            alternativeExerciseIds = emptyList(),
            videoReference = "https://coachos.ai/exercises/foam-roll-thoracic"
        )
    )
}
