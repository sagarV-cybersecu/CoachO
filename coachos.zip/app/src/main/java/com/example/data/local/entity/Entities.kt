package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.model.*

@Entity(tableName = "trainers")
data class TrainerEntity(
    @PrimaryKey val id: String,
    val email: String,
    val passwordHash: String,
    val displayName: String,
    val role: String = UserRole.TRAINER.name,
    val specialization: String,
    val bio: String,
    val clientCapacity: Int,
    val phone: String,
    val createdAt: Long
)

@Entity(
    tableName = "clients",
    indices = [Index(value = ["trainerId"]), Index(value = ["status"])]
)
data class ClientEntity(
    @PrimaryKey val id: String,
    val trainerId: String,
    val fullName: String,
    val email: String,
    val phone: String,
    val avatarUrl: String?,
    val primaryGoal: String,
    val goalType: String,
    val currentProgram: String,
    val status: String,
    val fitnessLevel: String,
    val dateOfBirth: String,
    val gender: String,
    val occupation: String,
    val targetTimelineWeeks: Int,
    val packageTotalSessions: Int,
    val packageRemainingSessions: Int,
    val sessionsCompleted: Int,
    val attendanceRatePercent: Int,
    val lastWorkoutDate: String,
    val lastCheckInDate: String,
    val needsAttention: Boolean,
    val attentionReason: String?,
    val readinessScore: String,
    val readinessReason: String,
    val currentWeightKg: Double,
    val targetWeightKg: Double,
    val notesSummary: String,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "client_notes",
    indices = [Index(value = ["clientId"]), Index(value = ["trainerId"])]
)
data class ClientNoteEntity(
    @PrimaryKey val id: String,
    val clientId: String,
    val trainerId: String,
    val title: String,
    val content: String,
    val category: String,
    val isPinned: Boolean,
    val createdAt: Long
)

@Entity(
    tableName = "scheduled_sessions",
    indices = [Index(value = ["trainerId"]), Index(value = ["clientId"])]
)
data class ScheduledSessionEntity(
    @PrimaryKey val id: String,
    val trainerId: String,
    val clientId: String,
    val clientName: String,
    val sessionTimeText: String,
    val sessionDateText: String,
    val durationMinutes: Int,
    val status: String,
    val sessionFocus: String,
    val location: String,
    val notes: String,
    val timestamp: Long
)

@Entity(
    tableName = "coaching_methods"
)
data class CoachingMethodEntity(
    @PrimaryKey val trainerId: String,
    val preferredSplit: String,
    val progressionPhilosophy: String,
    val avoidedExercises: String,
    val warmUpPhilosophy: String,
    val repRanges: String,
    val rpeTargets: String,
    val nutritionPhilosophy: String,
    val clientCommunicationStyle: String
)

@Entity(
    tableName = "ai_recommendations",
    indices = [Index(value = ["clientId"])]
)
data class AiRecommendationEntity(
    @PrimaryKey val id: String,
    val clientId: String,
    val clientName: String,
    val priority: String,
    val recommendation: String,
    val reason: String,
    val supportingDataJson: String, // comma separated or simple json
    val confidence: String,
    val considerationsJson: String,
    val status: String,
    val timestamp: Long
)

@Entity(
    tableName = "audit_logs",
    indices = [Index(value = ["trainerId"])]
)
data class AuditLogEntity(
    @PrimaryKey val id: String,
    val trainerId: String,
    val action: String,
    val entityType: String,
    val entityId: String,
    val details: String,
    val timestamp: Long
)
