package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.entity.*
import com.example.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class CoachRepository(private val database: AppDatabase) {
    private val trainerDao = database.trainerDao()
    private val clientDao = database.clientDao()
    private val clientNoteDao = database.clientNoteDao()
    private val sessionDao = database.sessionDao()
    private val coachingMethodDao = database.coachingMethodDao()
    private val aiRecommendationDao = database.aiRecommendationDao()
    private val auditLogDao = database.auditLogDao()
    private val clientConsultationDao = database.clientConsultationDao()
    private val healthScreeningDao = database.healthScreeningDao()
    private val clientGoalDao = database.clientGoalDao()
    private val clientLifestyleDao = database.clientLifestyleDao()
    private val assessmentDao = database.assessmentDao()
    private val measurementDao = database.measurementDao()
    private val progressPhotoDao = database.progressPhotoDao()
    private val timelineEventDao = database.timelineEventDao()

    // --- Authentication & Trainer Profile ---

    suspend fun getTrainerByEmail(email: String): TrainerUser? {
        val entity = trainerDao.getTrainerByEmail(email) ?: return null
        return TrainerUser(
            id = entity.id,
            email = entity.email,
            displayName = entity.displayName,
            role = UserRole.valueOf(entity.role),
            specialization = entity.specialization,
            bio = entity.bio,
            clientCapacity = entity.clientCapacity,
            phone = entity.phone,
            createdAt = entity.createdAt
        )
    }

    suspend fun getTrainerById(id: String): TrainerUser? {
        val entity = trainerDao.getTrainerById(id) ?: return null
        return TrainerUser(
            id = entity.id,
            email = entity.email,
            displayName = entity.displayName,
            role = UserRole.valueOf(entity.role),
            specialization = entity.specialization,
            bio = entity.bio,
            clientCapacity = entity.clientCapacity,
            phone = entity.phone,
            createdAt = entity.createdAt
        )
    }

    suspend fun registerTrainer(email: String, passwordHash: String, name: String): TrainerUser {
        val trainerId = UUID.randomUUID().toString()
        val entity = TrainerEntity(
            id = trainerId,
            email = email,
            passwordHash = passwordHash,
            displayName = name,
            role = UserRole.TRAINER.name,
            specialization = "Strength & Conditioning, Body Recomposition",
            bio = "Certified Personal Trainer dedicated to measurable progress and healthy habits.",
            clientCapacity = 25,
            phone = "+1 (555) 019-2834",
            createdAt = System.currentTimeMillis()
        )
        trainerDao.insertTrainer(entity)
        
        // Seed initial coaching method
        coachingMethodDao.saveCoachingMethod(
            CoachingMethodEntity(
                trainerId = trainerId,
                preferredSplit = "Upper / Lower (4 days/week)",
                progressionPhilosophy = "Double progression (reach max reps before adding 2.5-5kg)",
                avoidedExercises = "Behind-the-neck presses, upright rows with narrow grip",
                warmUpPhilosophy = "Joint circles, foam roll, 2 specific warm-up sets",
                repRanges = "Compounds 5-8, Isolations 10-15",
                rpeTargets = "RPE 7-8 standard, RPE 9 peak week",
                nutritionPhilosophy = "Protein target 2.0g/kg, sustainable caloric deficit",
                clientCommunicationStyle = "Objective, structured, encouraging, data-led"
            )
        )

        // Seed realistic initial clients for immediate productive use
        seedInitialClientsForTrainer(trainerId)

        logAudit(trainerId, "REGISTER", "TRAINER", trainerId, "Trainer account registered: $email")
        return TrainerUser(
            id = entity.id,
            email = entity.email,
            displayName = entity.displayName,
            role = UserRole.TRAINER,
            specialization = entity.specialization,
            bio = entity.bio,
            clientCapacity = entity.clientCapacity,
            phone = entity.phone,
            createdAt = entity.createdAt
        )
    }

    suspend fun updateTrainerProfile(trainer: TrainerUser) {
        val existing = trainerDao.getTrainerById(trainer.id)
        if (existing != null) {
            val updated = existing.copy(
                displayName = trainer.displayName,
                specialization = trainer.specialization,
                bio = trainer.bio,
                clientCapacity = trainer.clientCapacity,
                phone = trainer.phone
            )
            trainerDao.updateTrainer(updated)
            logAudit(trainer.id, "UPDATE_PROFILE", "TRAINER", trainer.id, "Trainer profile updated")
        }
    }

    // --- Client Management (Tenant Isolated) ---

    fun getClients(trainerId: String): Flow<List<Client>> {
        return clientDao.getClientsByTrainer(trainerId).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    fun getClientById(trainerId: String, clientId: String): Flow<Client?> {
        return clientDao.getClientById(trainerId, clientId).map { it?.toDomain() }
    }

    suspend fun getClientByIdOnce(trainerId: String, clientId: String): Client? {
        return clientDao.getClientByIdOnce(trainerId, clientId)?.toDomain()
    }

    fun getClientsNeedingAttention(trainerId: String): Flow<List<Client>> {
        return clientDao.getClientsNeedingAttention(trainerId).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    fun getClientCount(trainerId: String): Flow<Int> {
        return clientDao.getClientCount(trainerId)
    }

    suspend fun saveClient(client: Client) {
        val isNew = clientDao.getClientByIdOnce(client.trainerId, client.id) == null
        clientDao.insertClient(client.toEntity())
        logAudit(
            client.trainerId,
            if (isNew) "CREATE_CLIENT" else "UPDATE_CLIENT",
            "CLIENT",
            client.id,
            "Client saved: ${client.fullName}"
        )
        if (isNew) {
            addTimelineEvent(
                TimelineEvent(
                    id = UUID.randomUUID().toString(),
                    clientId = client.id,
                    trainerId = client.trainerId,
                    eventType = TimelineEventType.CLIENT_JOINED,
                    title = "Client Onboarded",
                    description = "${client.fullName} enrolled into ${client.currentProgram}. Starting weight: ${client.currentWeightKg} kg",
                    date = "Today"
                )
            )
            addMeasurement(
                ClientMeasurement(
                    id = UUID.randomUUID().toString(),
                    clientId = client.id,
                    trainerId = client.trainerId,
                    type = MeasurementType.WEIGHT,
                    value = client.currentWeightKg,
                    unit = "kg",
                    date = "Today",
                    notes = "Initial onboarding intake weight"
                )
            )
        }
    }

    suspend fun deleteClient(trainerId: String, clientId: String) {
        val client = clientDao.getClientByIdOnce(trainerId, clientId)
        clientDao.deleteClient(trainerId, clientId)
        logAudit(trainerId, "DELETE_CLIENT", "CLIENT", clientId, "Deleted client: ${client?.fullName ?: clientId}")
    }

    // --- Client Notes ---

    fun getNotesForClient(trainerId: String, clientId: String): Flow<List<ClientNote>> {
        return clientNoteDao.getNotesForClient(trainerId, clientId).map { entities ->
            entities.map {
                ClientNote(
                    id = it.id,
                    clientId = it.clientId,
                    trainerId = it.trainerId,
                    title = it.title,
                    content = it.content,
                    category = runCatching { NoteCategory.valueOf(it.category) }.getOrDefault(NoteCategory.TRAINING),
                    isPinned = it.isPinned,
                    createdAt = it.createdAt
                )
            }
        }
    }

    suspend fun addNote(note: ClientNote) {
        clientNoteDao.insertNote(
            ClientNoteEntity(
                id = note.id,
                clientId = note.clientId,
                trainerId = note.trainerId,
                title = note.title,
                content = note.content,
                category = note.category.name,
                isPinned = note.isPinned,
                createdAt = note.createdAt
            )
        )
        logAudit(note.trainerId, "ADD_NOTE", "CLIENT_NOTE", note.id, "Added note for client: ${note.clientId}")
        addTimelineEvent(
            TimelineEvent(
                id = UUID.randomUUID().toString(),
                clientId = note.clientId,
                trainerId = note.trainerId,
                eventType = TimelineEventType.TRAINER_NOTE_ADDED,
                title = "Coach Note Added",
                description = "${note.category.label}: ${note.title}",
                date = "Today"
            )
        )
    }

    suspend fun deleteNote(trainerId: String, noteId: String) {
        clientNoteDao.deleteNote(noteId, trainerId)
        logAudit(trainerId, "DELETE_NOTE", "CLIENT_NOTE", noteId, "Deleted note")
    }

    // --- Scheduled Sessions ---

    fun getSessionsForTrainer(trainerId: String): Flow<List<ScheduledSession>> {
        return sessionDao.getSessionsForTrainer(trainerId).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    fun getTodaySessions(trainerId: String): Flow<List<ScheduledSession>> {
        return sessionDao.getSessionsForDate(trainerId, "Today").map { entities ->
            entities.map { it.toDomain() }
        }
    }

    suspend fun saveSession(session: ScheduledSession) {
        sessionDao.insertSession(session.toEntity())
        logAudit(session.trainerId, "SAVE_SESSION", "SESSION", session.id, "Session scheduled for ${session.clientName}")
    }

    suspend fun updateSessionStatus(session: ScheduledSession, newStatus: SessionStatus) {
        val updated = session.copy(status = newStatus)
        sessionDao.updateSession(updated.toEntity())
        logAudit(session.trainerId, "UPDATE_SESSION_STATUS", "SESSION", session.id, "Session status changed to ${newStatus.name}")
    }

    // --- Coaching Method ---

    fun getCoachingMethod(trainerId: String): Flow<CoachingMethod?> {
        return coachingMethodDao.getCoachingMethod(trainerId).map { entity ->
            entity?.let {
                CoachingMethod(
                    trainerId = it.trainerId,
                    preferredSplit = it.preferredSplit,
                    progressionPhilosophy = it.progressionPhilosophy,
                    avoidedExercises = it.avoidedExercises,
                    warmUpPhilosophy = it.warmUpPhilosophy,
                    repRanges = it.repRanges,
                    rpeTargets = it.rpeTargets,
                    nutritionPhilosophy = it.nutritionPhilosophy,
                    clientCommunicationStyle = it.clientCommunicationStyle
                )
            }
        }
    }

    suspend fun saveCoachingMethod(method: CoachingMethod) {
        coachingMethodDao.saveCoachingMethod(
            CoachingMethodEntity(
                trainerId = method.trainerId,
                preferredSplit = method.preferredSplit,
                progressionPhilosophy = method.progressionPhilosophy,
                avoidedExercises = method.avoidedExercises,
                warmUpPhilosophy = method.warmUpPhilosophy,
                repRanges = method.repRanges,
                rpeTargets = method.rpeTargets,
                nutritionPhilosophy = method.nutritionPhilosophy,
                clientCommunicationStyle = method.clientCommunicationStyle
            )
        )
        logAudit(method.trainerId, "UPDATE_COACHING_METHOD", "COACHING_METHOD", method.trainerId, "Coaching philosophy updated")
    }

    // --- AI Recommendations ---

    fun getAiRecommendations(): Flow<List<AiRecommendation>> {
        return aiRecommendationDao.getAllRecommendations().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    suspend fun updateAiRecommendationStatus(id: String, newStatus: ActionStatus) {
        aiRecommendationDao.updateRecommendationStatus(id, newStatus.name)
    }

    suspend fun insertAiRecommendation(rec: AiRecommendation) {
        aiRecommendationDao.insertRecommendation(rec.toEntity())
    }

    // --- Audit Logs ---

    fun getAuditLogs(trainerId: String): Flow<List<AuditLog>> {
        return auditLogDao.getLogsForTrainer(trainerId).map { entities ->
            entities.map {
                AuditLog(
                    id = it.id,
                    trainerId = it.trainerId,
                    action = it.action,
                    entityType = it.entityType,
                    entityId = it.entityId,
                    details = it.details,
                    timestamp = it.timestamp
                )
            }
        }
    }

    private suspend fun logAudit(trainerId: String, action: String, entityType: String, entityId: String, details: String) {
        auditLogDao.insertLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                trainerId = trainerId,
                action = action,
                entityType = entityType,
                entityId = entityId,
                details = details,
                timestamp = System.currentTimeMillis()
            )
        )
    }

    // --- Data Seeding for Initial Trainer Experience ---

    suspend fun seedInitialClientsForTrainer(trainerId: String) {
        val client1 = Client(
            id = UUID.randomUUID().toString(),
            trainerId = trainerId,
            fullName = "Sarah Jenkins",
            email = "sarah.j@example.com",
            phone = "+1 (555) 234-5678",
            primaryGoal = "Fat Loss & Lower Body Strength",
            goalType = PrimaryGoalType.FAT_LOSS,
            currentProgram = "Lower Body Hypertrophy 4-Day",
            status = ClientStatus.NEEDS_ATTENTION,
            fitnessLevel = FitnessLevel.INTERMEDIATE,
            occupation = "Product Manager",
            targetTimelineWeeks = 12,
            packageTotalSessions = 20,
            packageRemainingSessions = 4,
            sessionsCompleted = 16,
            attendanceRatePercent = 88,
            lastWorkoutDate = "2 days ago",
            lastCheckInDate = "5 days ago",
            needsAttention = true,
            attentionReason = "Package nearly expired (4 sessions remaining) & weight plateau detected over 3 weeks.",
            readinessScore = "MODERATE",
            readinessReason = "Reported high work stress and 6 hrs sleep.",
            currentWeightKg = 68.2,
            targetWeightKg = 64.0,
            notesSummary = "Good work ethic. Tends to overwork when stressed. Needs recovery emphasis."
        )

        val client2 = Client(
            id = UUID.randomUUID().toString(),
            trainerId = trainerId,
            fullName = "Ahmed Al-Mansoor",
            email = "ahmed.m@example.com",
            phone = "+1 (555) 345-6789",
            primaryGoal = "Upper Body Hypertrophy & Posture",
            goalType = PrimaryGoalType.MUSCLE_GAIN,
            currentProgram = "Push-Pull Strength Split",
            status = ClientStatus.NEEDS_ATTENTION,
            fitnessLevel = FitnessLevel.INTERMEDIATE,
            occupation = "Software Engineer",
            targetTimelineWeeks = 16,
            packageTotalSessions = 24,
            packageRemainingSessions = 15,
            sessionsCompleted = 9,
            attendanceRatePercent = 75,
            lastWorkoutDate = "6 days ago",
            lastCheckInDate = "8 days ago",
            needsAttention = true,
            attentionReason = "Missed 2 consecutive sessions. Weekly check-in overdue.",
            readinessScore = "RECOVERY FOCUS",
            readinessReason = "Reported lower back stiffness after desk travel.",
            currentWeightKg = 81.0,
            targetWeightKg = 85.0,
            notesSummary = "Address thoracic mobility and bench bar path. Follow up on attendance."
        )

        val client3 = Client(
            id = UUID.randomUUID().toString(),
            trainerId = trainerId,
            fullName = "John Mitchell",
            email = "john.m@example.com",
            phone = "+1 (555) 456-7890",
            primaryGoal = "General Strength & Cardiovascular Conditioning",
            goalType = PrimaryGoalType.STRENGTH,
            currentProgram = "Foundational Full Body 3x",
            status = ClientStatus.ACTIVE,
            fitnessLevel = FitnessLevel.BEGINNER,
            occupation = "Architect",
            targetTimelineWeeks = 8,
            packageTotalSessions = 12,
            packageRemainingSessions = 7,
            sessionsCompleted = 5,
            attendanceRatePercent = 100,
            lastWorkoutDate = "Yesterday",
            lastCheckInDate = "Yesterday",
            needsAttention = false,
            attentionReason = null,
            readinessScore = "READY",
            readinessReason = "Slept 8 hours, eager to train, zero soreness.",
            currentWeightKg = 92.4,
            targetWeightKg = 85.0,
            notesSummary = "Squat form improving rapidly. Ready for progressive overload on deadlifts."
        )

        val client4 = Client(
            id = UUID.randomUUID().toString(),
            trainerId = trainerId,
            fullName = "David Chen",
            email = "david.c@example.com",
            phone = "+1 (555) 567-8901",
            primaryGoal = "Athletic Performance & Speed",
            goalType = PrimaryGoalType.ATHLETIC_PERFORMANCE,
            currentProgram = "Athletic Power & Plyometrics",
            status = ClientStatus.ACTIVE,
            fitnessLevel = FitnessLevel.ADVANCED,
            occupation = "Consultant",
            targetTimelineWeeks = 12,
            packageTotalSessions = 20,
            packageRemainingSessions = 12,
            sessionsCompleted = 8,
            attendanceRatePercent = 95,
            lastWorkoutDate = "3 days ago",
            lastCheckInDate = "2 days ago",
            needsAttention = false,
            attentionReason = null,
            readinessScore = "READY",
            readinessReason = "Excellent recovery, high motivation.",
            currentWeightKg = 74.0,
            targetWeightKg = 74.0,
            notesSummary = "Prep for half-marathon sprint endurance."
        )

        clientDao.insertClient(client1.toEntity())
        clientDao.insertClient(client2.toEntity())
        clientDao.insertClient(client3.toEntity())
        clientDao.insertClient(client4.toEntity())

        // Seed notes for Sarah
        clientNoteDao.insertNote(
            ClientNoteEntity(
                id = UUID.randomUUID().toString(),
                clientId = client1.id,
                trainerId = trainerId,
                title = "Weight Plateau Analysis",
                content = "Weight has hovered at 68.2kg for 3 weeks, but waist measurement is down 1.5cm. Water retention likely due to high work stress.",
                category = NoteCategory.COACHING.name,
                isPinned = true,
                createdAt = System.currentTimeMillis() - 86400000L * 2
            )
        )

        // Seed scheduled sessions for today
        sessionDao.insertSession(
            ScheduledSessionEntity(
                id = UUID.randomUUID().toString(),
                trainerId = trainerId,
                clientId = client3.id,
                clientName = client3.fullName,
                sessionTimeText = "09:00 AM",
                sessionDateText = "Today",
                durationMinutes = 60,
                status = SessionStatus.SCHEDULED.name,
                sessionFocus = "Full Body Compound Strength (Deadlift Focus)",
                location = "Weight Room Platform 2",
                notes = "Check hip hinge mechanics and bar contact.",
                timestamp = System.currentTimeMillis() + 3600000L
            )
        )

        sessionDao.insertSession(
            ScheduledSessionEntity(
                id = UUID.randomUUID().toString(),
                trainerId = trainerId,
                clientId = client1.id,
                clientName = client1.fullName,
                sessionTimeText = "11:30 AM",
                sessionDateText = "Today",
                durationMinutes = 60,
                status = SessionStatus.SCHEDULED.name,
                sessionFocus = "Glute Hypertrophy & Core Stability",
                location = "Studio A",
                notes = "Discuss package renewal and sleep hygiene.",
                timestamp = System.currentTimeMillis() + 10800000L
            )
        )

        sessionDao.insertSession(
            ScheduledSessionEntity(
                id = UUID.randomUUID().toString(),
                trainerId = trainerId,
                clientId = client2.id,
                clientName = client2.fullName,
                sessionTimeText = "05:00 PM",
                sessionDateText = "Today",
                durationMinutes = 60,
                status = SessionStatus.SCHEDULED.name,
                sessionFocus = "Posture, Thoracic Extension & Pull Split",
                location = "Main Gym",
                notes = "Re-engage after missed sessions. Keep intensity moderate.",
                timestamp = System.currentTimeMillis() + 25200000L
            )
        )

        // Seed initial AI recommendations for trainer review
        aiRecommendationDao.insertRecommendation(
            AiRecommendationEntity(
                id = UUID.randomUUID().toString(),
                clientId = client1.id,
                clientName = client1.fullName,
                priority = ActionPriority.HIGH.name,
                recommendation = "Discuss package renewal and maintain current calories while emphasizing sleep recovery.",
                reason = "4 sessions remaining in current package; body fat is dropping despite scale stall; reported high stress.",
                supportingDataJson = "Waist decreased 1.5cm, Weight stable 68.2kg, 4 sessions remaining",
                confidence = "High",
                considerationsJson = "Do not drop calories further as stress is elevated; reassuring client will prevent burnout.",
                status = ActionStatus.PENDING.name,
                timestamp = System.currentTimeMillis()
            )
        )

        aiRecommendationDao.insertRecommendation(
            AiRecommendationEntity(
                id = UUID.randomUUID().toString(),
                clientId = client2.id,
                clientName = client2.fullName,
                priority = ActionPriority.HIGH.name,
                recommendation = "Perform gentle mobility warm-up and de-load today's overhead volume to protect lower back.",
                reason = "Client missed 2 consecutive sessions and reported low back tightness from prolonged sitting.",
                supportingDataJson = "Missed 2 sessions, Check-in overdue 8 days, Reported back stiffness",
                confidence = "Medium",
                considerationsJson = "Trainer should visually inspect hip hinge before any weighted axial loading.",
                status = ActionStatus.PENDING.name,
                timestamp = System.currentTimeMillis()
            )
        )
        // --- Stage 2 Seed Data: Sarah Jenkins Consultation, Screening, Goals, Baseline & Timeline ---
        val sarahConsultation = ClientConsultation(
            clientId = client1.id,
            trainerId = trainerId,
            personal = ConsultationPersonalInfo(
                fullName = client1.fullName,
                dateOfBirth = "1994-05-12",
                gender = "Female",
                phone = client1.phone,
                email = client1.email,
                occupation = client1.occupation,
                emergencyContactName = "Mark Jenkins (Spouse)",
                emergencyContactPhone = "+1 (555) 987-6543"
            ),
            lifestyle = ConsultationLifestyle(
                dailyActivity = "Desk job with 40 min daily walking commute",
                averageSteps = 8500,
                sleepDurationHours = 6.8,
                sleepQuality = 3,
                stressLevel = 4,
                workSchedule = "Mon-Fri 8:30am - 6pm (High pressure tech startup)",
                lifestyleNotes = "Drinks 3-4 coffees daily. Stresses about work deadlines which impacts evening recovery."
            ),
            trainingHistory = ConsultationTrainingHistory(
                previousExperience = "3 years irregular gym workouts and occasional spin classes",
                currentActivity = "Strength training 3x/week with trainer, weekend walks",
                previousProgrammes = "Generic fitness apps, high-rep circuit bootcamps",
                favouriteExercises = "Romanian deadlifts, hip thrusts, dumbbell shoulder press",
                dislikedExercises = "Burpees, assault bike intervals",
                trainingLimitations = "Mild right knee patellar tenderness when squatting deep without warm-up",
                equipmentAvailability = "Full commercial gym with barbells, cables, and dumbbells"
            ),
            goals = ConsultationGoals(
                primaryGoal = "Fat Loss & Lower Body Tone (Drop 4kg safely)",
                secondaryGoals = "Build glute strength, improve sleep regularity to 7.5h",
                targetDate = "2026-11-30",
                motivation = "Prepare for summer hiking expedition and feel energetic at work",
                desiredOutcome = "Visible definition, deadlift 1.2x bodyweight without knee discomfort"
            ),
            nutrition = ConsultationNutrition(
                eatingPattern = "Skipped breakfast occasionally, lunch at desk, balanced dinner",
                mealsPerDay = 3,
                waterIntakeLiters = 2.2,
                foodPreferences = "Chicken, salmon, sweet potatoes, Greek yogurt, berries",
                dietaryRestrictions = "Mild lactose sensitivity",
                nutritionNotes = "Goal is 130g protein daily. Needs simple portable snack ideas for 3pm slumps."
            ),
            trainerNotes = "Highly motivated client. Emphasize recovery metrics and non-scale victories over strict deficit.",
            isCompleted = true,
            lastSavedAt = System.currentTimeMillis() - 86400000L * 28
        )
        clientConsultationDao.insertOrUpdateConsultation(sarahConsultation.toEntity())

        // Sarah's Health Screening (Clear with knee note)
        val sarahScreening = HealthScreening(
            clientId = client1.id,
            trainerId = trainerId,
            date = "2026-08-10",
            reviewStatus = ScreeningReviewStatus.CLEAR,
            questions = HealthScreening.defaultScreeningQuestions().map { q ->
                if (q.id == "q4_joint_injury") {
                    q.copy(
                        answerYes = true,
                        followUpAnswer = "Mild right knee discomfort with deep knee flexion; no history of tears or surgery.",
                        notes = "Include dedicated VMO warm-up, box squats, and terminal knee extensions."
                    )
                } else q
            },
            trainerNotes = "Clear for progressive resistance training. Avoid jump squats on hard floors. Monitor knee tracking.",
            disclaimerAcknowledged = true,
            updatedAt = System.currentTimeMillis() - 86400000L * 28
        )
        healthScreeningDao.insertOrUpdateHealthScreening(sarahScreening.toEntity())

        // Ahmed's Health Screening (Review Required for back pain)
        val ahmedScreening = HealthScreening(
            clientId = client2.id,
            trainerId = trainerId,
            date = "2026-08-15",
            reviewStatus = ScreeningReviewStatus.REVIEW_REQUIRED,
            questions = HealthScreening.defaultScreeningQuestions().map { q ->
                if (q.id == "q4_joint_injury") {
                    q.copy(
                        answerYes = true,
                        followUpAnswer = "Lower back L4-L5 stiffness after sitting 10+ hours a day. Periodic morning ache.",
                        notes = "No radiating sciatica or numbness reported. GP gave general exercise clearance."
                    )
                } else q
            },
            trainerNotes = "Trainer Review Required: Emphasize McGill Big 3 core stability and avoid heavy spinal compression until hip hinge is dialed.",
            disclaimerAcknowledged = true,
            updatedAt = System.currentTimeMillis() - 86400000L * 20
        )
        healthScreeningDao.insertOrUpdateHealthScreening(ahmedScreening.toEntity())

        // Sarah's Goals
        clientGoalDao.insertGoal(
            ClientGoal(
                id = UUID.randomUUID().toString(),
                clientId = client1.id,
                trainerId = trainerId,
                title = "Body Recomposition & Fat Loss",
                isPrimary = true,
                category = GoalCategory.FAT_LOSS,
                targetDate = "2026-11-30",
                targetMetric = "Weight (kg)",
                startingValue = "70.0 kg",
                currentValue = "68.2 kg",
                targetValue = "64.0 kg",
                status = GoalStatus.IN_PROGRESS,
                notes = "Down 1.8kg with noticeable waist taper."
            ).toEntity()
        )
        clientGoalDao.insertGoal(
            ClientGoal(
                id = UUID.randomUUID().toString(),
                clientId = client1.id,
                trainerId = trainerId,
                title = "Barbell Hip Thrust 100kg for 8 reps",
                isPrimary = false,
                category = GoalCategory.STRENGTH,
                targetDate = "2026-10-31",
                targetMetric = "1RM / Load (kg)",
                startingValue = "65 kg",
                currentValue = "85 kg",
                targetValue = "100 kg",
                status = GoalStatus.IN_PROGRESS,
                notes = "Currently hitting 85kg for clean sets of 8."
            ).toEntity()
        )

        // Sarah's Lifestyle Profile
        clientLifestyleDao.insertOrUpdateLifestyle(
            ClientLifestyle(
                clientId = client1.id,
                trainerId = trainerId,
                sleepDurationHours = 6.8,
                sleepQualityRating = 3,
                stressRating = 4,
                activityLevel = "Moderately Active",
                dailyAverageSteps = 8500,
                workScheduleType = "Desk / Tech Management",
                recoveryRating = 3,
                hydrationLiters = 2.2,
                nutritionHabitsSummary = "Consistently hits 125g protein; struggles with weekend restaurant sodium and late screen time.",
                trainingAvailabilityDays = "Mon 7am, Wed 7am, Fri 11:30am, Sat 10am",
                lifestyleNotes = "Coach recommended magnesium glycinate and 10 min evening mobility routine."
            ).toEntity()
        )

        // Sarah's Baseline Assessment
        val sarahAssessment = AssessmentSession(
            id = UUID.randomUUID().toString(),
            clientId = client1.id,
            trainerId = trainerId,
            title = "Initial Movement & Strength Baseline",
            date = "2026-08-11",
            isBaseline = true,
            selectedCategories = listOf(
                AssessmentCategory.MOVEMENT_OBSERVATIONS,
                AssessmentCategory.STRENGTH,
                AssessmentCategory.MOBILITY,
                AssessmentCategory.BODY_COMPOSITION
            ),
            items = listOf(
                AssessmentItem(
                    id = UUID.randomUUID().toString(),
                    category = AssessmentCategory.MOVEMENT_OBSERVATIONS,
                    testName = "Overhead Squat Screening",
                    resultValue = "Mild heel lift & forward torso lean",
                    baselineValue = "Initial Baseline",
                    notes = "Calf tightness and glute activation required prior to loading."
                ),
                AssessmentItem(
                    id = UUID.randomUUID().toString(),
                    category = AssessmentCategory.STRENGTH,
                    testName = "Standard Push-up Test",
                    resultValue = "12 reps",
                    unit = "reps",
                    baselineValue = "12 reps",
                    notes = "Good core bracing; slight elbow flare on final rep."
                ),
                AssessmentItem(
                    id = UUID.randomUUID().toString(),
                    category = AssessmentCategory.STRENGTH,
                    testName = "Trap Bar Deadlift 5RM",
                    resultValue = "75 kg",
                    unit = "kg",
                    baselineValue = "75 kg",
                    notes = "Neutral spine maintained throughout all 5 reps."
                ),
                AssessmentItem(
                    id = UUID.randomUUID().toString(),
                    category = AssessmentCategory.ENDURANCE,
                    testName = "Forearm Plank Hold",
                    resultValue = "65 sec",
                    unit = "sec",
                    baselineValue = "65 sec",
                    notes = "Hip drop noted at 55 seconds."
                ),
                AssessmentItem(
                    id = UUID.randomUUID().toString(),
                    category = AssessmentCategory.MOBILITY,
                    testName = "Ankle Weight-Bearing Lunge",
                    resultValue = "9 cm (R) / 11 cm (L)",
                    unit = "cm",
                    baselineValue = "9 cm / 11 cm",
                    notes = "Right ankle restricted; correlate with knee sensitivity."
                )
            ),
            summaryObservations = "Good structural foundation and coachability. Right ankle restriction causes mild knee compensation. Prescribe targeted ankle flossing and box squats as baseline interventions.",
            trainerRecommendations = "Prioritize posterior chain loading and 5-min pre-workout ankle mob."
        )
        assessmentDao.insertAssessment(sarahAssessment.toEntity())

        // Sarah's Historical Measurements
        val m1 = ClientMeasurement(
            id = UUID.randomUUID().toString(),
            clientId = client1.id,
            trainerId = trainerId,
            type = MeasurementType.WEIGHT,
            value = 70.0,
            unit = "kg",
            date = "2026-08-10",
            notes = "Intake baseline weight"
        )
        val m2 = ClientMeasurement(
            id = UUID.randomUUID().toString(),
            clientId = client1.id,
            trainerId = trainerId,
            type = MeasurementType.WEIGHT,
            value = 69.2,
            unit = "kg",
            date = "2026-08-24",
            notes = "Week 2 weigh-in"
        )
        val m3 = ClientMeasurement(
            id = UUID.randomUUID().toString(),
            clientId = client1.id,
            trainerId = trainerId,
            type = MeasurementType.WEIGHT,
            value = 68.2,
            unit = "kg",
            date = "2026-09-04",
            notes = "Current weigh-in"
        )
        val m4 = ClientMeasurement(
            id = UUID.randomUUID().toString(),
            clientId = client1.id,
            trainerId = trainerId,
            type = MeasurementType.WAIST,
            value = 76.0,
            unit = "cm",
            date = "2026-08-10",
            notes = "Intake baseline waist"
        )
        val m5 = ClientMeasurement(
            id = UUID.randomUUID().toString(),
            clientId = client1.id,
            trainerId = trainerId,
            type = MeasurementType.WAIST,
            value = 74.5,
            unit = "cm",
            date = "2026-09-04",
            notes = "Down 1.5cm despite scale plateau"
        )
        val m6 = ClientMeasurement(
            id = UUID.randomUUID().toString(),
            clientId = client1.id,
            trainerId = trainerId,
            type = MeasurementType.BODY_FAT_PERCENT,
            value = 26.2,
            unit = "%",
            date = "2026-08-10",
            notes = "Caliper estimate baseline"
        )
        val m7 = ClientMeasurement(
            id = UUID.randomUUID().toString(),
            clientId = client1.id,
            trainerId = trainerId,
            type = MeasurementType.BODY_FAT_PERCENT,
            value = 24.8,
            unit = "%",
            date = "2026-09-04",
            notes = "Down 1.4% body fat"
        )
        listOf(m1, m2, m3, m4, m5, m6, m7).forEach { measurementDao.insertMeasurement(it.toEntity()) }

        // Sarah's Progress Photos (Front & Left Side)
        progressPhotoDao.insertPhoto(
            ProgressPhoto(
                id = UUID.randomUUID().toString(),
                clientId = client1.id,
                trainerId = trainerId,
                photoUri = "android.resource://com.aistudio.coachos.ptai/drawable/ic_launcher_foreground",
                category = PhotoCategory.FRONT,
                date = "2026-08-10",
                notes = "Baseline front view (Week 1)"
            ).toEntity()
        )
        progressPhotoDao.insertPhoto(
            ProgressPhoto(
                id = UUID.randomUUID().toString(),
                clientId = client1.id,
                trainerId = trainerId,
                photoUri = "android.resource://com.aistudio.coachos.ptai/drawable/ic_launcher_foreground",
                category = PhotoCategory.LEFT,
                date = "2026-08-10",
                notes = "Baseline left posture view"
            ).toEntity()
        )

        // Sarah's Timeline Events
        listOf(
            TimelineEvent(
                id = UUID.randomUUID().toString(),
                clientId = client1.id,
                trainerId = trainerId,
                eventType = TimelineEventType.CLIENT_JOINED,
                title = "Client Joined CoachOS",
                description = "Sarah enrolled in the 20-session personal training transformation package.",
                date = "2026-08-09",
                timestamp = System.currentTimeMillis() - 86400000L * 29
            ),
            TimelineEvent(
                id = UUID.randomUUID().toString(),
                clientId = client1.id,
                trainerId = trainerId,
                eventType = TimelineEventType.CONSULTATION_COMPLETED,
                title = "Comprehensive Consultation",
                description = "Completed intake consultation covering nutrition, training history, and goals.",
                date = "2026-08-10",
                timestamp = System.currentTimeMillis() - 86400000L * 28
            ),
            TimelineEvent(
                id = UUID.randomUUID().toString(),
                clientId = client1.id,
                trainerId = trainerId,
                eventType = TimelineEventType.HEALTH_SCREENING_COMPLETED,
                title = "PAR-Q Health Screening Clear",
                description = "Reviewed medical background. Cleared with right knee warm-up precautions.",
                date = "2026-08-10",
                timestamp = System.currentTimeMillis() - 86400000L * 28 + 3600000L
            ),
            TimelineEvent(
                id = UUID.randomUUID().toString(),
                clientId = client1.id,
                trainerId = trainerId,
                eventType = TimelineEventType.ASSESSMENT_RECORDED,
                title = "Baseline Assessment Established",
                description = "Recorded movement screening, plank endurance, push-up test, and ankle mobility.",
                date = "2026-08-11",
                timestamp = System.currentTimeMillis() - 86400000L * 27
            ),
            TimelineEvent(
                id = UUID.randomUUID().toString(),
                clientId = client1.id,
                trainerId = trainerId,
                eventType = TimelineEventType.MEASUREMENT_RECORDED,
                title = "Waist Drop Recorded",
                description = "Waist measured at 74.5 cm (down 1.5 cm from baseline).",
                date = "2026-09-04",
                timestamp = System.currentTimeMillis() - 86400000L * 3
            )
        ).forEach { timelineEventDao.insertTimelineEvent(it.toEntity()) }
    }

    // --- Stage 2: Client Consultation ---

    fun getConsultation(trainerId: String, clientId: String): Flow<ClientConsultation?> {
        return clientConsultationDao.getConsultation(trainerId, clientId).map { entity ->
            entity?.toDomain()
        }
    }

    suspend fun saveConsultation(consultation: ClientConsultation) {
        clientConsultationDao.insertOrUpdateConsultation(consultation.toEntity())
        logAudit(consultation.trainerId, "SAVE_CONSULTATION", "CONSULTATION", consultation.clientId, "Saved consultation form (completed=${consultation.isCompleted})")
        if (consultation.isCompleted) {
            addTimelineEvent(
                TimelineEvent(
                    id = UUID.randomUUID().toString(),
                    clientId = consultation.clientId,
                    trainerId = consultation.trainerId,
                    eventType = TimelineEventType.CONSULTATION_COMPLETED,
                    title = "Consultation Completed",
                    description = "Initial onboarding consultation completed. Target goal: ${consultation.goals.primaryGoal.ifEmpty { "General Fitness" }}",
                    date = "Today"
                )
            )
        }
    }

    // --- Stage 2: PAR-Q & Health Screening ---

    fun getHealthScreening(trainerId: String, clientId: String): Flow<HealthScreening?> {
        return healthScreeningDao.getHealthScreening(trainerId, clientId).map { entity ->
            entity?.toDomain()
        }
    }

    suspend fun saveHealthScreening(screening: HealthScreening) {
        healthScreeningDao.insertOrUpdateHealthScreening(screening.toEntity())
        logAudit(screening.trainerId, "SAVE_HEALTH_SCREENING", "HEALTH_SCREENING", screening.clientId, "Health screening saved: Status ${screening.reviewStatus.name}")
        addTimelineEvent(
            TimelineEvent(
                id = UUID.randomUUID().toString(),
                clientId = screening.clientId,
                trainerId = screening.trainerId,
                eventType = TimelineEventType.HEALTH_SCREENING_COMPLETED,
                title = "Health Screening Completed",
                description = "PAR-Q exercise readiness reviewed. Status: ${screening.reviewStatus.label}",
                date = screening.date
            )
        )
    }

    // --- Stage 2: Client Goals ---

    fun getGoalsForClient(trainerId: String, clientId: String): Flow<List<ClientGoal>> {
        return clientGoalDao.getGoalsForClient(trainerId, clientId).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    suspend fun addGoal(goal: ClientGoal) {
        clientGoalDao.insertGoal(goal.toEntity())
        logAudit(goal.trainerId, "ADD_GOAL", "CLIENT_GOAL", goal.id, "Added goal: ${goal.title}")
    }

    suspend fun updateGoal(goal: ClientGoal) {
        clientGoalDao.updateGoal(goal.toEntity())
        logAudit(goal.trainerId, "UPDATE_GOAL", "CLIENT_GOAL", goal.id, "Updated goal: ${goal.title} status=${goal.status}")
    }

    suspend fun deleteGoal(trainerId: String, goalId: String) {
        clientGoalDao.deleteGoal(trainerId, goalId)
        logAudit(trainerId, "DELETE_GOAL", "CLIENT_GOAL", goalId, "Deleted goal")
    }

    // --- Stage 2: Lifestyle Profile ---

    fun getLifestyle(trainerId: String, clientId: String): Flow<ClientLifestyle?> {
        return clientLifestyleDao.getLifestyle(trainerId, clientId).map { entity ->
            entity?.toDomain()
        }
    }

    suspend fun saveLifestyle(lifestyle: ClientLifestyle) {
        clientLifestyleDao.insertOrUpdateLifestyle(lifestyle.toEntity())
        logAudit(lifestyle.trainerId, "SAVE_LIFESTYLE", "LIFESTYLE", lifestyle.clientId, "Updated lifestyle profile")
    }

    // --- Stage 2: Assessments & Baseline ---

    fun getAssessmentsForClient(trainerId: String, clientId: String): Flow<List<AssessmentSession>> {
        return assessmentDao.getAssessmentsForClient(trainerId, clientId).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    fun getBaselineAssessment(trainerId: String, clientId: String): Flow<AssessmentSession?> {
        return assessmentDao.getBaselineAssessment(trainerId, clientId).map { entity ->
            entity?.toDomain()
        }
    }

    suspend fun saveAssessment(assessment: AssessmentSession) {
        assessmentDao.insertAssessment(assessment.toEntity())
        if (assessment.isBaseline) {
            assessmentDao.clearOtherBaselines(assessment.trainerId, assessment.clientId, assessment.id)
        }
        logAudit(assessment.trainerId, "SAVE_ASSESSMENT", "ASSESSMENT", assessment.id, "Recorded assessment: ${assessment.title} (baseline=${assessment.isBaseline})")
        addTimelineEvent(
            TimelineEvent(
                id = UUID.randomUUID().toString(),
                clientId = assessment.clientId,
                trainerId = assessment.trainerId,
                eventType = TimelineEventType.ASSESSMENT_RECORDED,
                title = if (assessment.isBaseline) "Baseline Assessment Recorded" else "Assessment Recorded",
                description = "${assessment.title} • ${assessment.items.size} test metrics recorded",
                date = assessment.date
            )
        )
    }

    suspend fun deleteAssessment(trainerId: String, assessmentId: String) {
        assessmentDao.deleteAssessment(trainerId, assessmentId)
        logAudit(trainerId, "DELETE_ASSESSMENT", "ASSESSMENT", assessmentId, "Deleted assessment")
    }

    // --- Stage 2: Client Measurements ---

    fun getMeasurementsForClient(trainerId: String, clientId: String): Flow<List<ClientMeasurement>> {
        return measurementDao.getMeasurementsForClient(trainerId, clientId).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    fun getLatestWeight(trainerId: String, clientId: String): Flow<ClientMeasurement?> {
        return measurementDao.getLatestMeasurement(trainerId, clientId, MeasurementType.WEIGHT.name).map { entity ->
            entity?.toDomain()
        }
    }

    suspend fun addMeasurement(measurement: ClientMeasurement) {
        measurementDao.insertMeasurement(measurement.toEntity())
        if (measurement.type == MeasurementType.WEIGHT) {
            val client = clientDao.getClientByIdOnce(measurement.trainerId, measurement.clientId)
            if (client != null) {
                clientDao.updateClient(client.copy(currentWeightKg = measurement.value, updatedAt = System.currentTimeMillis()))
            }
        }
        logAudit(measurement.trainerId, "ADD_MEASUREMENT", "MEASUREMENT", measurement.id, "Recorded ${measurement.type.label}: ${measurement.value} ${measurement.unit}")
        addTimelineEvent(
            TimelineEvent(
                id = UUID.randomUUID().toString(),
                clientId = measurement.clientId,
                trainerId = measurement.trainerId,
                eventType = TimelineEventType.MEASUREMENT_RECORDED,
                title = "Measurement Recorded",
                description = "${measurement.type.label}: ${measurement.value} ${measurement.unit}",
                date = measurement.date
            )
        )
    }

    suspend fun deleteMeasurement(trainerId: String, measurementId: String) {
        measurementDao.deleteMeasurement(trainerId, measurementId)
        logAudit(trainerId, "DELETE_MEASUREMENT", "MEASUREMENT", measurementId, "Deleted measurement")
    }

    // --- Stage 2: Progress Photos ---

    fun getPhotosForClient(trainerId: String, clientId: String): Flow<List<ProgressPhoto>> {
        return progressPhotoDao.getPhotosForClient(trainerId, clientId).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    suspend fun addPhoto(photo: ProgressPhoto) {
        progressPhotoDao.insertPhoto(photo.toEntity())
        logAudit(photo.trainerId, "ADD_PHOTO", "PROGRESS_PHOTO", photo.id, "Uploaded progress photo: ${photo.category.label}")
        addTimelineEvent(
            TimelineEvent(
                id = UUID.randomUUID().toString(),
                clientId = photo.clientId,
                trainerId = photo.trainerId,
                eventType = TimelineEventType.PHOTO_UPLOADED,
                title = "Progress Photo Added",
                description = "Category: ${photo.category.label} (${photo.date})",
                date = photo.date
            )
        )
    }

    suspend fun deletePhoto(trainerId: String, photoId: String) {
        progressPhotoDao.deletePhoto(trainerId, photoId)
        logAudit(trainerId, "DELETE_PHOTO", "PROGRESS_PHOTO", photoId, "Deleted progress photo")
    }

    // --- Stage 2: Client Timeline ---

    fun getTimelineEvents(trainerId: String, clientId: String): Flow<List<TimelineEvent>> {
        return timelineEventDao.getTimelineEvents(trainerId, clientId).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    suspend fun addTimelineEvent(event: TimelineEvent) {
        timelineEventDao.insertTimelineEvent(event.toEntity())
    }

    suspend fun saveAssessmentSession(assessment: AssessmentSession) = saveAssessment(assessment)
    suspend fun deleteAssessmentSession(trainerId: String, assessmentId: String) = deleteAssessment(trainerId, assessmentId)
    suspend fun setSessionAsBaseline(trainerId: String, clientId: String, sessionId: String) {
        assessmentDao.clearOtherBaselines(trainerId, clientId, sessionId)
        assessmentDao.markAsBaseline(trainerId, sessionId)
        logAudit(trainerId, "SET_BASELINE", "ASSESSMENT", sessionId, "Marked assessment as baseline")
    }

    fun getProgressPhotosForClient(trainerId: String, clientId: String): Flow<List<ProgressPhoto>> = getPhotosForClient(trainerId, clientId)
    suspend fun addProgressPhoto(photo: ProgressPhoto) = addPhoto(photo)
    suspend fun deleteProgressPhoto(trainerId: String, photoId: String) = deletePhoto(trainerId, photoId)

    fun getTimelineForClient(trainerId: String, clientId: String): Flow<List<TimelineEvent>> = getTimelineEvents(trainerId, clientId)

    private fun ClientEntity.toDomain() = Client(
        id = id,
        trainerId = trainerId,
        fullName = fullName,
        email = email,
        phone = phone,
        avatarUrl = avatarUrl,
        primaryGoal = primaryGoal,
        goalType = runCatching { PrimaryGoalType.valueOf(goalType) }.getOrDefault(PrimaryGoalType.BODY_RECOMPOSITION),
        currentProgram = currentProgram,
        status = runCatching { ClientStatus.valueOf(status) }.getOrDefault(ClientStatus.ACTIVE),
        fitnessLevel = runCatching { FitnessLevel.valueOf(fitnessLevel) }.getOrDefault(FitnessLevel.INTERMEDIATE),
        dateOfBirth = dateOfBirth,
        gender = gender,
        occupation = occupation,
        targetTimelineWeeks = targetTimelineWeeks,
        packageTotalSessions = packageTotalSessions,
        packageRemainingSessions = packageRemainingSessions,
        sessionsCompleted = sessionsCompleted,
        attendanceRatePercent = attendanceRatePercent,
        lastWorkoutDate = lastWorkoutDate,
        lastCheckInDate = lastCheckInDate,
        needsAttention = needsAttention,
        attentionReason = attentionReason,
        readinessScore = readinessScore,
        readinessReason = readinessReason,
        currentWeightKg = currentWeightKg,
        targetWeightKg = targetWeightKg,
        notesSummary = notesSummary,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    private fun Client.toEntity() = ClientEntity(
        id = id,
        trainerId = trainerId,
        fullName = fullName,
        email = email,
        phone = phone,
        avatarUrl = avatarUrl,
        primaryGoal = primaryGoal,
        goalType = goalType.name,
        currentProgram = currentProgram,
        status = status.name,
        fitnessLevel = fitnessLevel.name,
        dateOfBirth = dateOfBirth,
        gender = gender,
        occupation = occupation,
        targetTimelineWeeks = targetTimelineWeeks,
        packageTotalSessions = packageTotalSessions,
        packageRemainingSessions = packageRemainingSessions,
        sessionsCompleted = sessionsCompleted,
        attendanceRatePercent = attendanceRatePercent,
        lastWorkoutDate = lastWorkoutDate,
        lastCheckInDate = lastCheckInDate,
        needsAttention = needsAttention,
        attentionReason = attentionReason,
        readinessScore = readinessScore,
        readinessReason = readinessReason,
        currentWeightKg = currentWeightKg,
        targetWeightKg = targetWeightKg,
        notesSummary = notesSummary,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    private fun ScheduledSessionEntity.toDomain() = ScheduledSession(
        id = id,
        trainerId = trainerId,
        clientId = clientId,
        clientName = clientName,
        sessionTimeText = sessionTimeText,
        sessionDateText = sessionDateText,
        durationMinutes = durationMinutes,
        status = runCatching { SessionStatus.valueOf(status) }.getOrDefault(SessionStatus.SCHEDULED),
        sessionFocus = sessionFocus,
        location = location,
        notes = notes,
        timestamp = timestamp
    )

    private fun ScheduledSession.toEntity() = ScheduledSessionEntity(
        id = id,
        trainerId = trainerId,
        clientId = clientId,
        clientName = clientName,
        sessionTimeText = sessionTimeText,
        sessionDateText = sessionDateText,
        durationMinutes = durationMinutes,
        status = status.name,
        sessionFocus = sessionFocus,
        location = location,
        notes = notes,
        timestamp = timestamp
    )

    private fun AiRecommendationEntity.toDomain() = AiRecommendation(
        id = id,
        clientId = clientId,
        clientName = clientName,
        priority = runCatching { ActionPriority.valueOf(priority) }.getOrDefault(ActionPriority.MEDIUM),
        recommendation = recommendation,
        reason = reason,
        supportingData = supportingDataJson.split(",").map { it.trim() }.filter { it.isNotEmpty() },
        confidence = confidence,
        considerations = considerationsJson.split(";").map { it.trim() }.filter { it.isNotEmpty() },
        status = runCatching { ActionStatus.valueOf(status) }.getOrDefault(ActionStatus.PENDING),
        timestamp = timestamp
    )

    private fun AiRecommendation.toEntity() = AiRecommendationEntity(
        id = id,
        clientId = clientId,
        clientName = clientName,
        priority = priority.name,
        recommendation = recommendation,
        reason = reason,
        supportingDataJson = supportingData.joinToString(", "),
        confidence = confidence,
        considerationsJson = considerations.joinToString("; "),
        status = status.name,
        timestamp = timestamp
    )

    // --- Stage 2 Mappers & JSON Converters ---

    private fun questionsToJson(questions: List<ScreeningQuestion>): String {
        val arr = JSONArray()
        for (q in questions) {
            val obj = JSONObject()
            obj.put("id", q.id)
            obj.put("questionText", q.questionText)
            obj.put("answerYes", q.answerYes)
            obj.put("followUpPrompt", q.followUpPrompt)
            obj.put("followUpAnswer", q.followUpAnswer)
            obj.put("notes", q.notes)
            arr.put(obj)
        }
        return arr.toString()
    }

    private fun jsonToQuestions(json: String): List<ScreeningQuestion> {
        if (json.isBlank()) return HealthScreening.defaultScreeningQuestions()
        return try {
            val list = mutableListOf<ScreeningQuestion>()
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    ScreeningQuestion(
                        id = obj.optString("id", "q$i"),
                        questionText = obj.optString("questionText", ""),
                        answerYes = obj.optBoolean("answerYes", false),
                        followUpPrompt = obj.optString("followUpPrompt", ""),
                        followUpAnswer = obj.optString("followUpAnswer", ""),
                        notes = obj.optString("notes", "")
                    )
                )
            }
            list
        } catch (e: Exception) {
            HealthScreening.defaultScreeningQuestions()
        }
    }

    private fun itemsToJson(items: List<AssessmentItem>): String {
        val arr = JSONArray()
        for (it in items) {
            val obj = JSONObject()
            obj.put("id", it.id)
            obj.put("category", it.category.name)
            obj.put("testName", it.testName)
            obj.put("resultValue", it.resultValue)
            obj.put("unit", it.unit)
            obj.put("baselineValue", it.baselineValue ?: "")
            obj.put("notes", it.notes)
            arr.put(obj)
        }
        return arr.toString()
    }

    private fun jsonToItems(json: String): List<AssessmentItem> {
        if (json.isBlank()) return emptyList()
        return try {
            val list = mutableListOf<AssessmentItem>()
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    AssessmentItem(
                        id = obj.optString("id", UUID.randomUUID().toString()),
                        category = runCatching { AssessmentCategory.valueOf(obj.optString("category")) }.getOrDefault(AssessmentCategory.MOVEMENT_OBSERVATIONS),
                        testName = obj.optString("testName", ""),
                        resultValue = obj.optString("resultValue", ""),
                        unit = obj.optString("unit", ""),
                        baselineValue = obj.optString("baselineValue").takeIf { it.isNotBlank() },
                        notes = obj.optString("notes", "")
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun ClientConsultationEntity.toDomain() = ClientConsultation(
        clientId = clientId,
        trainerId = trainerId,
        personal = ConsultationPersonalInfo(
            fullName = fullName,
            dateOfBirth = dateOfBirth,
            gender = gender,
            phone = phone,
            email = email,
            occupation = occupation,
            emergencyContactName = emergencyContactName,
            emergencyContactPhone = emergencyContactPhone
        ),
        lifestyle = ConsultationLifestyle(
            dailyActivity = dailyActivity,
            averageSteps = averageSteps,
            sleepDurationHours = sleepDurationHours,
            sleepQuality = sleepQuality,
            stressLevel = stressLevel,
            workSchedule = workSchedule,
            lifestyleNotes = lifestyleNotes
        ),
        trainingHistory = ConsultationTrainingHistory(
            previousExperience = previousExperience,
            currentActivity = currentActivity,
            previousProgrammes = previousProgrammes,
            favouriteExercises = favouriteExercises,
            dislikedExercises = dislikedExercises,
            trainingLimitations = trainingLimitations,
            equipmentAvailability = equipmentAvailability
        ),
        goals = ConsultationGoals(
            primaryGoal = primaryGoal,
            secondaryGoals = secondaryGoals,
            targetDate = targetDate,
            motivation = motivation,
            desiredOutcome = desiredOutcome
        ),
        nutrition = ConsultationNutrition(
            eatingPattern = eatingPattern,
            mealsPerDay = mealsPerDay,
            waterIntakeLiters = waterIntakeLiters,
            foodPreferences = foodPreferences,
            dietaryRestrictions = dietaryRestrictions,
            nutritionNotes = nutritionNotes
        ),
        trainerNotes = trainerNotes,
        isCompleted = isCompleted,
        lastSavedAt = lastSavedAt
    )

    private fun ClientConsultation.toEntity() = ClientConsultationEntity(
        clientId = clientId,
        trainerId = trainerId,
        fullName = personal.fullName,
        dateOfBirth = personal.dateOfBirth,
        gender = personal.gender,
        phone = personal.phone,
        email = personal.email,
        occupation = personal.occupation,
        emergencyContactName = personal.emergencyContactName,
        emergencyContactPhone = personal.emergencyContactPhone,
        dailyActivity = lifestyle.dailyActivity,
        averageSteps = lifestyle.averageSteps,
        sleepDurationHours = lifestyle.sleepDurationHours,
        sleepQuality = lifestyle.sleepQuality,
        stressLevel = lifestyle.stressLevel,
        workSchedule = lifestyle.workSchedule,
        lifestyleNotes = lifestyle.lifestyleNotes,
        previousExperience = trainingHistory.previousExperience,
        currentActivity = trainingHistory.currentActivity,
        previousProgrammes = trainingHistory.previousProgrammes,
        favouriteExercises = trainingHistory.favouriteExercises,
        dislikedExercises = trainingHistory.dislikedExercises,
        trainingLimitations = trainingHistory.trainingLimitations,
        equipmentAvailability = trainingHistory.equipmentAvailability,
        primaryGoal = goals.primaryGoal,
        secondaryGoals = goals.secondaryGoals,
        targetDate = goals.targetDate,
        motivation = goals.motivation,
        desiredOutcome = goals.desiredOutcome,
        eatingPattern = nutrition.eatingPattern,
        mealsPerDay = nutrition.mealsPerDay,
        waterIntakeLiters = nutrition.waterIntakeLiters,
        foodPreferences = nutrition.foodPreferences,
        dietaryRestrictions = nutrition.dietaryRestrictions,
        nutritionNotes = nutrition.nutritionNotes,
        trainerNotes = trainerNotes,
        isCompleted = isCompleted,
        lastSavedAt = lastSavedAt
    )

    private fun HealthScreeningEntity.toDomain() = HealthScreening(
        clientId = clientId,
        trainerId = trainerId,
        date = date,
        reviewStatus = runCatching { ScreeningReviewStatus.valueOf(reviewStatus) }.getOrDefault(ScreeningReviewStatus.CLEAR),
        questions = jsonToQuestions(questionsJson),
        trainerNotes = trainerNotes,
        disclaimerAcknowledged = disclaimerAcknowledged,
        updatedAt = updatedAt
    )

    private fun HealthScreening.toEntity() = HealthScreeningEntity(
        clientId = clientId,
        trainerId = trainerId,
        date = date,
        reviewStatus = reviewStatus.name,
        questionsJson = questionsToJson(questions),
        trainerNotes = trainerNotes,
        disclaimerAcknowledged = disclaimerAcknowledged,
        updatedAt = updatedAt
    )

    private fun ClientGoalEntity.toDomain() = ClientGoal(
        id = id,
        clientId = clientId,
        trainerId = trainerId,
        title = title,
        isPrimary = isPrimary,
        category = runCatching { GoalCategory.valueOf(category) }.getOrDefault(GoalCategory.GENERAL_HEALTH),
        targetDate = targetDate,
        targetMetric = targetMetric,
        startingValue = startingValue,
        currentValue = currentValue,
        targetValue = targetValue,
        status = runCatching { GoalStatus.valueOf(status) }.getOrDefault(GoalStatus.IN_PROGRESS),
        notes = notes,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    private fun ClientGoal.toEntity() = ClientGoalEntity(
        id = id,
        clientId = clientId,
        trainerId = trainerId,
        title = title,
        isPrimary = isPrimary,
        category = category.name,
        targetDate = targetDate,
        targetMetric = targetMetric,
        startingValue = startingValue,
        currentValue = currentValue,
        targetValue = targetValue,
        status = status.name,
        notes = notes,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    private fun ClientLifestyleEntity.toDomain() = ClientLifestyle(
        clientId = clientId,
        trainerId = trainerId,
        sleepDurationHours = sleepDurationHours,
        sleepQualityRating = sleepQualityRating,
        stressRating = stressRating,
        activityLevel = activityLevel,
        dailyAverageSteps = dailyAverageSteps,
        workScheduleType = workScheduleType,
        recoveryRating = recoveryRating,
        hydrationLiters = hydrationLiters,
        nutritionHabitsSummary = nutritionHabitsSummary,
        trainingAvailabilityDays = trainingAvailabilityDays,
        lifestyleNotes = lifestyleNotes,
        updatedAt = updatedAt
    )

    private fun ClientLifestyle.toEntity() = ClientLifestyleEntity(
        clientId = clientId,
        trainerId = trainerId,
        sleepDurationHours = sleepDurationHours,
        sleepQualityRating = sleepQualityRating,
        stressRating = stressRating,
        activityLevel = activityLevel,
        dailyAverageSteps = dailyAverageSteps,
        workScheduleType = workScheduleType,
        recoveryRating = recoveryRating,
        hydrationLiters = hydrationLiters,
        nutritionHabitsSummary = nutritionHabitsSummary,
        trainingAvailabilityDays = trainingAvailabilityDays,
        lifestyleNotes = lifestyleNotes,
        updatedAt = updatedAt
    )

    private fun AssessmentSessionEntity.toDomain(): AssessmentSession {
        val cats = categoriesJson.split(",").mapNotNull {
            runCatching { AssessmentCategory.valueOf(it.trim()) }.getOrNull()
        }
        return AssessmentSession(
            id = id,
            clientId = clientId,
            trainerId = trainerId,
            title = title,
            date = date,
            isBaseline = isBaseline,
            selectedCategories = if (cats.isNotEmpty()) cats else listOf(AssessmentCategory.MOVEMENT_OBSERVATIONS, AssessmentCategory.STRENGTH),
            items = jsonToItems(itemsJson),
            summaryObservations = summaryObservations,
            trainerRecommendations = trainerRecommendations,
            createdAt = createdAt
        )
    }

    private fun AssessmentSession.toEntity() = AssessmentSessionEntity(
        id = id,
        clientId = clientId,
        trainerId = trainerId,
        title = title,
        date = date,
        isBaseline = isBaseline,
        categoriesJson = selectedCategories.joinToString(",") { it.name },
        itemsJson = itemsToJson(items),
        summaryObservations = summaryObservations,
        trainerRecommendations = trainerRecommendations,
        createdAt = createdAt
    )

    private fun ClientMeasurementEntity.toDomain() = ClientMeasurement(
        id = id,
        clientId = clientId,
        trainerId = trainerId,
        type = runCatching { MeasurementType.valueOf(type) }.getOrDefault(MeasurementType.WEIGHT),
        customTypeName = customTypeName,
        value = value,
        unit = unit,
        date = date,
        notes = notes,
        createdAt = createdAt
    )

    private fun ClientMeasurement.toEntity() = ClientMeasurementEntity(
        id = id,
        clientId = clientId,
        trainerId = trainerId,
        type = type.name,
        customTypeName = customTypeName,
        value = value,
        unit = unit,
        date = date,
        notes = notes,
        createdAt = createdAt
    )

    private fun ProgressPhotoEntity.toDomain() = ProgressPhoto(
        id = id,
        clientId = clientId,
        trainerId = trainerId,
        photoUri = photoUri,
        category = runCatching { PhotoCategory.valueOf(category) }.getOrDefault(PhotoCategory.FRONT),
        customCategoryName = customCategoryName,
        date = date,
        notes = notes,
        createdAt = createdAt
    )

    private fun ProgressPhoto.toEntity() = ProgressPhotoEntity(
        id = id,
        clientId = clientId,
        trainerId = trainerId,
        photoUri = photoUri,
        category = category.name,
        customCategoryName = customCategoryName,
        date = date,
        notes = notes,
        createdAt = createdAt
    )

    private fun TimelineEventEntity.toDomain() = TimelineEvent(
        id = id,
        clientId = clientId,
        trainerId = trainerId,
        eventType = runCatching { TimelineEventType.valueOf(eventType) }.getOrDefault(TimelineEventType.TRAINER_NOTE_ADDED),
        title = title,
        description = description,
        date = date,
        timestamp = timestamp
    )

    private fun TimelineEvent.toEntity() = TimelineEventEntity(
        id = id,
        clientId = clientId,
        trainerId = trainerId,
        eventType = eventType.name,
        title = title,
        description = description,
        date = date,
        timestamp = timestamp
    )
}
