package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.model.*

@Entity(
    tableName = "exercises",
    indices = [
        Index(value = ["name"]),
        Index(value = ["category"]),
        Index(value = ["primaryMuscle"]),
        Index(value = ["equipment"]),
        Index(value = ["trainerId"])
    ]
)
data class ExerciseEntity(
    @PrimaryKey val id: String,
    val trainerId: String?,
    val name: String,
    val category: String,
    val primaryMuscle: String,
    val secondaryMusclesCsv: String,
    val movementPattern: String,
    val equipment: String,
    val difficulty: String,
    val instructionsPipe: String,
    val coachingCuesPipe: String,
    val commonMistakesPipe: String,
    val trainerNotes: String,
    val alternativeExerciseIdsCsv: String,
    val videoReference: String,
    val isCustom: Boolean,
    val createdAt: Long
)

@Entity(
    tableName = "programmes",
    indices = [
        Index(value = ["trainerId"]),
        Index(value = ["clientId"]),
        Index(value = ["isTemplate"])
    ]
)
data class ProgrammeEntity(
    @PrimaryKey val id: String,
    val trainerId: String,
    val clientId: String?,
    val name: String,
    val goal: String,
    val durationWeeks: Int,
    val weeklyFrequency: Int,
    val startDate: String,
    val endDate: String,
    val notes: String,
    val isTemplate: Boolean,
    val version: Int,
    val parentProgrammeId: String?,
    val status: String,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "programme_versions",
    indices = [
        Index(value = ["programmeId"]),
        Index(value = ["trainerId"])
    ]
)
data class ProgrammeVersionEntity(
    @PrimaryKey val id: String,
    val programmeId: String,
    val trainerId: String,
    val versionNumber: Int,
    val date: String,
    val changesSummary: String,
    val reasonForChange: String,
    val snapshotJson: String,
    val createdAt: Long
)

@Entity(
    tableName = "training_days",
    indices = [
        Index(value = ["programmeId"]),
        Index(value = ["orderIndex"])
    ]
)
data class TrainingDayEntity(
    @PrimaryKey val id: String,
    val programmeId: String,
    val dayName: String,
    val dayOfWeek: String,
    val orderIndex: Int,
    val focusNotes: String
)

@Entity(
    tableName = "workout_exercises",
    indices = [
        Index(value = ["workoutDayId"]),
        Index(value = ["exerciseId"]),
        Index(value = ["orderIndex"])
    ]
)
data class WorkoutExerciseEntity(
    @PrimaryKey val id: String,
    val workoutDayId: String,
    val exerciseId: String,
    val exerciseName: String,
    val orderIndex: Int,
    val isWarmup: Boolean,
    val exerciseStructure: String,
    val groupTag: String,
    val targetSets: Int,
    val targetReps: String,
    val targetWeightKg: Double?,
    val targetDurationSec: Int?,
    val targetDistanceMeters: Double?,
    val restSec: Int,
    val tempo: String,
    val targetRpe: Double?,
    val notes: String
)

@Entity(
    tableName = "workout_logs",
    indices = [
        Index(value = ["trainerId"]),
        Index(value = ["clientId"]),
        Index(value = ["programmeId"]),
        Index(value = ["date"])
    ]
)
data class WorkoutLogEntity(
    @PrimaryKey val id: String,
    val trainerId: String,
    val clientId: String,
    val programmeId: String?,
    val workoutDayId: String?,
    val workoutTitle: String,
    val date: String,
    val startTimeMs: Long,
    val endTimeMs: Long?,
    val durationMinutes: Int,
    val totalVolumeKg: Double,
    val totalReps: Int,
    val totalSetsCompleted: Int,
    val completionPercentage: Int,
    val averageRpe: Double?,
    val sessionNotes: String,
    val isCompleted: Boolean,
    val createdAt: Long
)

@Entity(
    tableName = "logged_sets",
    indices = [
        Index(value = ["workoutLogId"]),
        Index(value = ["exerciseId"])
    ]
)
data class LoggedSetEntity(
    @PrimaryKey val id: String,
    val workoutLogId: String,
    val exerciseId: String,
    val exerciseName: String,
    val setNumber: Int,
    val plannedWeightKg: Double?,
    val plannedReps: Int?,
    val plannedRpe: Double?,
    val actualWeightKg: Double,
    val actualReps: Int,
    val actualRpe: Double?,
    val actualDurationSec: Int?,
    val setType: String,
    val isCompleted: Boolean,
    val notes: String,
    val timestamp: Long
)
