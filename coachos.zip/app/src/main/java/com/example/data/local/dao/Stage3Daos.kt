package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ExerciseDao {
    @Query("SELECT * FROM exercises WHERE trainerId IS NULL OR trainerId = :trainerId ORDER BY name ASC")
    fun getAllExercises(trainerId: String): Flow<List<ExerciseEntity>>

    @Query("SELECT * FROM exercises WHERE (trainerId IS NULL OR trainerId = :trainerId) AND (name LIKE '%' || :query || '%' OR primaryMuscle LIKE '%' || :query || '%' OR category LIKE '%' || :query || '%') ORDER BY name ASC")
    fun searchExercises(trainerId: String, query: String): Flow<List<ExerciseEntity>>

    @Query("SELECT * FROM exercises WHERE id = :id")
    suspend fun getExerciseById(id: String): ExerciseEntity?

    @Query("SELECT COUNT(*) FROM exercises")
    suspend fun getExerciseCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExercise(exercise: ExerciseEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExercises(exercises: List<ExerciseEntity>)

    @Query("DELETE FROM exercises WHERE id = :exerciseId AND trainerId = :trainerId")
    suspend fun deleteCustomExercise(trainerId: String, exerciseId: String)
}

@Dao
interface ProgrammeDao {
    @Query("SELECT * FROM programmes WHERE trainerId = :trainerId AND isTemplate = 0 ORDER BY updatedAt DESC")
    fun getProgrammesForTrainer(trainerId: String): Flow<List<ProgrammeEntity>>

    @Query("SELECT * FROM programmes WHERE trainerId = :trainerId AND clientId = :clientId AND isTemplate = 0 ORDER BY updatedAt DESC")
    fun getProgrammesForClient(trainerId: String, clientId: String): Flow<List<ProgrammeEntity>>

    @Query("SELECT * FROM programmes WHERE trainerId = :trainerId AND isTemplate = 1 ORDER BY name ASC")
    fun getTemplatesForTrainer(trainerId: String): Flow<List<ProgrammeEntity>>

    @Query("SELECT * FROM programmes WHERE trainerId = :trainerId AND id = :programmeId")
    suspend fun getProgrammeById(trainerId: String, programmeId: String): ProgrammeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProgramme(programme: ProgrammeEntity)

    @Update
    suspend fun updateProgramme(programme: ProgrammeEntity)

    @Query("DELETE FROM programmes WHERE trainerId = :trainerId AND id = :programmeId")
    suspend fun deleteProgramme(trainerId: String, programmeId: String)
}

@Dao
interface ProgrammeVersionDao {
    @Query("SELECT * FROM programme_versions WHERE programmeId = :programmeId ORDER BY versionNumber DESC")
    fun getVersionsForProgramme(programmeId: String): Flow<List<ProgrammeVersionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVersion(version: ProgrammeVersionEntity)
}

@Dao
interface TrainingDayDao {
    @Query("SELECT * FROM training_days WHERE programmeId = :programmeId ORDER BY orderIndex ASC")
    fun getDaysForProgramme(programmeId: String): Flow<List<TrainingDayEntity>>

    @Query("SELECT * FROM training_days WHERE programmeId = :programmeId ORDER BY orderIndex ASC")
    suspend fun getDaysForProgrammeSync(programmeId: String): List<TrainingDayEntity>

    @Query("SELECT * FROM training_days WHERE id = :dayId")
    suspend fun getDayById(dayId: String): TrainingDayEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDay(day: TrainingDayEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDays(days: List<TrainingDayEntity>)

    @Query("DELETE FROM training_days WHERE id = :dayId")
    suspend fun deleteDay(dayId: String)

    @Query("DELETE FROM training_days WHERE programmeId = :programmeId")
    suspend fun deleteDaysForProgramme(programmeId: String)
}

@Dao
interface WorkoutExerciseDao {
    @Query("SELECT * FROM workout_exercises WHERE workoutDayId = :workoutDayId ORDER BY orderIndex ASC")
    fun getExercisesForDay(workoutDayId: String): Flow<List<WorkoutExerciseEntity>>

    @Query("SELECT * FROM workout_exercises WHERE workoutDayId = :workoutDayId ORDER BY orderIndex ASC")
    suspend fun getExercisesForDaySync(workoutDayId: String): List<WorkoutExerciseEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkoutExercise(exercise: WorkoutExerciseEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkoutExercises(exercises: List<WorkoutExerciseEntity>)

    @Query("DELETE FROM workout_exercises WHERE id = :id")
    suspend fun deleteWorkoutExercise(id: String)

    @Query("DELETE FROM workout_exercises WHERE workoutDayId = :workoutDayId")
    suspend fun deleteExercisesForDay(workoutDayId: String)
}

@Dao
interface WorkoutLogDao {
    @Query("SELECT * FROM workout_logs WHERE trainerId = :trainerId ORDER BY createdAt DESC")
    fun getLogsForTrainer(trainerId: String): Flow<List<WorkoutLogEntity>>

    @Query("SELECT * FROM workout_logs WHERE trainerId = :trainerId AND clientId = :clientId ORDER BY createdAt DESC")
    fun getLogsForClient(trainerId: String, clientId: String): Flow<List<WorkoutLogEntity>>

    @Query("SELECT * FROM workout_logs WHERE trainerId = :trainerId ORDER BY createdAt DESC LIMIT :limit")
    fun getRecentLogs(trainerId: String, limit: Int): Flow<List<WorkoutLogEntity>>

    @Query("SELECT * FROM workout_logs WHERE id = :id")
    suspend fun getLogById(id: String): WorkoutLogEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkoutLog(log: WorkoutLogEntity)

    @Update
    suspend fun updateWorkoutLog(log: WorkoutLogEntity)

    @Query("DELETE FROM workout_logs WHERE trainerId = :trainerId AND id = :logId")
    suspend fun deleteWorkoutLog(trainerId: String, logId: String)
}

@Dao
interface LoggedSetDao {
    @Query("SELECT * FROM logged_sets WHERE workoutLogId = :workoutLogId ORDER BY setNumber ASC")
    fun getSetsForLog(workoutLogId: String): Flow<List<LoggedSetEntity>>

    @Query("SELECT * FROM logged_sets WHERE workoutLogId = :workoutLogId ORDER BY setNumber ASC")
    suspend fun getSetsForLogSync(workoutLogId: String): List<LoggedSetEntity>

    @Query("SELECT * FROM logged_sets WHERE exerciseId = :exerciseId AND isCompleted = 1 ORDER BY timestamp DESC")
    fun getSetsForExercise(exerciseId: String): Flow<List<LoggedSetEntity>>

    @Query("SELECT * FROM logged_sets WHERE exerciseId = :exerciseId AND isCompleted = 1 ORDER BY timestamp DESC")
    suspend fun getSetsForExerciseSync(exerciseId: String): List<LoggedSetEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSet(set: LoggedSetEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSets(sets: List<LoggedSetEntity>)

    @Query("DELETE FROM logged_sets WHERE workoutLogId = :workoutLogId")
    suspend fun deleteSetsForLog(workoutLogId: String)
}
