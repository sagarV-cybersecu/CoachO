package com.example.data.session

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SessionManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("coach_os_session_prefs", Context.MODE_PRIVATE)

    private val _currentTrainerId = MutableStateFlow(prefs.getString(KEY_TRAINER_ID, null))
    val currentTrainerId: StateFlow<String?> = _currentTrainerId.asStateFlow()

    private val _isLoggedIn = MutableStateFlow(prefs.getBoolean(KEY_IS_LOGGED_IN, false))
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    fun saveSession(trainerId: String, email: String, displayName: String) {
        prefs.edit()
            .putString(KEY_TRAINER_ID, trainerId)
            .putString(KEY_EMAIL, email)
            .putString(KEY_DISPLAY_NAME, displayName)
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .apply()

        _currentTrainerId.value = trainerId
        _isLoggedIn.value = true
    }

    fun clearSession() {
        prefs.edit().clear().apply()
        _currentTrainerId.value = null
        _isLoggedIn.value = false
    }

    fun getTrainerDisplayName(): String {
        return prefs.getString(KEY_DISPLAY_NAME, "Coach") ?: "Coach"
    }

    fun getTrainerEmail(): String {
        return prefs.getString(KEY_EMAIL, "") ?: ""
    }

    companion object {
        private const val KEY_TRAINER_ID = "trainer_id"
        private const val KEY_EMAIL = "email"
        private const val KEY_DISPLAY_NAME = "display_name"
        private const val KEY_IS_LOGGED_IN = "is_logged_in"

        @Volatile
        private var INSTANCE: SessionManager? = null

        fun getInstance(context: Context): SessionManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SessionManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
