package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "client_consultations",
    indices = [Index(value = ["clientId"], unique = true), Index(value = ["trainerId"])]
)
data class ClientConsultationEntity(
    @PrimaryKey val clientId: String,
    val trainerId: String,
    // Personal
    val fullName: String,
    val dateOfBirth: String,
    val gender: String,
    val phone: String,
    val email: String,
    val occupation: String,
    val emergencyContactName: String,
    val emergencyContactPhone: String,
    // Lifestyle
    val dailyActivity: String,
    val averageSteps: Int,
    val sleepDurationHours: Double,
    val sleepQuality: Int,
    val stressLevel: Int,
    val workSchedule: String,
    val lifestyleNotes: String,
    // Training History
    val previousExperience: String,
    val currentActivity: String,
    val previousProgrammes: String,
    val favouriteExercises: String,
    val dislikedExercises: String,
    val trainingLimitations: String,
    val equipmentAvailability: String,
    // Goals
    val primaryGoal: String,
    val secondaryGoals: String,
    val targetDate: String,
    val motivation: String,
    val desiredOutcome: String,
    // Nutrition
    val eatingPattern: String,
    val mealsPerDay: Int,
    val waterIntakeLiters: Double,
    val foodPreferences: String,
    val dietaryRestrictions: String,
    val nutritionNotes: String,
    // Trainer Notes & Metadata
    val trainerNotes: String,
    val isCompleted: Boolean,
    val lastSavedAt: Long
)

@Entity(
    tableName = "health_screenings",
    indices = [Index(value = ["clientId"], unique = true), Index(value = ["trainerId"])]
)
data class HealthScreeningEntity(
    @PrimaryKey val clientId: String,
    val trainerId: String,
    val date: String,
    val reviewStatus: String, // CLEAR, REVIEW_REQUIRED, PROFESSIONAL_CLEARANCE_RECOMMENDED
    val questionsJson: String, // serialized JSON of questions and answers
    val trainerNotes: String,
    val disclaimerAcknowledged: Boolean,
    val updatedAt: Long
)

@Entity(
    tableName = "client_goals",
    indices = [Index(value = ["clientId"]), Index(value = ["trainerId"])]
)
data class ClientGoalEntity(
    @PrimaryKey val id: String,
    val clientId: String,
    val trainerId: String,
    val title: String,
    val isPrimary: Boolean,
    val category: String,
    val targetDate: String,
    val targetMetric: String,
    val startingValue: String,
    val currentValue: String,
    val targetValue: String,
    val status: String,
    val notes: String,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "client_lifestyles",
    indices = [Index(value = ["clientId"], unique = true), Index(value = ["trainerId"])]
)
data class ClientLifestyleEntity(
    @PrimaryKey val clientId: String,
    val trainerId: String,
    val sleepDurationHours: Double,
    val sleepQualityRating: Int,
    val stressRating: Int,
    val activityLevel: String,
    val dailyAverageSteps: Int,
    val workScheduleType: String,
    val recoveryRating: Int,
    val hydrationLiters: Double,
    val nutritionHabitsSummary: String,
    val trainingAvailabilityDays: String,
    val lifestyleNotes: String,
    val updatedAt: Long
)

@Entity(
    tableName = "assessment_sessions",
    indices = [Index(value = ["clientId"]), Index(value = ["trainerId"])]
)
data class AssessmentSessionEntity(
    @PrimaryKey val id: String,
    val clientId: String,
    val trainerId: String,
    val title: String,
    val date: String,
    val isBaseline: Boolean,
    val categoriesJson: String, // serialized categories list
    val itemsJson: String, // serialized assessment items list
    val summaryObservations: String,
    val trainerRecommendations: String,
    val createdAt: Long
)

@Entity(
    tableName = "client_measurements",
    indices = [Index(value = ["clientId"]), Index(value = ["trainerId"])]
)
data class ClientMeasurementEntity(
    @PrimaryKey val id: String,
    val clientId: String,
    val trainerId: String,
    val type: String,
    val customTypeName: String?,
    val value: Double,
    val unit: String,
    val date: String,
    val notes: String,
    val createdAt: Long
)

@Entity(
    tableName = "progress_photos",
    indices = [Index(value = ["clientId"]), Index(value = ["trainerId"])]
)
data class ProgressPhotoEntity(
    @PrimaryKey val id: String,
    val clientId: String,
    val trainerId: String,
    val photoUri: String,
    val category: String,
    val customCategoryName: String?,
    val date: String,
    val notes: String,
    val createdAt: Long
)

@Entity(
    tableName = "timeline_events",
    indices = [Index(value = ["clientId"]), Index(value = ["trainerId"])]
)
data class TimelineEventEntity(
    @PrimaryKey val id: String,
    val clientId: String,
    val trainerId: String,
    val eventType: String,
    val title: String,
    val description: String,
    val date: String,
    val timestamp: Long
)
