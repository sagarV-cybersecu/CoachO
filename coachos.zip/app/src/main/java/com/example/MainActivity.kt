package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.example.ai.AIService
import com.example.ai.ClientIntelligenceService
import com.example.ai.GeminiAiService
import com.example.data.local.AppDatabase
import com.example.data.repository.CoachRepository
import com.example.data.session.SessionManager
import com.example.ui.navigation.CoachAppRoot
import com.example.ui.theme.CoachOSTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getInstance(applicationContext)
        val sessionManager = SessionManager.getInstance(applicationContext)
        val repository = CoachRepository(database)
        val aiService: AIService = GeminiAiService()
        val intelligenceService = ClientIntelligenceService(
            aiService = aiService,
            repository = repository
        )

        setContent {
            CoachOSTheme {
                CoachAppRoot(
                    repository = repository,
                    sessionManager = sessionManager,
                    intelligenceService = intelligenceService
                )
            }
        }
    }
}

// Kept for preview and test suite compatibility
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}
